import { useAuth } from "@/hooks/use-auth";
import { useUserDashboard } from "@/hooks/use-faucet";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { getUserTier } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Coins, LogOut } from "lucide-react";

export function TopBar() {
  const { user, logout } = useAuth();
  const { data, isLoading } = useUserDashboard();
  const { convertToUsd } = useBtcPrice();

  if (!user) return null;

  const balanceSats = Number(data?.profile.balance || 0);
  const experience = data?.profile.experience || 0;
  const tier = getUserTier(experience);

  return (
    <header className="hidden lg:flex items-center justify-end h-16 px-6 border-b border-border/30 bg-background/80 backdrop-blur-sm sticky top-0 z-40">
      <div className="flex items-center gap-5">
        <div className="flex items-center gap-1.5 text-xs">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tier.color }} />
          <span className="text-muted-foreground font-medium">{tier.name}</span>
          <span className="text-muted-foreground/50 font-mono">
            {experience.toLocaleString()} XP
          </span>
        </div>

        <div className="h-5 w-px bg-border/30" />

        <div className="flex items-center gap-2">
          <Coins className="w-4 h-4 text-primary" />
          {isLoading ? (
            <Skeleton className="h-5 w-20 bg-card" />
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-primary font-bold font-mono text-sm" data-testid="text-topbar-balance">
                {balanceSats.toLocaleString()}
              </span>
              <span className="text-muted-foreground/60 text-xs font-mono">{convertToUsd(balanceSats)}</span>
            </div>
          )}
        </div>

        <div className="h-5 w-px bg-border/30" />

        <div className="flex items-center gap-2.5">
          <div className="text-right hidden xl:block">
            <p className="text-xs font-medium text-foreground leading-tight">{user.firstName} {user.lastName}</p>
            <p className="text-[10px] text-muted-foreground truncate max-w-[120px]">{user.email}</p>
          </div>
          <div className="h-8 w-8 rounded-md bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/15 flex items-center justify-center overflow-hidden">
            {user.profileImageUrl ? (
              <img src={user.profileImageUrl} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="text-primary font-bold text-xs">
                {user.firstName?.[0] || user.email?.[0] || 'U'}
              </div>
            )}
          </div>
        </div>

        <div className="h-5 w-px bg-border/30" />

        <Button
          variant="ghost"
          size="icon"
          onClick={() => logout()}
          className="text-muted-foreground"
          data-testid="button-topbar-logout"
        >
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    </header>
  );
}
