import { Link, useLocation } from "wouter";
import { LayoutDashboard, Coins, Wallet, ArrowUpDown, TrendingUp, LogOut, Menu, MessageCircle, Landmark, Grid3X3, Swords, Mail, Crown, Rocket, Trophy } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useUserDashboard } from "@/hooks/use-faucet";
import { cn } from "@/lib/utils";
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getUserTier, USER_TIERS, TIER_PERKS, getNextTier } from "@shared/schema";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import cruxLogo from "@assets/CA0A230C-04DB-489C-8663-E0A31C1FE619_1771457007262.png";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard },
  { label: "Faucet", href: "/faucet", icon: Coins },
  { label: "Crash", href: "/crash", icon: Rocket },
  { label: "Hi-Lo", href: "/hilo", icon: ArrowUpDown },
  { label: "Keno", href: "/keno", icon: Grid3X3 },
  { label: "Duels", href: "/duels", icon: Swords },
  { label: "Leaderboard", href: "/leaderboard", icon: Trophy },
  { label: "Chat", href: "/chat", icon: MessageCircle },
  { label: "Ranks", href: "/ranks", icon: Crown },
  { label: "Inbox", href: "/inbox", icon: Mail },
  { label: "Staking", href: "/staking", icon: Landmark },
  { label: "Bitcoin", href: "/bitcoin", icon: TrendingUp },
  { label: "Wallet", href: "/wallet", icon: Wallet },
];

function UserProfileBox() {
  const { user } = useAuth();
  const { data: dashboardData } = useUserDashboard();
  const profile = dashboardData?.profile;

  if (!user || !profile) return null;

  const tier = getUserTier(profile.experience);
  const nextTier = getNextTier(profile.experience);
  const perks = TIER_PERKS[tier.name as keyof typeof TIER_PERKS];
  const balance = Number(profile.balance || 0);
  const xp = profile.experience || 0;

  const displayName = user.firstName
    ? `${user.firstName} ${(user.lastName || "").charAt(0)}.`
    : `User`;

  const xpProgress = nextTier
    ? Math.min(100, ((xp - tier.minXp) / (nextTier.minXp - tier.minXp)) * 100)
    : 100;

  return (
    <div className="mx-3 mb-3 rounded-lg border border-border/30 bg-background/40 p-3 space-y-2.5" data-testid="sidebar-user-profile">
      <div className="flex items-center gap-2.5">
        <Avatar className="h-9 w-9 border border-border/40">
          <AvatarImage src={user.profileImageUrl || undefined} alt={displayName} />
          <AvatarFallback className="text-xs font-bold bg-primary/10 text-primary">
            {(user.firstName || "U").charAt(0)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground truncate" data-testid="text-sidebar-username">
            {displayName}
          </p>
          <div className="flex items-center gap-1.5">
            <Badge
              variant="outline"
              className="text-[9px] px-1.5 py-0 h-4 font-bold no-default-hover-elevate no-default-active-elevate"
              style={{
                borderColor: tier.color + "50",
                color: tier.color,
                backgroundColor: tier.color + "10",
              }}
              data-testid="badge-sidebar-tier"
            >
              {tier.name}
            </Badge>
          </div>
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-muted-foreground">Balance</span>
          <span className="font-mono font-bold text-primary" data-testid="text-sidebar-balance">
            {balance.toLocaleString()} Crux
          </span>
        </div>
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-muted-foreground">XP</span>
          <span className="font-mono font-bold text-foreground" data-testid="text-sidebar-xp">
            {xp.toLocaleString()}
          </span>
        </div>
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-muted-foreground">Faucet</span>
          <span className="font-mono font-bold text-foreground">{perks?.faucetMultiplier}x</span>
        </div>
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-muted-foreground">Cooldown</span>
          <span className="font-mono font-bold text-foreground">{perks?.cooldownMinutes}min</span>
        </div>
      </div>

      {nextTier && (
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[9px] text-muted-foreground">
            <span>Next: {nextTier.name}</span>
            <span>{Math.round(xpProgress)}%</span>
          </div>
          <div className="h-1 rounded-full bg-border/40 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${xpProgress}%`,
                backgroundColor: nextTier.color,
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export function Sidebar() {
  const [location] = useLocation();
  const { logout } = useAuth();

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-5 pb-4">
        <div className="flex items-center gap-2">
          <img src={cruxLogo} alt="CruxCrypto.org" className="h-10 w-auto object-contain" data-testid="img-site-logo" />
        </div>
      </div>

      <UserProfileBox />

      <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} aria-current={isActive ? "page" : undefined}>
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-200 cursor-pointer text-sm",
                  isActive
                    ? "bg-primary/10 text-primary font-medium border border-primary/15"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/[0.04]"
                )}
                data-testid={`nav-${item.label.toLowerCase().replace(/\s/g, '-')}`}
              >
                <item.icon className={cn("w-4 h-4", isActive ? "text-primary" : "")} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-3 mt-auto border-t border-border/30">
        <button
          type="button"
          onClick={() => logout()}
          className="flex items-center gap-3 px-3 py-2.5 w-full rounded-md text-sm text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors"
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block w-64 h-screen fixed left-0 top-0 border-r border-border/30 bg-card/40 backdrop-blur-xl z-50">
        <NavContent />
      </aside>

      <div className="lg:hidden fixed top-0 left-0 right-0 p-4 flex items-center justify-between bg-card/80 backdrop-blur-lg border-b border-border/30 z-50">
        <div className="flex items-center gap-2">
          <img src={cruxLogo} alt="CruxCrypto.org" className="h-8 w-auto object-contain" data-testid="img-site-logo-mobile" />
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0 bg-card border-r border-border/30">
            <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
            <SheetDescription className="sr-only">Main navigation links for Crux Faucet</SheetDescription>
            <NavContent />
          </SheetContent>
        </Sheet>
      </div>
    </>
  );
}
