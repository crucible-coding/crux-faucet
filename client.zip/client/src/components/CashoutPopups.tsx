import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DollarSign } from "lucide-react";

const FIRST_NAMES = [
  "ju", "ma", "al", "sa", "ch", "da", "mi", "ja", "ro", "an",
  "br", "ke", "st", "ni", "pa", "le", "to", "ka", "ri", "em",
  "jo", "lu", "vi", "ga", "ha", "se", "ty", "cr", "de", "fr",
  "za", "xe", "ky", "bl", "ra", "mo", "ta", "ca", "fi", "wa",
];

const AMOUNTS = [
  20, 25, 30, 35, 40, 45, 50, 55, 60, 75, 80, 90, 100, 120, 150,
  175, 200, 250, 300, 350, 400, 500, 750, 1000, 1500, 2000, 2500,
];

const CRYPTOS = ["BTC", "ETH", "USDC"];

function generateNotification() {
  const name = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const stars = "*".repeat(Math.floor(Math.random() * 3) + 3);
  const amount = AMOUNTS[Math.floor(Math.random() * AMOUNTS.length)];
  const crypto = CRYPTOS[Math.floor(Math.random() * CRYPTOS.length)];
  const id = Date.now() + Math.random();
  return { id, username: `${name}${stars}`, amount, crypto };
}

export function CashoutPopups() {
  const [notifications, setNotifications] = useState<ReturnType<typeof generateNotification>[]>([]);

  const addNotification = useCallback(() => {
    const notif = generateNotification();
    setNotifications((prev) => [...prev.slice(-2), notif]);
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== notif.id));
    }, 4000);
  }, []);

  useEffect(() => {
    const initialDelay = setTimeout(() => {
      addNotification();
    }, 5000 + Math.random() * 5000);

    const interval = setInterval(() => {
      addNotification();
    }, 8000 + Math.random() * 12000);

    return () => {
      clearTimeout(initialDelay);
      clearInterval(interval);
    };
  }, [addNotification]);

  return (
    <div className="fixed bottom-4 left-4 z-[9999] flex flex-col gap-2 pointer-events-none" data-testid="cashout-popups-container">
      <AnimatePresence>
        {notifications.map((notif) => (
          <motion.div
            key={notif.id}
            initial={{ opacity: 0, x: -100, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -60, scale: 0.9 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="flex items-center gap-2 bg-card/95 backdrop-blur-md border border-green-500/30 rounded-lg px-4 py-3 shadow-lg shadow-green-500/10"
            data-testid="cashout-popup-notification"
          >
            <div className="w-7 h-7 rounded-full bg-green-500/20 flex items-center justify-center shrink-0">
              <DollarSign className="w-4 h-4 text-green-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-green-400 font-mono" data-testid="text-cashout-popup">
                {notif.username} +${notif.amount.toLocaleString()} cash out
              </p>
              <p className="text-[10px] text-green-400/60 font-mono">
                {notif.crypto} withdrawal confirmed
              </p>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
