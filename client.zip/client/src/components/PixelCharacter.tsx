import { motion } from "framer-motion";
import { getAvatarDef } from "@shared/schema";

interface PixelCharacterProps {
  avatarId: string;
  size?: number;
  facing?: "left" | "right";
  attacking?: boolean;
  winner?: boolean;
  loser?: boolean;
  idle?: boolean;
}

export function PixelCharacter({
  avatarId,
  size = 120,
  facing = "right",
  attacking = false,
  winner = false,
  loser = false,
  idle = true,
}: PixelCharacterProps) {
  const avatar = getAvatarDef(avatarId);
  const scale = size / 120;
  const flip = facing === "left" ? -1 : 1;

  const eyeColor = avatarId === "herobrine" ? "#ffffff" : avatarId === "enderman" ? "#ff00ff" : avatarId === "blaze" ? "#ffaa00" : "#1a1a1a";
  const eyeGlow = avatarId === "herobrine" || avatarId === "enderman" || avatarId === "blaze";

  const swordColors: Record<string, string> = {
    "Wooden Sword": "#8B6914",
    "Stone Sword": "#888888",
    "Iron Sword": "#c0c0c0",
    "Diamond Sword": "#00d4ff",
    "Netherite Sword": "#3a3a3a",
    "Enchanted Blade": "#aa44ff",
    "Sonic Blade": "#00ffcc",
  };
  const swordColor = swordColors[avatar.weapon] || "#888888";
  const swordGlow = ["Diamond Sword", "Enchanted Blade", "Sonic Blade"].includes(avatar.weapon);

  return (
    <motion.div
      style={{ width: size, height: size * 1.4, transform: `scaleX(${flip})`, imageRendering: "pixelated" }}
      animate={
        winner
          ? { y: [0, -10, 0], scale: [1, 1.05, 1] }
          : loser
          ? { opacity: [1, 0.4, 1], rotate: [0, -5, 0] }
          : idle
          ? { y: [0, -3, 0] }
          : {}
      }
      transition={
        winner
          ? { duration: 0.6, repeat: Infinity }
          : loser
          ? { duration: 1.2, repeat: 2 }
          : idle
          ? { duration: 2, repeat: Infinity, ease: "easeInOut" }
          : {}
      }
    >
      <svg
        viewBox="0 0 120 168"
        width={size}
        height={size * 1.4}
        style={{ imageRendering: "pixelated" }}
      >
        <rect x="30" y="0" width="60" height="60" fill={avatar.skinColor} rx="2" />

        <rect x="42" y="16" width="12" height="10" fill={eyeColor} rx="1" />
        <rect x="66" y="16" width="12" height="10" fill={eyeColor} rx="1" />
        {eyeGlow && (
          <>
            <rect x="42" y="16" width="12" height="10" fill={eyeColor} opacity="0.6" rx="1">
              <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" />
            </rect>
            <rect x="66" y="16" width="12" height="10" fill={eyeColor} opacity="0.6" rx="1">
              <animate attributeName="opacity" values="0.3;0.8;0.3" dur="2s" repeatCount="indefinite" />
            </rect>
          </>
        )}

        <rect x="48" y="36" width="24" height="6" fill={avatar.skinColor} opacity="0.6" rx="1" />

        {avatarId === "skeleton" && (
          <>
            <rect x="42" y="32" width="36" height="12" fill="#1a1a1a" opacity="0.3" rx="1" />
          </>
        )}

        <rect x="24" y="60" width="72" height="48" fill={avatar.shirtColor} rx="2" />

        <rect x="6" y="60" width="18" height="42" fill={avatar.shirtColor} rx="2" />
        <rect x="6" y="96" width="18" height="12" fill={avatar.skinColor} rx="1" />

        <motion.g
          animate={attacking ? { rotate: [0, -90, -120, 0] } : {}}
          transition={attacking ? { duration: 0.5, ease: "easeOut" } : {}}
          style={{ transformOrigin: "96px 72px" }}
        >
          <rect x="96" y="60" width="18" height="42" fill={avatar.shirtColor} rx="2" />
          <rect x="96" y="96" width="18" height="12" fill={avatar.skinColor} rx="1" />

          <rect x="108" y="40" width="6" height="56" fill={swordColor} rx="1" />
          <rect x="102" y="52" width="18" height="6" fill={swordColor === "#8B6914" ? "#5c4710" : "#666"} rx="1" />
          {swordGlow && (
            <rect x="108" y="40" width="6" height="56" fill={swordColor} opacity="0.4" rx="1">
              <animate attributeName="opacity" values="0.2;0.6;0.2" dur="1.5s" repeatCount="indefinite" />
            </rect>
          )}
        </motion.g>

        <rect x="30" y="108" width="24" height="48" fill={avatar.pantsColor} rx="2" />
        <rect x="66" y="108" width="24" height="48" fill={avatar.pantsColor} rx="2" />

        <rect x="30" y="148" width="24" height="12" fill={avatar.pantsColor} opacity="0.7" rx="1" />
        <rect x="66" y="148" width="24" height="12" fill={avatar.pantsColor} opacity="0.7" rx="1" />
      </svg>
    </motion.div>
  );
}

export function PixelCharacterCard({
  avatarId,
  selected,
  locked,
  onClick,
}: {
  avatarId: string;
  selected?: boolean;
  locked?: boolean;
  onClick?: () => void;
}) {
  const avatar = getAvatarDef(avatarId);

  return (
    <motion.div
      whileHover={!locked ? { scale: 1.05 } : {}}
      whileTap={!locked ? { scale: 0.98 } : {}}
      onClick={!locked ? onClick : undefined}
      className={`relative p-3 rounded-md cursor-pointer border transition-all ${
        selected
          ? "border-primary bg-primary/10 ring-1 ring-primary/30"
          : locked
          ? "border-border/20 bg-card/30 opacity-50 cursor-not-allowed"
          : "border-border/30 bg-card/50 hover:border-primary/30"
      }`}
      data-testid={`avatar-card-${avatarId}`}
    >
      <div className="flex flex-col items-center gap-2">
        <PixelCharacter avatarId={avatarId} size={64} idle={!locked} />
        <div className="text-center">
          <div className="text-xs font-bold text-foreground">{avatar.name}</div>
          <div className="text-[10px] text-muted-foreground">{avatar.weapon}</div>
          {locked && (
            <div className="text-[10px] text-orange-400 font-medium mt-0.5">
              {avatar.minTier}+
            </div>
          )}
        </div>
      </div>
      {selected && (
        <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-primary flex items-center justify-center">
          <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
            <path d="M1 4L3 6L7 2" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      )}
    </motion.div>
  );
}
