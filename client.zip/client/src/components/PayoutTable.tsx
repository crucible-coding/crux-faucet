import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const PAYOUTS = [
  { range: "0000", amount: 50000, isJackpot: true },
  { range: "0001 - 0010", amount: 5000 },
  { range: "0011 - 0100", amount: 500 },
  { range: "0101 - 1000", amount: 50 },
  { range: "1001 - 5000", amount: 10 },
  { range: "5001 - 9999", amount: 5 },
];

export function PayoutTable() {
  return (
    <Card className="neon-card bg-card/80 overflow-hidden">
      <div className="p-4 border-b border-border/20 bg-gradient-to-r from-primary/5 to-accent/5">
        <h3 className="font-display font-bold text-sm text-center text-foreground uppercase tracking-wider">Lucky Numbers</h3>
        <p className="text-[11px] text-muted-foreground text-center mt-0.5">Lower = Better!</p>
      </div>
      <div className="divide-y divide-border/15">
        {PAYOUTS.map((tier, index) => (
          <motion.div
            key={tier.range}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.04 }}
            className={`flex justify-between items-center px-5 py-2.5 ${
              tier.isJackpot ? "bg-primary/8" : ""
            }`}
          >
            <span className={`font-mono text-sm ${tier.isJackpot ? "text-primary font-bold" : "text-muted-foreground"}`}>
              {tier.range}
            </span>
            <div className="flex items-center gap-2">
              {tier.isJackpot && <Badge variant="default" className="text-[10px]">Jackpot</Badge>}
              <span className={`font-bold font-mono text-sm ${tier.isJackpot ? "text-primary" : "text-foreground"}`}>
                {tier.amount.toLocaleString()} Crux
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}
