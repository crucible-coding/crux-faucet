import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Cookie } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export function CookieConsent() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("crux_cookie_consent");
    if (!consent) {
      const timer = setTimeout(() => setShow(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const accept = () => {
    localStorage.setItem("crux_cookie_consent", "accepted");
    setShow(false);
  };

  const decline = () => {
    localStorage.setItem("crux_cookie_consent", "declined");
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className="fixed bottom-0 left-0 right-0 z-50 p-4"
          data-testid="cookie-consent-banner"
        >
          <div className="max-w-3xl mx-auto bg-card border border-border/50 rounded-lg shadow-lg p-4 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <Cookie className="w-5 h-5 text-primary shrink-0 mt-0.5 sm:mt-0" />
            <div className="flex-1 text-sm text-muted-foreground">
              <p>
                We use cookies to maintain your session and improve your experience. By continuing to use this site, you consent to our use of cookies.{" "}
                <Link href="/privacy" className="text-primary underline" data-testid="link-cookie-privacy">
                  Privacy Policy
                </Link>
              </p>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button size="sm" variant="ghost" onClick={decline} data-testid="button-cookie-decline">
                Decline
              </Button>
              <Button size="sm" onClick={accept} data-testid="button-cookie-accept">
                Accept
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
