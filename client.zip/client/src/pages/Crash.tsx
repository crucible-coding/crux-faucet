export default function Crash(){
  return (
    <div>
      <h1>Turn your crypto x4000</h1>
      <p>Play Crash and Win</p>
    </div>
  );
}