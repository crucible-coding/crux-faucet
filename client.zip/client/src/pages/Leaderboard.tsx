import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getUserTier, USER_TIERS } from "@shared/schema";
import { Trophy, TrendingUp, Rocket, Crown } from "lucide-react";
import { motion } from "framer-motion";

type LeaderboardEntry = {
  userId: string;
  name: string;
  avatar: string;
  tier: string;
  tierColor: string;
};

type RichestEntry = LeaderboardEntry & { totalBalance: string };
type XpEntry = LeaderboardEntry & { experience: number };
type CrashEntry = LeaderboardEntry & { biggestWin: string; crashPoint: string; cashedOutAt: string | null };

type LeaderboardData = {
  richest: RichestEntry[];
  topXp: XpEntry[];
  crashWins: CrashEntry[];
};

function RankMedal({ rank }: { rank: number }) {
  if (rank === 1) return <div className="w-7 h-7 rounded-md bg-yellow-500/20 border border-yellow-500/30 flex items-center justify-center text-yellow-500 font-bold text-xs" data-testid={`medal-${rank}`}>1</div>;
  if (rank === 2) return <div className="w-7 h-7 rounded-md bg-gray-300/20 border border-gray-400/30 flex items-center justify-center text-gray-400 font-bold text-xs" data-testid={`medal-${rank}`}>2</div>;
  if (rank === 3) return <div className="w-7 h-7 rounded-md bg-amber-700/20 border border-amber-700/30 flex items-center justify-center text-amber-600 font-bold text-xs" data-testid={`medal-${rank}`}>3</div>;
  return <div className="w-7 h-7 rounded-md bg-muted/30 flex items-center justify-center text-muted-foreground text-xs font-mono" data-testid={`rank-${rank}`}>{rank}</div>;
}

function TierBadge({ tierName, tierColor }: { tierName: string; tierColor: string }) {
  const idx = USER_TIERS.findIndex(t => t.name === tierName);
  const baseClasses = "text-[10px] font-bold px-2 py-0.5 rounded-md inline-flex items-center gap-1";

  if (idx >= 5) {
    return <span className={`${baseClasses} tier-badge-rainbow`} style={{ backgroundColor: tierColor + "20" }}><Crown className="w-3 h-3" />{tierName}</span>;
  }
  return <span className={baseClasses} style={{ backgroundColor: tierColor + "20", color: tierColor }}>{tierName}</span>;
}

function LeaderboardTable<T extends LeaderboardEntry>({
  title,
  icon: Icon,
  data,
  renderValue,
  emptyMessage,
}: {
  title: string;
  icon: any;
  data: T[] | undefined;
  renderValue: (entry: T) => string;
  emptyMessage: string;
}) {
  return (
    <Card className="p-0 overflow-hidden">
      <div className="flex items-center gap-2 px-5 py-4 border-b border-border/30">
        <Icon className="w-5 h-5 text-primary" />
        <h2 className="font-bold text-foreground" data-testid={`leaderboard-title-${title.toLowerCase().replace(/\s/g, '-')}`}>{title}</h2>
      </div>
      <div className="divide-y divide-border/20">
        {!data ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 px-5 py-3">
              <Skeleton className="w-7 h-7 rounded-md" />
              <Skeleton className="w-24 h-4" />
              <Skeleton className="w-16 h-4 ml-auto" />
            </div>
          ))
        ) : data.length === 0 ? (
          <div className="px-5 py-8 text-center text-sm text-muted-foreground">{emptyMessage}</div>
        ) : (
          data.map((entry, i) => (
            <motion.div
              key={entry.userId + i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.03 }}
              className="flex items-center gap-3 px-5 py-3"
              data-testid={`leaderboard-row-${i}`}
            >
              <RankMedal rank={i + 1} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-sm text-foreground truncate" data-testid={`leaderboard-name-${i}`}>{entry.name}</span>
                  <TierBadge tierName={entry.tier} tierColor={entry.tierColor} />
                </div>
              </div>
              <span className="text-sm font-mono font-bold text-primary whitespace-nowrap" data-testid={`leaderboard-value-${i}`}>
                {renderValue(entry)}
              </span>
            </motion.div>
          ))
        )}
      </div>
    </Card>
  );
}

export default function Leaderboard() {
  const { data, isLoading } = useQuery<LeaderboardData>({
    queryKey: ["/api/leaderboard"],
    refetchInterval: 30000,
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Trophy className="w-7 h-7 text-primary" />
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-leaderboard-title">Leaderboard</h1>
          <p className="text-sm text-muted-foreground">See who's on top across the server</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <LeaderboardTable
          title="Richest Users"
          icon={Trophy}
          data={data?.richest}
          renderValue={(e) => `${parseFloat(e.totalBalance).toLocaleString()} Crux`}
          emptyMessage="No wallet data yet. Start claiming to get on the board!"
        />

        <LeaderboardTable
          title="Top Earners (XP)"
          icon={TrendingUp}
          data={data?.topXp}
          renderValue={(e) => `${e.experience.toLocaleString()} XP`}
          emptyMessage="No XP earned yet. Roll the faucet to earn XP!"
        />
      </div>

      <LeaderboardTable
        title="Biggest Crash Wins"
        icon={Rocket}
        data={data?.crashWins}
        renderValue={(e) => `${parseFloat(e.biggestWin).toLocaleString()} Crux @ ${e.cashedOutAt || "?"}x`}
        emptyMessage="No crash wins yet. Play Crash to get on the board!"
      />
    </div>
  );
}
