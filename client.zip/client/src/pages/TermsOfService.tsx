import { Card } from "@/components/ui/card";
import { FileText } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      <div>
        <div className="flex items-center gap-2 mb-2">
          <FileText className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold font-display text-foreground" data-testid="text-tos-title">Terms of Service</h1>
        </div>
        <p className="text-sm text-muted-foreground">Last updated: February 18, 2026</p>
      </div>

      <Card className="p-6 space-y-6 text-sm text-foreground/90 leading-relaxed">
        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">1. Acceptance of Terms</h2>
          <p className="text-muted-foreground">
            By accessing or using Crux Faucet ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree to these terms, you may not access or use the Platform. The Platform is operated under the laws of the State of Nevada.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">2. Platform Description</h2>
          <p className="text-muted-foreground">
            Crux Faucet is a cryptocurrency savings and investment platform that allows users to accumulate digital assets through periodic claiming (faucet), membership benefits, and platform activities. The Platform is designed to help users build long-term cryptocurrency holdings. Crux is the in-platform unit used to track your crypto savings across supported wallets (BTC, ETH, USDC).
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">3. Eligibility</h2>
          <p className="text-muted-foreground mb-2">To use the Platform, you must:</p>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>Be at least 21 years of age</li>
            <li>Not be located in a restricted jurisdiction (Utah, Hawaii, Alabama, Alaska, or Georgia)</li>
            <li>Have the legal capacity to enter into a binding agreement</li>
            <li>Comply with all applicable local, state, and federal laws</li>
          </ul>
          <p className="text-muted-foreground mt-2">
            The Platform uses IP-based geolocation to enforce jurisdictional restrictions. Attempting to circumvent these restrictions may result in account termination and forfeiture of accumulated assets.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">4. Account Registration</h2>
          <p className="text-muted-foreground">
            You must create an account through our authentication provider to use the Platform. You are responsible for maintaining the confidentiality of your account credentials and for all activity that occurs under your account. You agree to notify us immediately of any unauthorized access.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">5. Crux Points and Cryptocurrency</h2>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>Crux points represent units within the Platform that correspond to cryptocurrency value</li>
            <li>Crux can be accumulated through free faucet claims, daily bonuses, and platform activities</li>
            <li>Crux is allocated to your chosen cryptocurrency wallets (BTC, ETH, USDC)</li>
            <li>Withdrawal requires a minimum of $20 USD equivalent in a specific cryptocurrency wallet</li>
            <li>A membership tier (minimum Journeyman) is required to unlock withdrawal capabilities</li>
            <li>A 1-5% sliding processing fee applies to all withdrawals (lower fee for larger amounts)</li>
            <li>Cryptocurrency values are volatile and may fluctuate significantly</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">6. Membership Tiers</h2>
          <p className="text-muted-foreground">
            The Platform offers paid membership tiers (Journeyman through Elite) that provide enhanced benefits including faster faucet cooldowns, higher multipliers, daily bonuses, and reduced withdrawal requirements. Memberships are processed through Stripe and are subscription-based. You may cancel your subscription at any time, but no refunds will be issued for partial billing periods.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">7. Platform Activities</h2>
          <p className="text-muted-foreground">
            The Platform includes entertainment features (Crash, Hi-Lo, Keno, Duels) that allow users to increase or decrease their Crux balance. These features use a provably fair system where all outcomes are cryptographically verifiable. Users should understand that participation in these activities carries risk of loss. These features are provided for entertainment purposes and should not be considered a primary investment strategy.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">8. Provably Fair System</h2>
          <p className="text-muted-foreground">
            All platform operations use a provably fair algorithm based on cryptographic hashing (SHA-256). Each operation uses a server seed, client seed, and nonce to generate verifiable results. Users can independently verify any result using the revealed server seed after each operation.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">9. Liquidity Protection</h2>
          <p className="text-muted-foreground">
            To ensure all users can withdraw their funds, the Platform maintains a liquidity reserve requirement. Withdrawals may be temporarily limited if the Platform's reserve falls below the required threshold. This measure protects all users' ability to access their funds.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">10. Prohibited Conduct</h2>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>Creating multiple accounts or using automated tools to claim faucet rewards</li>
            <li>Exploiting bugs, glitches, or vulnerabilities in the Platform</li>
            <li>Attempting to circumvent geographic restrictions</li>
            <li>Engaging in fraudulent activity or money laundering</li>
            <li>Harassing, threatening, or abusing other users in the chat</li>
            <li>Violating any applicable laws or regulations</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">11. Termination</h2>
          <p className="text-muted-foreground">
            We reserve the right to suspend or terminate your account at any time for violation of these Terms, suspected fraud, or any other reason at our sole discretion. Upon termination for cause, you may forfeit any accumulated Crux balance.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">12. Disclaimer of Warranties</h2>
          <p className="text-muted-foreground">
            THE PLATFORM IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED. WE DO NOT GUARANTEE UNINTERRUPTED ACCESS, THE ACCURACY OF CRYPTOCURRENCY PRICE DATA, OR THAT THE PLATFORM WILL MEET YOUR SPECIFIC INVESTMENT GOALS. CRYPTOCURRENCY INVESTMENTS ARE INHERENTLY VOLATILE AND CARRY SUBSTANTIAL RISK OF LOSS.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">13. Limitation of Liability</h2>
          <p className="text-muted-foreground">
            TO THE MAXIMUM EXTENT PERMITTED BY LAW, WE SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING LOSS OF PROFITS OR CRYPTOCURRENCY VALUE, ARISING OUT OF YOUR USE OF THE PLATFORM.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">14. Governing Law</h2>
          <p className="text-muted-foreground">
            These Terms shall be governed by and construed in accordance with the laws of the State of Nevada, without regard to its conflict of laws principles. Any disputes arising under these Terms shall be resolved in the state or federal courts located in Clark County, Nevada.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">15. Changes to Terms</h2>
          <p className="text-muted-foreground">
            We reserve the right to modify these Terms at any time. We will notify you of material changes by posting the updated Terms on this page. Your continued use of the Platform after changes constitutes acceptance of the revised Terms.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">16. Contact</h2>
          <p className="text-muted-foreground">
            If you have questions about these Terms of Service, please contact us through the platform's support channels.
          </p>
        </section>
      </Card>
    </div>
  );
}
