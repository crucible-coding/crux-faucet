import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mail, MailOpen, Loader2, Swords, Gift, Shield, CheckCircle, Inbox as InboxIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type InboxMsg = {
  id: number;
  userId: string;
  subject: string;
  body: string;
  type: string;
  isRead: boolean;
  actionType: string | null;
  actionCompleted: boolean;
  createdAt: string;
};

function getTypeIcon(type: string) {
  switch (type) {
    case "duel_challenge": return <Swords className="w-4 h-4 text-orange-400" />;
    case "reward": return <Gift className="w-4 h-4 text-green-400" />;
    case "verification": return <Shield className="w-4 h-4 text-cyan-400" />;
    default: return <Mail className="w-4 h-4 text-primary" />;
  }
}

function getTypeBadge(type: string) {
  switch (type) {
    case "duel_challenge": return <Badge variant="outline" className="text-[9px] border-orange-400/40 text-orange-400">Duel</Badge>;
    case "reward": return <Badge variant="outline" className="text-[9px] border-green-400/40 text-green-400">Reward</Badge>;
    case "verification": return <Badge variant="outline" className="text-[9px] border-cyan-400/40 text-cyan-400">Verify</Badge>;
    default: return <Badge variant="outline" className="text-[9px]">System</Badge>;
  }
}

export default function Inbox() {
  const { toast } = useToast();

  const { data, isLoading } = useQuery<{ messages: InboxMsg[]; unreadCount: number }>({
    queryKey: [api.inbox.list.path],
    refetchInterval: 10000,
  });

  const markReadMutation = useMutation({
    mutationFn: async (messageId: number) => {
      const res = await apiRequest("POST", api.inbox.read.path, { messageId });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.inbox.list.path] });
    },
  });

  const verifyEmailMutation = useMutation({
    mutationFn: async (messageId: number) => {
      const res = await apiRequest("POST", api.inbox.verifyEmail.path, { messageId });
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.inbox.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/dashboard"] });
      toast({ title: data.message });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const messages = data?.messages || [];
  const unreadCount = data?.unreadCount || 0;

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-bold font-display tracking-tight gradient-text-cyan-purple" data-testid="text-page-title">
          <InboxIcon className="w-8 h-8 inline mr-2" />
          Inbox
        </h1>
        <p className="text-sm text-muted-foreground">
          {unreadCount > 0 ? `You have ${unreadCount} unread message${unreadCount > 1 ? "s" : ""}` : "All caught up!"}
        </p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : messages.length === 0 ? (
        <Card className="neon-card bg-card/80 p-12 text-center">
          <MailOpen className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
          <p className="text-muted-foreground text-sm">Your inbox is empty. Play games and interact to receive messages!</p>
        </Card>
      ) : (
        <AnimatePresence>
          <div className="space-y-2">
            {messages.map((msg, idx) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card
                  className={`neon-card p-4 cursor-pointer transition-all ${
                    msg.isRead ? "bg-card/50 opacity-70" : "bg-card/80 border-primary/20"
                  }`}
                  onClick={() => {
                    if (!msg.isRead) {
                      markReadMutation.mutate(msg.id);
                    }
                  }}
                  data-testid={`inbox-message-${msg.id}`}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      {msg.isRead ? (
                        <MailOpen className="w-4 h-4 text-muted-foreground/50" />
                      ) : (
                        <Mail className="w-4 h-4 text-primary" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        {getTypeIcon(msg.type)}
                        <span className={`text-sm font-bold ${msg.isRead ? "text-muted-foreground" : "text-foreground"}`}>
                          {msg.subject}
                        </span>
                        {getTypeBadge(msg.type)}
                        {!msg.isRead && (
                          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                        )}
                      </div>

                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{msg.body}</p>

                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="text-[10px] text-muted-foreground/60">
                          {new Date(msg.createdAt).toLocaleDateString()} {new Date(msg.createdAt).toLocaleTimeString()}
                        </span>

                        {msg.actionType === "verify_email" && !msg.actionCompleted && (
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              verifyEmailMutation.mutate(msg.id);
                            }}
                            disabled={verifyEmailMutation.isPending}
                            data-testid={`button-verify-email-${msg.id}`}
                          >
                            {verifyEmailMutation.isPending ? (
                              <Loader2 className="w-3 h-3 animate-spin mr-1" />
                            ) : (
                              <CheckCircle className="w-3 h-3 mr-1" />
                            )}
                            Verify & Claim 1,000 Crux
                          </Button>
                        )}

                        {msg.actionCompleted && (
                          <Badge variant="outline" className="text-[9px] border-green-400/40 text-green-400">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Completed
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </AnimatePresence>
      )}
    </div>
  );
}
