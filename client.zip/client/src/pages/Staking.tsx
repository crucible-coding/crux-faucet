import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useUserDashboard } from "@/hooks/use-faucet";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { getUserTier, getTierPerks, TIER_PERKS, USER_TIERS } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Lock,
  Unlock,
  TrendingUp,
  ArrowRightLeft,
  Clock,
  Shield,
  Info,
  Loader2,
  Percent,
  Coins,
  AlertTriangle,
} from "lucide-react";
import { SiEthereum } from "react-icons/si";

export default function Staking() {
  const { data: dashboard, isLoading: dashLoading } = useUserDashboard();
  const { convertToUsd, btcPrice } = useBtcPrice();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [stakeAmount, setStakeAmount] = useState("");
  const [showStakeForm, setShowStakeForm] = useState(false);

  const { data: stakingData, isLoading: stakesLoading } = useQuery<{
    stakes: any[];
    totalEthStaked: string;
    totalSatoshiStaked: string;
    stakingApy: number;
  }>({
    queryKey: [api.staking.list.path],
  });

  const { data: prices } = useQuery<{
    btcPrice: number;
    ethPrice: number;
    btcToEthRate: number;
  }>({
    queryKey: [api.staking.prices.path],
    refetchInterval: 60000,
  });

  const balance = Number(dashboard?.profile?.balance || 0);
  const experience = dashboard?.profile?.experience || 0;
  const tier = getUserTier(experience);
  const perks = getTierPerks(tier.name);

  const canStake = perks.canStake;
  const stakeAmountNum = parseInt(stakeAmount) || 0;
  void prices;

  const stakeMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.staking.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ satoshiAmount: stakeAmountNum }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Stake Created", description: data.message });
      setStakeAmount("");
      setShowStakeForm(false);
      queryClient.invalidateQueries({ queryKey: [api.staking.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
    },
    onError: (err: any) => {
      toast({ title: "Staking Failed", description: err.message, variant: "destructive" });
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (stakeId: number) => {
      const res = await fetch(api.staking.withdraw.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ stakeId }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Withdrawal Successful", description: data.message });
      queryClient.invalidateQueries({ queryKey: [api.staking.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
    },
    onError: (err: any) => {
      toast({ title: "Withdrawal Failed", description: err.message, variant: "destructive" });
    },
  });

  const activeStakes = (stakingData?.stakes || []).filter((s: any) => s.status === "locked");
  const pastStakes = (stakingData?.stakes || []).filter((s: any) => s.status === "withdrawn");

  if (dashLoading || stakesLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div>
        <h1 className="text-3xl font-bold font-display text-foreground" data-testid="text-staking-title">Crux Staking</h1>
        <p className="text-muted-foreground">Stake your Crux on our server and earn {canStake ? `${perks.stakingApy}%` : "up to 2%"} APY rewards over time.</p>
      </div>

      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <div className="space-y-2 text-sm">
              <p className="font-semibold text-foreground">How Crux Staking Works</p>
              <ol className="list-decimal list-inside space-y-1 text-muted-foreground">
                <li>Choose how many Crux you want to stake</li>
                <li>Your Crux are locked on our server staking pool for <span className="text-primary font-bold">6 months</span></li>
                <li>You earn <span className="text-primary font-bold">{perks.stakingApy}% APY</span> staking rewards on your Crux</li>
                <li>After 6 months, withdraw your Crux + rewards</li>
              </ol>
              <div className="flex items-center gap-2 pt-1">
                <AlertTriangle className="w-4 h-4 text-yellow-500 shrink-0" />
                <p className="text-xs text-yellow-500/90">
                  Your Crux are locked for 6 months. You cannot withdraw early.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <Coins className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Available Balance</p>
            <p className="text-2xl font-mono font-bold text-foreground" data-testid="text-staking-balance">
              {balance.toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">Crux</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <Lock className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Crux Staked</p>
            <p className="text-2xl font-mono font-bold text-foreground" data-testid="text-total-crux-staked">
              {Number(stakingData?.totalSatoshiStaked || 0).toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground">Crux</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <Percent className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Your APY Rate</p>
            <p className="text-2xl font-mono font-bold text-primary" data-testid="text-staking-apy">
              {canStake ? `${perks.stakingApy}%` : "---"}
            </p>
            <p className="text-xs text-muted-foreground">{canStake ? `${tier.name} tier` : "Requires Engineer+"}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            APY Rates by Tier
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {USER_TIERS.map((t) => {
              const p = TIER_PERKS[t.name as keyof typeof TIER_PERKS];
              const isCurrentTier = t.name === tier.name;
              return (
                <div
                  key={t.name}
                  className={`rounded-md border p-3 text-center ${isCurrentTier ? "border-primary bg-primary/10" : "border-border/50"} ${!p.canStake ? "opacity-50" : ""}`}
                  data-testid={`tier-apy-${t.name.toLowerCase()}`}
                >
                  <p className="text-xs font-medium text-muted-foreground">{t.name}</p>
                  <p className={`text-lg font-mono font-bold ${!p.canStake ? "text-muted-foreground" : isCurrentTier ? "text-primary" : "text-foreground"}`}>
                    {p.canStake ? `${p.stakingApy}%` : "---"}
                  </p>
                  {isCurrentTier && <Badge variant="secondary" className="mt-1 text-[10px]">You</Badge>}
                  {!p.canStake && <p className="text-[10px] text-muted-foreground mt-1">Locked</p>}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-primary" />
            Stake Crux
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!canStake ? (
            <div className="text-center space-y-4 py-4">
              <Lock className="w-10 h-10 text-muted-foreground mx-auto" />
              <div>
                <p className="font-semibold text-foreground">Engineer Tier Required</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Crux staking is available for Engineer, Boss, and Elite tiers only.
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  You need <span className="font-mono font-bold text-primary">{(2000 - experience).toLocaleString()} more XP</span> to reach Engineer tier.
                </p>
              </div>
            </div>
          ) : !showStakeForm ? (
            <div className="text-center space-y-4">
              <p className="text-sm text-muted-foreground">
                Lock your Crux in our server staking pool for 6 months and earn {perks.stakingApy}% APY rewards.
              </p>
              <Button
                onClick={() => setShowStakeForm(true)}
                disabled={balance < 100}
                data-testid="button-start-stake"
              >
                <Lock className="w-4 h-4 mr-2" />
                Start Staking
              </Button>
              {balance < 100 && (
                <p className="text-xs text-muted-foreground">Minimum 100 Crux required to stake</p>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground block mb-2">Amount to Stake (Crux)</label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={stakeAmount}
                    onChange={(e) => setStakeAmount(e.target.value)}
                    placeholder="Enter amount in Crux"
                    className="font-mono"
                    min={100}
                    max={balance}
                    data-testid="input-stake-amount"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setStakeAmount(balance.toString())}
                    data-testid="button-stake-max"
                  >
                    Max
                  </Button>
                </div>
                {stakeAmountNum > balance && (
                  <p className="text-xs text-red-400 mt-1">Insufficient balance</p>
                )}
              </div>

              {stakeAmountNum >= 100 && stakeAmountNum <= balance && (
                <div className="bg-secondary/30 rounded-md p-4 space-y-3" data-testid="stake-preview">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Staking Preview</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">You stake</p>
                      <p className="font-mono font-bold text-foreground">{stakeAmountNum.toLocaleString()} Crux</p>
                      <p className="text-xs text-muted-foreground font-mono">{convertToUsd(stakeAmountNum)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Est. rewards (6 months)</p>
                      <p className="font-mono font-bold text-green-400">+{Math.floor(stakeAmountNum * (perks.stakingApy / 100) * (180 / 365)).toLocaleString()} Crux</p>
                    </div>
                  </div>
                  <div className="border-t border-border/30 pt-3 grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground">APY Rate</p>
                      <p className="font-mono font-bold text-primary">{perks.stakingApy}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Total after 6 months</p>
                      <p className="font-mono font-bold text-primary">{(stakeAmountNum + Math.floor(stakeAmountNum * (perks.stakingApy / 100) * (180 / 365))).toLocaleString()} Crux</p>
                    </div>
                  </div>
                  <div className="border-t border-border/30 pt-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Lock className="w-3 h-3 shrink-0" />
                      <span>Locked until {new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  onClick={() => stakeMutation.mutate()}
                  disabled={stakeMutation.isPending || stakeAmountNum < 100 || stakeAmountNum > balance}
                  data-testid="button-confirm-stake"
                >
                  {stakeMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Lock className="w-4 h-4 mr-2" />
                  )}
                  Confirm Stake
                </Button>
                <Button variant="outline" onClick={() => { setShowStakeForm(false); setStakeAmount(""); }}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {activeStakes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" />
              Active Stakes ({activeStakes.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {activeStakes.map((stake: any) => {
              const unlockDate = new Date(stake.unlocksAt);
              const stakedDate = new Date(stake.stakedAt);
              const now = new Date();
              const totalDays = 180;
              const daysElapsed = Math.floor((now.getTime() - stakedDate.getTime()) / (1000 * 60 * 60 * 24));
              const daysLeft = Math.max(0, Math.ceil((unlockDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
              const progress = Math.min(100, (daysElapsed / totalDays) * 100);
              const isUnlocked = now >= unlockDate;
              const stakedCrux = Number(stake.satoshiAmount);
              const accruedRewardsCrux = Math.floor(stakedCrux * (perks.stakingApy / 100) * (daysElapsed / 365));

              return (
                <div
                  key={stake.id}
                  className="border border-border/50 rounded-md p-4 space-y-3"
                  data-testid={`stake-active-${stake.id}`}
                >
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-primary" />
                      <span className="font-mono font-bold text-foreground">{stakedCrux.toLocaleString()} Crux</span>
                      <Badge variant="secondary" className="text-[10px]">
                        {perks.stakingApy}% APY
                      </Badge>
                    </div>
                    <Badge variant={isUnlocked ? "default" : "secondary"} className="text-[10px]">
                      {isUnlocked ? (
                        <><Unlock className="w-3 h-3 mr-1" /> Ready</>
                      ) : (
                        <><Clock className="w-3 h-3 mr-1" /> {daysLeft}d left</>
                      )}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-xs">
                    <div>
                      <p className="text-muted-foreground">Staked</p>
                      <p className="font-mono text-foreground">{stakedDate.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Unlocks</p>
                      <p className="font-mono text-foreground">{unlockDate.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Rewards accrued</p>
                      <p className="font-mono text-green-400">+{accruedRewardsCrux.toLocaleString()} Crux</p>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground mb-1">
                      <span>{daysElapsed} / {totalDays} days</span>
                      <span>{progress.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-1.5">
                      <div
                        className={`h-1.5 rounded-full transition-all ${isUnlocked ? "bg-green-500" : "bg-primary"}`}
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  {isUnlocked && (
                    <Button
                      size="sm"
                      onClick={() => withdrawMutation.mutate(stake.id)}
                      disabled={withdrawMutation.isPending}
                      data-testid={`button-withdraw-stake-${stake.id}`}
                    >
                      {withdrawMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Unlock className="w-4 h-4 mr-2" />
                      )}
                      Withdraw Crux + Rewards
                    </Button>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {pastStakes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Unlock className="w-5 h-5 text-muted-foreground" />
              Past Stakes ({pastStakes.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {pastStakes.map((stake: any) => (
                <div
                  key={stake.id}
                  className="flex items-center justify-between flex-wrap gap-2 border border-border/30 rounded-md p-3 text-sm"
                  data-testid={`stake-past-${stake.id}`}
                >
                  <div className="flex items-center gap-2">
                    <Unlock className="w-4 h-4 text-muted-foreground" />
                    <span className="font-mono text-muted-foreground">{Number(stake.satoshiAmount).toLocaleString()} Crux</span>
                    <Badge variant="outline" className="text-[10px]">Withdrawn</Badge>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {stake.withdrawnAt ? new Date(stake.withdrawnAt).toLocaleDateString() : "---"}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
