import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useUserDashboard } from "@/hooks/use-faucet";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { api } from "@shared/routes";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowUp, ArrowDown, Loader2, Shield, History } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import confetti from "canvas-confetti";

export default function HiLo() {
  const { data: dashboardData } = useUserDashboard();
  const { convertToUsd } = useBtcPrice();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [betAmount, setBetAmount] = useState("10");
  const [lastResult, setLastResult] = useState<{
    currentNumber: number;
    nextNumber: number;
    guess: string;
    won: boolean;
    betAmount: string;
    payout: string;
    multiplier: string;
    serverSeed: string;
    serverSeedHash: string;
    clientSeed: string;
    nonce: number;
  } | null>(null);

  const { data: history } = useQuery({
    queryKey: [api.hilo.history.path],
    queryFn: async () => {
      const res = await fetch(api.hilo.history.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch history");
      return res.json();
    },
  });

  const playMutation = useMutation({
    mutationFn: async (guess: "higher" | "lower") => {
      const res = await fetch(api.hilo.play.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ betAmount: parseInt(betAmount), guess }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to play");
      }
      return api.hilo.play.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      setLastResult(data);
      queryClient.invalidateQueries({ queryKey: [api.hilo.history.path] });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });

      if (data.won) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#06ffff", "#00ff88", "#ffffff"],
        });
        toast({
          title: "You Won!",
          description: `${data.currentNumber} -> ${data.nextNumber}. You won ${Number(data.payout).toLocaleString()} Crux! (${data.multiplier}x)`,
          className: "bg-primary text-primary-foreground border-none",
        });
      } else {
        toast({
          title: "You Lost",
          description: `${data.currentNumber} -> ${data.nextNumber}. Better luck next time!`,
          variant: "destructive",
        });
      }
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const balance = Number(dashboardData?.profile.balance || 0);
  const bet = parseInt(betAmount) || 0;

  const quickBets = [10, 50, 100, 500, 1000];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-bold font-display tracking-tight gradient-text-cyan-purple">Hi-Lo Game</h1>
        <p className="text-sm text-muted-foreground">Guess if the next number (1-100) will be higher or lower.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 items-start">
        <div className="space-y-5">
          <Card className="neon-card bg-card/80 p-6">
            <div className="text-center mb-6">
              <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">Your Balance</p>
              <p className="text-2xl font-bold font-mono text-foreground" data-testid="text-hilo-balance">
                {balance.toLocaleString()} Crux
              </p>
              <p className="text-xs text-muted-foreground font-mono">{convertToUsd(balance)}</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground mb-2 block">Bet Amount (Crux)</label>
                <Input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  min="1"
                  max={balance}
                  className="font-mono text-lg"
                  data-testid="input-bet-amount"
                />
                {bet > 0 && (
                  <p className="text-xs text-muted-foreground mt-1 font-mono">{convertToUsd(bet)}</p>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                {quickBets.map((qb) => (
                  <Button
                    key={qb}
                    variant="outline"
                    size="sm"
                    onClick={() => setBetAmount(qb.toString())}
                    disabled={qb > balance}
                    data-testid={`button-quickbet-${qb}`}
                  >
                    {qb.toLocaleString()}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setBetAmount(Math.floor(balance / 2).toString())}
                  disabled={balance < 2}
                >
                  Half
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setBetAmount(Math.floor(balance).toString())}
                  disabled={balance < 1}
                >
                  Max
                </Button>
              </div>
            </div>
          </Card>

          <Card className="neon-card bg-card/80 p-8 relative overflow-hidden flex flex-col items-center justify-center min-h-[280px]">
            <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-accent/5 pointer-events-none" />

            <AnimatePresence mode="wait">
              {lastResult ? (
                <motion.div
                  key={`result-${lastResult.nonce}`}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="relative z-10 text-center w-full"
                >
                  <div className="flex items-center justify-center gap-6 mb-6">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Was</p>
                      <div className="text-5xl font-mono font-bold text-muted-foreground">{lastResult.currentNumber}</div>
                    </div>
                    <div className={`text-3xl ${lastResult.won ? "text-green-400" : "text-red-400"}`}>
                      {lastResult.nextNumber > lastResult.currentNumber ? <ArrowUp /> : <ArrowDown />}
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Next</p>
                      <div className={`text-5xl font-mono font-bold ${lastResult.won ? "text-green-400" : "text-red-400"}`}>{lastResult.nextNumber}</div>
                    </div>
                  </div>
                  <p className={`text-lg font-bold ${lastResult.won ? "text-green-400" : "text-red-400"}`}>
                    {lastResult.won ? `Won ${Number(lastResult.payout).toLocaleString()} Crux (${lastResult.multiplier}x)` : `Lost ${Number(lastResult.betAmount).toLocaleString()} Crux`}
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="relative z-10 text-center"
                >
                  <div className="text-7xl font-mono font-bold text-muted/30 mb-4">?</div>
                  <p className="text-muted-foreground">Place your bet and guess!</p>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>

          <div className="grid grid-cols-2 gap-4">
            <Button
              size="lg"
              className="text-xl font-bold bg-green-600 text-white"
              onClick={() => playMutation.mutate("higher")}
              disabled={playMutation.isPending || bet < 1 || bet > balance}
              data-testid="button-higher"
            >
              {playMutation.isPending ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <>
                  <ArrowUp className="w-6 h-6 mr-2" />
                  HIGHER
                </>
              )}
            </Button>
            <Button
              size="lg"
              className="text-xl font-bold bg-red-600 text-white"
              onClick={() => playMutation.mutate("lower")}
              disabled={playMutation.isPending || bet < 1 || bet > balance}
              data-testid="button-lower"
            >
              {playMutation.isPending ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <>
                  <ArrowDown className="w-6 h-6 mr-2" />
                  LOWER
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <Card className="neon-card bg-card/80 p-5">
            <h3 className="font-display font-bold text-sm mb-3 text-foreground uppercase tracking-wider">How It Works</h3>
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>1. Set your bet amount in Crux</p>
              <p>2. A random number (1-100) is generated</p>
              <p>3. Guess if the next number will be Higher or Lower</p>
              <p>4. If you're right, you win your bet multiplied by the odds</p>
              <p>5. If you're wrong, you lose your bet to the house</p>
              <p className="text-primary font-medium mt-4">The riskier the guess, the higher the multiplier!</p>
            </div>
          </Card>

          {lastResult && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="neon-card bg-card/80 p-4 space-y-3"
            >
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Shield className="w-4 h-4 text-primary" />
                Provably Fair
              </div>
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Server Seed Hash:</span>
                  <p className="font-mono text-foreground/80 break-all">{lastResult.serverSeedHash.substring(0, 32)}...</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Client Seed:</span>
                  <p className="font-mono text-foreground/80">{lastResult.clientSeed}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Nonce:</span>
                  <p className="font-mono text-foreground/80">{lastResult.nonce}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Server Seed (Revealed):</span>
                  <p className="font-mono text-foreground/80 break-all">{lastResult.serverSeed.substring(0, 32)}...</p>
                </div>
              </div>
            </motion.div>
          )}

          {history && history.length > 0 && (
            <Card className="neon-card bg-card/80 p-4">
              <div className="flex items-center gap-2 mb-3">
                <History className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-display font-bold text-xs text-foreground uppercase tracking-wider">Recent Games</h3>
              </div>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {history.slice(0, 10).map((game: any) => (
                  <div key={game.id} className="flex items-center justify-between text-xs py-1.5 border-b border-border/20 last:border-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-muted-foreground">{game.currentNumber} {"\u2192"} {game.nextNumber}</span>
                      <span className={`font-medium ${game.won ? "text-green-400" : "text-red-400"}`}>
                        {game.guess === "higher" ? "Hi" : "Lo"}
                      </span>
                    </div>
                    <span className={`font-mono font-bold ${game.won ? "text-green-400" : "text-red-400"}`}>
                      {game.won ? `+${Number(game.payout).toLocaleString()}` : `-${Number(game.betAmount).toLocaleString()}`}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
