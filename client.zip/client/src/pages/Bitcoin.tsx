import { useQuery } from "@tanstack/react-query";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { useUserDashboard } from "@/hooks/use-faucet";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, ExternalLink, Coins } from "lucide-react";
import { motion } from "framer-motion";

interface CoinGeckoData {
  bitcoin: {
    usd: number;
    usd_24h_change: number;
    usd_24h_vol: number;
    usd_market_cap: number;
    last_updated_at: number;
  };
}

export default function Bitcoin() {
  const { convertToUsd } = useBtcPrice();
  const { data: dashboardData } = useUserDashboard();

  const { data: btcData, isLoading } = useQuery<CoinGeckoData>({
    queryKey: ["btc-detailed-price"],
    queryFn: async () => {
      const res = await fetch(
        "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_market_cap=true&include_last_updated_at=true"
      );
      if (!res.ok) throw new Error("Failed to fetch BTC price");
      return res.json();
    },
    refetchInterval: 30000,
    staleTime: 15000,
  });

  const btc = btcData?.bitcoin;
  const price = btc?.usd || 0;
  const change24h = btc?.usd_24h_change || 0;
  const volume = btc?.usd_24h_vol || 0;
  const marketCap = btc?.usd_market_cap || 0;
  const isPositive = change24h >= 0;

  const balanceSats = Number(dashboardData?.profile.balance || 0);

  const exchanges = [
    { name: "Coinbase", url: "https://www.coinbase.com/price/bitcoin", desc: "Most popular US exchange" },
    { name: "Binance", url: "https://www.binance.com/en/trade/BTC_USDT", desc: "Largest global exchange" },
    { name: "Kraken", url: "https://www.kraken.com/prices/bitcoin", desc: "Trusted since 2011" },
    { name: "Cash App", url: "https://cash.app/bitcoin", desc: "Easy mobile buying" },
    { name: "Strike", url: "https://strike.me/", desc: "Lightning Network focused" },
    { name: "River", url: "https://river.com/", desc: "Bitcoin-only exchange" },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div>
        <h1 className="text-3xl font-bold font-display text-foreground">Bitcoin</h1>
        <p className="text-muted-foreground">Live price, market data, and where to buy.</p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="bg-gradient-to-br from-card to-card/50 border-border/50 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-20 -mt-20" />
          <CardContent className="p-8 relative z-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">Bitcoin Price</p>
                {isLoading ? (
                  <div className="h-12 w-48 bg-secondary rounded animate-pulse" />
                ) : (
                  <div className="flex items-end gap-4 flex-wrap">
                    <h2 className="text-5xl font-bold font-mono text-foreground" data-testid="text-btc-price">
                      ${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </h2>
                    <div className={`flex items-center gap-1 text-lg font-medium ${isPositive ? "text-green-400" : "text-red-400"}`}>
                      {isPositive ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                      {isPositive ? "+" : ""}{change24h.toFixed(2)}%
                    </div>
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  {btc?.last_updated_at ? `Updated ${new Date(btc.last_updated_at * 1000).toLocaleTimeString()}` : ""}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <p className="text-sm text-muted-foreground">Your Balance</p>
                <p className="text-2xl font-bold font-mono text-primary">{balanceSats.toLocaleString()} Crux</p>
                <p className="text-sm text-muted-foreground font-mono">{convertToUsd(balanceSats)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="bg-card/50 border-border/50 p-6">
          <p className="text-sm text-muted-foreground mb-1">Market Cap</p>
          <p className="text-xl font-bold font-mono text-foreground">
            ${(marketCap / 1_000_000_000).toFixed(0)}B
          </p>
        </Card>
        <Card className="bg-card/50 border-border/50 p-6">
          <p className="text-sm text-muted-foreground mb-1">24h Volume</p>
          <p className="text-xl font-bold font-mono text-foreground">
            ${(volume / 1_000_000_000).toFixed(1)}B
          </p>
        </Card>
        <Card className="bg-card/50 border-border/50 p-6">
          <p className="text-sm text-muted-foreground mb-1">Crux per $1</p>
          <p className="text-xl font-bold font-mono text-foreground">
            {price > 0 ? Math.floor(100_000_000 / price).toLocaleString() : "---"}
          </p>
        </Card>
      </div>

      <div>
        <h2 className="text-xl font-bold font-display mb-4">Buy Bitcoin</h2>
        <p className="text-muted-foreground text-sm mb-6">
          Ready to buy real Bitcoin? Here are trusted exchanges where you can purchase BTC with USD, EUR, and other currencies.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {exchanges.map((exchange) => (
            <motion.div
              key={exchange.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="bg-card/50 border-border/50 p-5 hover:border-primary/30 transition-colors group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center">
                      <Coins className="w-4 h-4 text-primary" />
                    </div>
                    <h3 className="font-bold text-foreground">{exchange.name}</h3>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-4">{exchange.desc}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => window.open(exchange.url, "_blank")}
                  data-testid={`button-exchange-${exchange.name.toLowerCase()}`}
                >
                  Visit Exchange
                  <ExternalLink className="w-3 h-3 ml-2" />
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Card className="bg-primary/5 border-primary/20 p-6">
        <h3 className="font-bold text-foreground mb-2">New to Bitcoin?</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Bitcoin is the world's first cryptocurrency. 1 Bitcoin = 100,000,000 Crux. 
          You can earn free Crux using our faucet and Hi-Lo game, then learn about buying real Bitcoin 
          when you're ready. Always do your own research before investing.
        </p>
      </Card>
    </div>
  );
}
