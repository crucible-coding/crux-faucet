import { useState } from "react";
import { useUserDashboard } from "@/hooks/use-faucet";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { api } from "@shared/routes";
import { SUPPORTED_CRYPTOS, getUserTier } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Wallet as WalletIcon, ArrowUpRight, Copy, Lock, AlertTriangle, TrendingUp, Shield, Clock, Activity, Unlock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const MIN_WITHDRAW_USD = 20;
const UPSELL_THRESHOLD_USD = 19;

const MODE_CONFIG: Record<string, { label: string; color: string; bg: string; border: string }> = {
  healthy: { label: "Healthy", color: "text-green-400", bg: "bg-green-500/10", border: "border-green-500/30" },
  caution: { label: "Caution", color: "text-yellow-400", bg: "bg-yellow-500/10", border: "border-yellow-500/30" },
  protection: { label: "Protection", color: "text-orange-400", bg: "bg-orange-500/10", border: "border-orange-500/30" },
  emergency: { label: "Slow Mode", color: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/30" },
};

export default function Wallet() {
  const { data, isLoading } = useUserDashboard();
  const { convertToUsd, btcPrice } = useBtcPrice();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedCrypto, setSelectedCrypto] = useState<string | null>(null);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawAddress, setWithdrawAddress] = useState("");

  const { data: cryptoWallets } = useQuery({
    queryKey: [api.cryptoWallets.list.path],
  });

  const { data: withdrawStatus } = useQuery<any>({
    queryKey: [api.wallet.withdrawStatus.path],
  });

  const { data: liquidityStatus } = useQuery<any>({
    queryKey: [api.liquidity.status.path],
  });

  const balanceSats = Number(data?.profile.balance || 0);
  const balanceBtc = balanceSats / 100_000_000;
  const walletAddress = data?.profile.walletAddress || "Generating...";

  const userTier = data?.profile ? getUserTier(data.profile.experience) : null;
  const isFreeTier = userTier?.name === "Apprentice";

  const spendable = withdrawStatus?.spendableBalance || 0;
  const locked = withdrawStatus?.lockedBalance || 0;
  const spendablePercent = balanceSats > 0 ? Math.min(100, (spendable / balanceSats) * 100) : 0;
  const sysMode = liquidityStatus?.mode || "healthy";
  const modeInfo = MODE_CONFIG[sysMode] || MODE_CONFIG.healthy;

  const withdrawMutation = useMutation({
    mutationFn: async () => {
      if (!selectedCrypto) throw new Error("Select a crypto wallet");
      const amount = parseInt(withdrawAmount);
      const res = await apiRequest("POST", api.wallet.withdraw.path, {
        amount,
        btcAddress: withdrawAddress,
      });
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Withdrawal Submitted", description: data.message });
      setSelectedCrypto(null);
      setWithdrawAmount("");
      setWithdrawAddress("");
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
      queryClient.invalidateQueries({ queryKey: [api.cryptoWallets.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.wallet.withdrawStatus.path] });
    },
    onError: (err: any) => {
      toast({ title: "Withdrawal Failed", description: err.message, variant: "destructive" });
    },
  });

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    toast({ title: "Copied", description: "Wallet address copied to clipboard." });
  };

  const getWalletBalance = (currencyId: string): string => {
    if (!cryptoWallets) return "0";
    const wallet = (cryptoWallets as any[]).find((w: any) => w.currency === currencyId);
    return wallet?.balance || "0";
  };

  const getWalletUsd = (currencyId: string): number => {
    const bal = parseFloat(getWalletBalance(currencyId));
    if (btcPrice <= 0) return 0;
    return (bal / 100_000_000) * btcPrice;
  };

  const withdrawAmountNum = parseInt(withdrawAmount) || 0;

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground">Wallet</h1>
          <p className="text-muted-foreground">Loading your wallet...</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <Skeleton className="h-56 rounded-lg" />
          <Skeleton className="h-56 rounded-lg" />
        </div>
        <Skeleton className="h-64 rounded-lg" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-display text-foreground">Wallet</h1>
        <p className="text-muted-foreground">Manage your crypto savings and withdrawals.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-primary/10 border-primary/20">
          <CardHeader>
            <CardTitle className="text-primary flex items-center gap-2">
              <WalletIcon className="w-5 h-5" /> Total Crux Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold font-mono text-foreground" data-testid="text-wallet-balance">
              {balanceSats.toLocaleString()} Crux
            </div>
            <div className="mt-2 space-y-1">
              <p className="text-sm text-primary font-mono font-bold">{convertToUsd(balanceSats)}</p>
              <p className="text-xs text-muted-foreground font-mono">{balanceBtc.toFixed(8)} BTC</p>
            </div>

            {withdrawStatus && (
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 text-green-400">
                    <Unlock className="w-3 h-3" /> Spendable
                  </span>
                  <span className="font-mono text-green-400">{spendable.toLocaleString()} Crux</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 text-yellow-400">
                    <Lock className="w-3 h-3" /> Vesting
                  </span>
                  <span className="font-mono text-yellow-400">{locked.toLocaleString()} Crux</span>
                </div>
                <div className="w-full bg-secondary rounded-full h-2 mt-1">
                  <div
                    className="h-2 rounded-full bg-green-500 transition-all"
                    style={{ width: `${spendablePercent}%` }}
                  />
                </div>
                <p className="text-[10px] text-muted-foreground text-right">
                  {spendablePercent.toFixed(0)}% unlocked — 20% per day
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Your Deposit Address</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="bg-secondary/50 rounded-lg p-3">
                <p className="text-xs text-muted-foreground mb-1">Wallet Address</p>
                <p className="font-mono text-xs text-foreground break-all" data-testid="text-wallet-address">{walletAddress}</p>
              </div>
              <Button variant="outline" size="sm" onClick={handleCopyAddress} className="w-full" data-testid="button-copy-address">
                <Copy className="w-3 h-3 mr-2" />
                Copy Address
              </Button>
            </CardContent>
          </Card>

          {liquidityStatus && (
            <Card className={`${modeInfo.border} border`}>
              <CardContent className="pt-4 pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className={`w-4 h-4 ${modeInfo.color}`} />
                    <span className={`text-sm font-medium ${modeInfo.color}`}>System: {modeInfo.label}</span>
                  </div>
                  <span className={`text-xs font-mono px-2 py-0.5 rounded ${modeInfo.bg} ${modeInfo.color}`} data-testid="text-reward-multiplier">
                    Rewards {liquidityStatus.rewardMultiplier}
                  </span>
                </div>
                {withdrawStatus?.cooldownMinutesRemaining > 0 && (
                  <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    Withdrawal cooldown: {withdrawStatus.cooldownMinutesRemaining} min remaining
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <WalletIcon className="w-5 h-5" />
            Crypto Wallets
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Each crypto wallet needs $20.00 USD to unlock withdrawal. Select a wallet below to cash out.
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-4">
            {SUPPORTED_CRYPTOS.map((crypto) => {
              const bal = getWalletBalance(crypto.id);
              const balNum = parseFloat(bal);
              const walletUsd = getWalletUsd(crypto.id);
              const progress = Math.min(100, (walletUsd / MIN_WITHDRAW_USD) * 100);
              const canWithdrawThis = walletUsd >= MIN_WITHDRAW_USD;
              const nearThreshold = walletUsd >= UPSELL_THRESHOLD_USD && walletUsd < MIN_WITHDRAW_USD;
              const isSelected = selectedCrypto === crypto.id;

              return (
                <div
                  key={crypto.id}
                  className={`rounded-lg p-4 border space-y-3 cursor-pointer transition-colors ${
                    isSelected
                      ? "border-primary bg-primary/5"
                      : "border-border/30 bg-secondary/30 hover-elevate"
                  }`}
                  onClick={() => setSelectedCrypto(isSelected ? null : crypto.id)}
                  data-testid={`wallet-card-${crypto.id}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: crypto.color }}
                      />
                      <span className="text-sm font-bold text-foreground">{crypto.symbol}</span>
                    </div>
                    {canWithdrawThis && (
                      <ArrowUpRight className="w-4 h-4 text-green-500" />
                    )}
                    {nearThreshold && (
                      <TrendingUp className="w-4 h-4 text-yellow-500" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{crypto.name}</p>
                  <p className="text-lg font-mono font-bold text-foreground" data-testid={`wallet-balance-${crypto.id}`}>
                    {balNum > 0 ? balNum.toLocaleString() : "0"} Crux
                  </p>
                  <p className="text-xs text-muted-foreground font-mono">
                    ~${walletUsd.toFixed(2)} USD
                  </p>

                  <div className="w-full bg-secondary rounded-full h-1.5">
                    <div
                      className={`h-1.5 rounded-full transition-all ${canWithdrawThis ? "bg-green-500" : "bg-primary"}`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground">
                    {canWithdrawThis
                      ? "Ready to withdraw"
                      : `$${walletUsd.toFixed(2)} / $${MIN_WITHDRAW_USD}.00`
                    }
                  </p>

                  {nearThreshold && isFreeTier && (
                    <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-md p-2 mt-1">
                      <p className="text-[11px] text-yellow-500 font-medium">
                        Almost at $20! Purchase at least Journeyman rank to unlock cash out.
                      </p>
                      <Link href="/ranks">
                        <Button variant="outline" size="sm" className="mt-1 w-full text-xs border-yellow-500/30 text-yellow-500" data-testid={`button-upgrade-${crypto.id}`}>
                          View Ranks
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {selectedCrypto && (
        <Card className="border-primary/30">
          <CardHeader>
            <CardTitle className="flex items-center justify-between flex-wrap gap-2">
              <span className="flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5" />
                Withdraw {SUPPORTED_CRYPTOS.find(c => c.id === selectedCrypto)?.symbol}
              </span>
              {(() => {
                const walletUsd = getWalletUsd(selectedCrypto);
                if (walletUsd < MIN_WITHDRAW_USD) {
                  return (
                    <span className="text-xs font-normal text-muted-foreground flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Need ${MIN_WITHDRAW_USD}.00 in this wallet
                    </span>
                  );
                }
                return null;
              })()}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const walletUsd = getWalletUsd(selectedCrypto);
              const cryptoBal = parseFloat(getWalletBalance(selectedCrypto));
              const canWithdrawThis = walletUsd >= MIN_WITHDRAW_USD;
              const nearThreshold = walletUsd >= UPSELL_THRESHOLD_USD && walletUsd < MIN_WITHDRAW_USD;

              if (!canWithdrawThis) {
                return (
                  <div className="bg-secondary/30 rounded-xl p-6 text-center space-y-3">
                    {nearThreshold ? (
                      <>
                        <TrendingUp className="w-10 h-10 text-yellow-500 mx-auto" />
                        <h3 className="font-bold text-foreground">Almost Ready to Cash Out!</h3>
                        <p className="text-sm text-muted-foreground">
                          Your {SUPPORTED_CRYPTOS.find(c => c.id === selectedCrypto)?.symbol} wallet is at <span className="text-primary font-bold">${walletUsd.toFixed(2)}</span>. 
                          You need <span className="font-bold text-foreground">${(MIN_WITHDRAW_USD - walletUsd).toFixed(2)} more</span> to reach the $20 minimum.
                        </p>
                        {isFreeTier && (
                          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 mt-2">
                            <Shield className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
                            <p className="text-sm font-medium text-yellow-500 mb-2">
                              To cash out, you need at least the Journeyman rank. Purchase a rank now so you're ready when you hit $20!
                            </p>
                            <Link href="/ranks">
                              <Button size="sm" className="mt-1" data-testid="button-upgrade-rank">
                                View Ranks & Pricing
                              </Button>
                            </Link>
                          </div>
                        )}
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-10 h-10 text-yellow-500 mx-auto" />
                        <h3 className="font-bold text-foreground">Withdrawal Locked</h3>
                        <p className="text-sm text-muted-foreground">
                          You need at least <span className="text-primary font-bold">${MIN_WITHDRAW_USD}.00 USD</span> in this wallet to cash out.
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Current value: <span className="font-mono font-bold text-foreground">${walletUsd.toFixed(2)}</span>
                        </p>
                      </>
                    )}
                    <div className="w-full bg-secondary rounded-full h-2 mt-4">
                      <div
                        className={`h-2 rounded-full transition-all ${nearThreshold ? "bg-yellow-500" : "bg-primary"}`}
                        style={{ width: `${Math.min(100, (walletUsd / MIN_WITHDRAW_USD) * 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {((walletUsd / MIN_WITHDRAW_USD) * 100).toFixed(1)}% of minimum reached
                    </p>
                  </div>
                );
              }

              const maxWithdrawable = Math.min(cryptoBal, spendable, withdrawStatus?.tierLimit || cryptoBal);

              return (
                <div className="space-y-4">
                  <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 text-sm text-green-500 flex items-center gap-2">
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                    Your {SUPPORTED_CRYPTOS.find(c => c.id === selectedCrypto)?.symbol} wallet has ${walletUsd.toFixed(2)} USD available ({cryptoBal.toLocaleString()} Crux)
                  </div>

                  {withdrawStatus && spendable < cryptoBal && (
                    <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 text-xs text-yellow-500 flex items-center gap-2">
                      <Lock className="w-4 h-4 shrink-0" />
                      <span>
                        <strong>{spendable.toLocaleString()}</strong> Crux unlocked for withdrawal.
                        <strong> {locked.toLocaleString()}</strong> still vesting (20% unlocks daily).
                      </span>
                    </div>
                  )}

                  {withdrawStatus?.cooldownMinutesRemaining > 0 && (
                    <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-3 text-xs text-orange-400 flex items-center gap-2">
                      <Clock className="w-4 h-4 shrink-0" />
                      Cooldown active — {withdrawStatus.cooldownMinutesRemaining} minutes remaining before next withdrawal.
                    </div>
                  )}

                  <div>
                    <label className="text-sm font-medium text-muted-foreground block mb-2">Amount (Crux)</label>
                    <Input
                      type="number"
                      value={withdrawAmount}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWithdrawAmount(e.target.value)}
                      placeholder={`Max: ${maxWithdrawable.toLocaleString()} Crux`}
                      className="font-mono"
                      max={maxWithdrawable}
                      data-testid="input-withdraw-amount"
                    />
                    <div className="flex gap-2 mt-2 flex-wrap">
                      <Button variant="outline" size="sm" onClick={() => setWithdrawAmount(Math.floor(maxWithdrawable * 0.25).toString())} data-testid="button-withdraw-25">25%</Button>
                      <Button variant="outline" size="sm" onClick={() => setWithdrawAmount(Math.floor(maxWithdrawable * 0.5).toString())} data-testid="button-withdraw-50">50%</Button>
                      <Button variant="outline" size="sm" onClick={() => setWithdrawAmount(Math.floor(maxWithdrawable * 0.75).toString())} data-testid="button-withdraw-75">75%</Button>
                      <Button variant="outline" size="sm" onClick={() => setWithdrawAmount(Math.floor(maxWithdrawable).toString())} data-testid="button-withdraw-max">MAX</Button>
                    </div>
                    {withdrawAmountNum > 0 && (
                      <p className="text-xs text-muted-foreground mt-2 font-mono">{convertToUsd(withdrawAmountNum)} (1-5% sliding fee applies)</p>
                    )}
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground block mb-2">Wallet Address</label>
                    <Input
                      value={withdrawAddress}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWithdrawAddress(e.target.value)}
                      placeholder={`Enter your ${SUPPORTED_CRYPTOS.find(c => c.id === selectedCrypto)?.symbol} wallet address`}
                      className="font-mono"
                      data-testid="input-withdraw-address"
                    />
                  </div>
                  <div className="flex gap-3 flex-wrap">
                    <Button
                      onClick={() => withdrawMutation.mutate()}
                      disabled={
                        withdrawMutation.isPending ||
                        withdrawAmountNum < 1 ||
                        !withdrawAddress ||
                        (withdrawStatus && !withdrawStatus.canWithdraw) ||
                        withdrawAmountNum > maxWithdrawable
                      }
                      data-testid="button-submit-withdraw"
                    >
                      <ArrowUpRight className="w-4 h-4 mr-2" />
                      {withdrawMutation.isPending ? "Processing..." : `Withdraw ${SUPPORTED_CRYPTOS.find(c => c.id === selectedCrypto)?.symbol}`}
                    </Button>
                    <Button variant="outline" onClick={() => setSelectedCrypto(null)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              );
            })()}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border border-border/50">
            <div className="p-4 bg-secondary/30 grid grid-cols-4 font-medium text-sm text-muted-foreground">
              <div>Type</div>
              <div>Amount</div>
              <div>Status</div>
              <div className="text-right">Date</div>
            </div>
            <div className="divide-y divide-border/30">
              {data?.transactions && data.transactions.length > 0 ? (
                data.transactions.map((tx) => (
                  <div key={tx.id} className="p-4 grid grid-cols-4 items-center text-sm">
                    <div className="capitalize">{tx.type.replace(/_/g, ' ')}</div>
                    <div>
                      <div className={`font-mono font-medium ${tx.type.includes('loss') || tx.type === 'withdraw' ? 'text-red-400' : 'text-green-400'}`}>
                        {tx.type.includes('loss') || tx.type === 'withdraw' ? '-' : '+'}{Number(tx.amount).toLocaleString()} Crux
                      </div>
                      <div className="text-xs text-muted-foreground font-mono">{convertToUsd(Number(tx.amount))}</div>
                    </div>
                    <div>
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-500/10 text-green-500">
                        Completed
                      </span>
                    </div>
                    <div className="text-right text-muted-foreground">
                      {new Date(tx.createdAt || Date.now()).toLocaleDateString()}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-muted-foreground">No transactions found</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
