import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { USER_TIERS, CHAT_COLOR_PRESETS, canUseCustomChatColor, getUserTier } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useUserDashboard } from "@/hooks/use-faucet";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Send, MessageCircle, Users, Palette, X, Check, Lock, Crown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

function TierBadge({ tierName, small }: { tierName: string; small?: boolean }) {
  const tier = USER_TIERS.find(t => t.name === tierName) || USER_TIERS[0];
  const idx = USER_TIERS.findIndex(t => t.name === tierName);

  const baseClasses = small
    ? "text-[10px] font-bold px-1.5 py-0.5 rounded-md inline-flex items-center"
    : "text-xs font-bold px-2 py-0.5 rounded-md inline-flex items-center";

  if (idx >= 5) {
    return (
      <span
        className={`${baseClasses} tier-badge-rainbow`}
        style={{ backgroundColor: tier.color + "20" }}
      >
        {tier.name}
      </span>
    );
  }
  if (idx === 4) {
    return (
      <span
        className={`${baseClasses} tier-badge-glow`}
        style={{
          color: tier.color,
          backgroundColor: tier.color + "20",
          textShadow: `0 0 8px ${tier.color}80`,
        }}
      >
        {tier.name}
      </span>
    );
  }
  if (idx === 3) {
    return (
      <span
        className={`${baseClasses} tier-badge-gradient`}
        style={{
          background: tier.gradient || tier.color + "20",
          WebkitBackgroundClip: tier.gradient ? "text" : undefined,
          WebkitTextFillColor: tier.gradient ? "transparent" : undefined,
          backgroundColor: tier.gradient ? tier.color + "15" : undefined,
        }}
      >
        <span
          style={tier.gradient ? {
            background: tier.gradient,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          } : { color: tier.color }}
        >
          {tier.name}
        </span>
      </span>
    );
  }

  return (
    <span
      className={baseClasses}
      style={{ color: tier.color, backgroundColor: tier.color + "15" }}
    >
      {tier.name}
    </span>
  );
}

function StyledUsername({ username, tierName, chatColor }: { username: string; tierName: string; chatColor?: string | null }) {
  const tier = USER_TIERS.find(t => t.name === tierName) || USER_TIERS[0];
  const displayColor = chatColor || undefined;

  switch (tier.fontStyle) {
    case "rainbow":
      return (
        <span
          className={`text-xs font-bold ${displayColor ? "" : "tier-text-rainbow"}`}
          style={displayColor ? { color: displayColor, textShadow: `0 0 6px ${displayColor}40` } : undefined}
          data-testid="text-username-rainbow"
        >
          {username}
        </span>
      );
    case "glow":
      return (
        <span
          className="text-xs font-bold"
          style={{
            color: displayColor || tier.color,
            textShadow: `0 0 8px ${displayColor || tier.color}60`,
          }}
          data-testid="text-username-glow"
        >
          {username}
        </span>
      );
    case "italic-bold":
      return (
        <span
          className="text-xs font-bold italic"
          style={{ color: displayColor || tier.color }}
          data-testid="text-username-italic"
        >
          {username}
        </span>
      );
    case "bold":
      return (
        <span className="text-xs font-bold text-foreground" data-testid="text-username-bold">
          {username}
        </span>
      );
    default:
      return (
        <span className="text-xs font-medium text-foreground" data-testid="text-username-normal">
          {username}
        </span>
      );
  }
}

export default function Chat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [showColorPicker, setShowColorPicker] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const { data: dashboardData } = useUserDashboard();
  const profile = dashboardData?.profile;
  const experience = profile?.experience || 0;
  const currentTier = getUserTier(experience);
  const tierDef = USER_TIERS.find(t => t.name === currentTier.name) || USER_TIERS[0];
  const canPickColor = canUseCustomChatColor(currentTier.name);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: [api.chat.messages.path],
    queryFn: async () => {
      const res = await fetch(api.chat.messages.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch messages");
      return res.json();
    },
    refetchInterval: 3000,
  });

  const sendMutation = useMutation({
    mutationFn: async (msg: string) => {
      const res = await fetch(api.chat.send.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ message: msg }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({ queryKey: [api.chat.messages.path] });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const colorMutation = useMutation({
    mutationFn: async (color: string) => {
      const res = await fetch(api.chatColor.update.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ color }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Color Updated", description: data.message });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
      setShowColorPicker(false);
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    const trimmed = message.trim();
    if (!trimmed) return;
    sendMutation.mutate(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const uniqueUsers = new Set(messages.map((m: any) => m.userId)).size;

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[calc(100vh-120px)]">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div>
          <h1 className="text-3xl font-bold font-display text-foreground flex items-center gap-3">
            <MessageCircle className="w-8 h-8 text-primary" />
            Chat
          </h1>
          <p className="text-muted-foreground text-sm">Talk with other Crux Faucet users</p>
        </div>
        <div className="flex items-center gap-3">
          {canPickColor && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowColorPicker(!showColorPicker)}
              data-testid="button-toggle-color-picker"
            >
              <Palette className="w-4 h-4 mr-1" />
              Chat Color
            </Button>
          )}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="w-4 h-4" />
            <span data-testid="text-user-count">{uniqueUsers} user{uniqueUsers !== 1 ? "s" : ""} chatting</span>
          </div>
        </div>
      </div>

      <div className="mb-3 flex flex-wrap gap-2 items-center">
        {USER_TIERS.map(tier => (
          <TierBadge key={tier.name} tierName={tier.name} small />
        ))}
      </div>

      {showColorPicker && canPickColor && (
        <Card className="mb-3 p-4 border-border/50 bg-card/80">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-bold text-foreground">Choose your chat message color</p>
            <Button variant="ghost" size="icon" onClick={() => setShowColorPicker(false)} data-testid="button-close-color-picker">
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {CHAT_COLOR_PRESETS.map(color => (
              <button
                type="button"
                key={color}
                className="w-8 h-8 rounded-md border-2 transition-transform hover:scale-110 flex items-center justify-center"
                style={{
                  backgroundColor: color,
                  borderColor: profile?.chatColor === color ? "#ffffff" : "transparent",
                }}
                onClick={() => colorMutation.mutate(color)}
                aria-label={`Select chat color ${color}${profile?.chatColor === color ? " (selected)" : ""}`}
                aria-pressed={profile?.chatColor === color}
                data-testid={`button-color-${color.replace("#", "")}`}
              >
                {profile?.chatColor === color && (
                  <>
                    <Check className="w-4 h-4 text-black" />
                    <span className="sr-only">Selected</span>
                  </>
                )}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Current: <span style={{ color: profile?.chatColor || currentTier.color }}>{profile?.chatColor || "Default tier color"}</span>
          </p>
        </Card>
      )}

      <Card className="flex-1 flex flex-col overflow-hidden border-border/50 bg-card/50">
        <div
          ref={scrollContainerRef}
          className="flex-1 overflow-y-auto p-4 space-y-3"
          data-testid="chat-messages-container"
        >
          {isLoading ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              Loading messages...
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground space-y-2">
              <MessageCircle className="w-12 h-12 opacity-20" />
              <p>No messages yet. Be the first to say something!</p>
            </div>
          ) : (
            messages.map((msg: any) => {
              const isOwn = msg.userId === user?.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isOwn ? "items-end" : "items-start"}`}
                  data-testid={`chat-message-${msg.id}`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <TierBadge tierName={msg.tier} small />
                    <StyledUsername username={msg.username} tierName={msg.tier} chatColor={msg.chatColor} />
                    <span className="text-xs text-muted-foreground">
                      {new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                  <div
                    className={`rounded-2xl px-4 py-2.5 max-w-[80%] text-sm break-words ${
                      isOwn
                        ? "bg-primary/15 rounded-tr-sm"
                        : "bg-secondary/50 rounded-tl-sm"
                    }`}
                    style={msg.chatColor ? { color: msg.chatColor } : undefined}
                  >
                    {msg.message}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-border/50 p-4 bg-background/30">
          <div className="flex gap-3">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value.slice(0, tierDef.maxMessageLength))}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              maxLength={tierDef.maxMessageLength}
              className="flex-1"
              data-testid="input-chat-message"
            />
            <Button
              onClick={handleSend}
              disabled={sendMutation.isPending || !message.trim()}
              data-testid="button-send-message"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex items-center justify-between mt-2 flex-wrap gap-1">
            <div className="flex items-center gap-2">
              <p className="text-xs text-muted-foreground">{message.length}/{tierDef.maxMessageLength} chars</p>
              {!tierDef.canSendLinks && (
                <span className="text-[10px] text-muted-foreground/60 flex items-center gap-0.5">
                  <Lock className="w-2.5 h-2.5" /> Links locked
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              {canPickColor && profile?.chatColor && (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: profile.chatColor }} />
                  Custom color
                </div>
              )}
              <Badge
                variant="outline"
                className="text-[9px] h-4 px-1.5 py-0 no-default-hover-elevate no-default-active-elevate"
                style={{ borderColor: currentTier.color + "40", color: currentTier.color }}
              >
                {currentTier.name}
              </Badge>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
