import { useUserDashboard } from "@/hooks/use-faucet";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { getUserTier, getNextTier, USER_TIERS, getTierPerks } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUpRight, ArrowDownLeft, Clock, Coins, Activity, Shield, Zap, Gift, Flame, Star, Crown, Palette, Timer, Award, Trophy, CheckCircle, Lock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { SiEthereum } from "react-icons/si";

function TierBadgeLarge({ tierName }: { tierName: string }) {
  const tier = USER_TIERS.find(t => t.name === tierName) || USER_TIERS[0];
  const idx = USER_TIERS.findIndex(t => t.name === tierName);

  const baseClasses = "text-sm font-bold px-3 py-1 rounded-md inline-flex items-center gap-1.5";

  if (idx >= 5) {
    return (
      <span className={`${baseClasses} tier-badge-rainbow`} style={{ backgroundColor: tier.color + "20" }}>
        <Crown className="w-4 h-4" />
        {tier.name}
      </span>
    );
  }
  if (idx === 4) {
    return (
      <span
        className={`${baseClasses} tier-badge-glow`}
        style={{ color: tier.color, backgroundColor: tier.color + "20", textShadow: `0 0 8px ${tier.color}80` }}
      >
        <Star className="w-4 h-4" />
        {tier.name}
      </span>
    );
  }
  if (idx === 3) {
    return (
      <span className={`${baseClasses}`} style={{ backgroundColor: tier.color + "15" }}>
        <span style={{ background: tier.gradient || undefined, WebkitBackgroundClip: tier.gradient ? "text" : undefined, WebkitTextFillColor: tier.gradient ? "transparent" : undefined, color: tier.gradient ? undefined : tier.color }}>
          {tier.name}
        </span>
      </span>
    );
  }

  return (
    <span className={baseClasses} style={{ color: tier.color, backgroundColor: tier.color + "15" }}>
      <Shield className="w-4 h-4" />
      {tier.name}
    </span>
  );
}

function PerkItem({ icon: Icon, label, value, highlight }: { icon: any; label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Icon className="w-3.5 h-3.5" />
        <span>{label}</span>
      </div>
      <span className={`text-sm font-mono font-medium ${highlight ? "text-primary" : "text-foreground"}`}>{value}</span>
    </div>
  );
}

const PAST_RAFFLE_WINNERS = [
  { name: "Marcus T.", tier: "Elite", date: "Jul 2025", ethPrice: "$3,842" },
  { name: "Jessica K.", tier: "Boss", date: "Jan 2025", ethPrice: "$3,215" },
  { name: "Devon R.", tier: "Engineer", date: "Jul 2024", ethPrice: "$2,987" },
];

const tierColors: Record<string, string> = {
  Apprentice: "#94a3b8", Journeyman: "#22c55e", Foreman: "#3b82f6",
  Engineer: "#a855f7", Boss: "#f59e0b", Elite: "#ef4444",
};

function DashboardRaffleBanner({ isSubscribed }: { isSubscribed: boolean }) {
  const now = new Date();
  const year = now.getFullYear();
  const jul = new Date(year, 6, 1);
  const nextDate = now < jul ? jul : new Date(year + 1, 0, 1);
  const daysLeft = Math.max(0, Math.ceil((nextDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <Card className="neon-card overflow-visible" data-testid="dashboard-raffle-banner">
      <div className="p-5 space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-[#627eea]/15 border border-[#627eea]/30 flex items-center justify-center shrink-0">
              <SiEthereum className="w-5 h-5 text-[#627eea]" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">1 ETH Raffle</p>
              <p className="text-xs text-muted-foreground">
                {isSubscribed ? (
                  <span className="text-green-400 font-medium">You're entered!</span>
                ) : (
                  "Subscribe to any rank to enter"
                )}
                {" \u00b7 "}<span className="font-mono font-bold text-foreground">{daysLeft}</span> days left
              </p>
            </div>
          </div>
          {isSubscribed ? (
            <Badge className="bg-green-500/15 text-green-400 border-green-500/30 no-default-hover-elevate no-default-active-elevate text-[10px]">
              <CheckCircle className="w-3 h-3 mr-1" /> Entered
            </Badge>
          ) : (
            <Badge variant="outline" className="border-[#627eea]/30 text-[#627eea] no-default-hover-elevate no-default-active-elevate text-[10px]">
              <Lock className="w-3 h-3 mr-1" /> Not Entered
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-2 mb-1">
          <Trophy className="w-3 h-3 text-yellow-500" />
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Recent Winners</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {PAST_RAFFLE_WINNERS.map((winner, i) => (
            <div key={i} className="flex items-center gap-2 rounded-md bg-background/40 border border-border/20 px-2.5 py-1.5">
              <div className="w-5 h-5 rounded-full bg-[#627eea]/15 flex items-center justify-center shrink-0">
                <SiEthereum className="w-2.5 h-2.5 text-[#627eea]" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[11px] font-bold text-foreground truncate">{winner.name}</p>
                <p className="text-[9px] text-muted-foreground">{winner.date} · {winner.ethPrice}</p>
              </div>
              <Badge
                variant="outline"
                className="text-[7px] px-1 py-0 h-3 no-default-hover-elevate no-default-active-elevate shrink-0"
                style={{ borderColor: (tierColors[winner.tier] || "#94a3b8") + "40", color: tierColors[winner.tier] || "#94a3b8" }}
              >
                {winner.tier}
              </Badge>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

export default function Dashboard() {
  const { data, isLoading } = useUserDashboard();
  const { convertToUsd } = useBtcPrice();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: dailyStatus } = useQuery({
    queryKey: [api.dailyBonus.status.path],
    queryFn: async () => {
      const res = await fetch(api.dailyBonus.status.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const { data: rankStatus } = useQuery<{ hasSubscription: boolean; subscribedTier: string | null }>({
    queryKey: [api.ranks.status.path],
  });

  const claimDailyMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.dailyBonus.claim.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Daily Bonus!", description: data.message });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
      queryClient.invalidateQueries({ queryKey: [api.dailyBonus.status.path] });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  if (isLoading) return <DashboardSkeleton />;

  const profile = data?.profile;
  const transactions = data?.transactions || [];
  const balanceSats = Number(profile?.balance || 0);
  const experience = profile?.experience || 0;
  const tier = getUserTier(experience);
  const nextTier = getNextTier(experience);
  const perks = getTierPerks(tier.name);
  const streak = profile?.hiloStreak || 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
        <div>
          <h1 className="text-2xl font-bold font-display tracking-tight text-foreground" data-testid="text-dashboard-title">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Welcome back. Here's your activity overview.</p>
        </div>
        <TierBadgeLarge tierName={tier.name} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Balance"
          value={`${balanceSats.toLocaleString()}`}
          unit="Crux"
          subtitle={convertToUsd(balanceSats)}
          icon={Coins}
          accentColor="from-primary/20 to-primary/5"
          iconColor="text-primary"
        />
        <StatCard
          title="Current Tier"
          value={tier.name}
          subtitle={`${experience.toLocaleString()} XP`}
          icon={Shield}
          accentColor="from-yellow-500/20 to-yellow-500/5"
          iconColor="text-yellow-500"
          valueColor={tier.color}
        />
        <StatCard
          title="Win Streak"
          value={streak.toString()}
          subtitle={streak >= 3 && perks.streakBonus > 0 ? `+${perks.streakBonus}% bonus` : "Win 3+ in a row"}
          icon={Flame}
          accentColor="from-orange-500/20 to-orange-500/5"
          iconColor="text-orange-400"
        />
        <StatCard
          title="Games Played"
          value={transactions.filter(t => t.type === 'hilo_win' || t.type === 'hilo_loss').length.toString()}
          subtitle="Hi-Lo rounds"
          icon={Activity}
          accentColor="from-accent/20 to-accent/5"
          iconColor="text-accent"
        />
      </div>

      <DashboardRaffleBanner isSubscribed={rankStatus?.hasSubscription || false} />

      {dailyStatus && dailyStatus.bonusAmount > 0 && (
        <Card className="neon-card bg-card/80 p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-md bg-yellow-500/10 border border-yellow-500/15">
                <Gift className="w-5 h-5 text-yellow-500" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-foreground">Daily Bonus</h3>
                <p className="text-xs text-muted-foreground">
                  {dailyStatus.canClaim
                    ? `Claim ${dailyStatus.bonusAmount} Crux as your ${tier.name} daily reward!`
                    : `Next bonus available ${dailyStatus.nextAvailableAt ? formatDistanceToNow(new Date(dailyStatus.nextAvailableAt), { addSuffix: true }) : "tomorrow"}`
                  }
                </p>
              </div>
            </div>
            <Button
              size="sm"
              onClick={() => claimDailyMutation.mutate()}
              disabled={!dailyStatus.canClaim || claimDailyMutation.isPending}
              data-testid="button-claim-daily"
            >
              <Gift className="w-4 h-4 mr-1.5" />
              {dailyStatus.canClaim ? `Claim ${dailyStatus.bonusAmount} Crux` : "Claimed"}
            </Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-lg font-bold font-display">Recent Transactions</h2>
          <Card className="neon-card bg-card/80 overflow-hidden">
            {transactions.length === 0 ? (
              <div className="p-10 text-center text-muted-foreground flex flex-col items-center">
                <Clock className="w-10 h-10 mb-3 opacity-20" />
                <p className="text-sm">No transactions yet</p>
                <p className="text-xs opacity-60 mt-1">Claim from the faucet to see activity!</p>
              </div>
            ) : (
              <div className="divide-y divide-border/20">
                {transactions.slice(0, 10).map((tx) => (
                  <div key={tx.id} className="px-5 py-3.5 flex items-center justify-between" data-testid={`tx-${tx.id}`}>
                    <div className="flex items-center gap-3">
                      <div className={`h-9 w-9 rounded-md flex items-center justify-center ${
                        tx.type === 'faucet_claim' ? 'bg-primary/10 text-primary' :
                        tx.type === 'daily_bonus' ? 'bg-yellow-500/10 text-yellow-500' :
                        tx.type === 'hilo_win' || tx.type === 'keno_win' ? 'bg-green-500/10 text-green-500' :
                        tx.type === 'hilo_loss' || tx.type === 'keno_loss' ? 'bg-red-500/10 text-red-500' :
                        tx.type === 'withdraw' ? 'bg-red-500/10 text-red-500' : 'bg-secondary text-foreground'
                      }`}>
                        {tx.type === 'daily_bonus' ? <Gift className="w-4 h-4" /> :
                         tx.type === 'withdraw' || tx.type === 'hilo_loss' || tx.type === 'keno_loss' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground capitalize">{tx.type.replace(/_/g, ' ')}</p>
                        <p className="text-[11px] text-muted-foreground">{tx.description || 'No description'}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-mono font-bold text-sm ${tx.type === 'withdraw' || tx.type === 'hilo_loss' || tx.type === 'keno_loss' ? 'text-red-400' : 'text-primary'}`}>
                        {tx.type === 'withdraw' || tx.type === 'hilo_loss' || tx.type === 'keno_loss' ? '-' : '+'}{Number(tx.amount).toLocaleString()} Crux
                      </p>
                      <p className="text-[11px] text-muted-foreground font-mono">
                        {convertToUsd(Number(tx.amount))}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-bold font-display">Tier Progress</h2>
          <Card className="neon-card bg-card/80 p-5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-28 h-28 rounded-full blur-3xl -mr-8 -mt-8" style={{ backgroundColor: tier.color + "12" }} />

            <div className="relative z-10 text-center py-3">
              <div className="w-16 h-16 mx-auto rounded-md flex items-center justify-center border border-border/30 bg-gradient-to-br from-secondary to-secondary/50 shadow-lg mb-3 relative">
                <div className="absolute inset-0 border rounded-md animate-pulse-border" />
                <Shield className="w-7 h-7" style={{ color: tier.color }} />
              </div>
              <TierBadgeLarge tierName={tier.name} />
              <p className="text-xs text-muted-foreground mt-2">
                {experience.toLocaleString()} XP
                {nextTier && ` / ${nextTier.minXp.toLocaleString()} XP`}
              </p>

              {nextTier ? (
                <>
                  <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden mt-3">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, ((experience - tier.minXp) / (nextTier.minXp - tier.minXp)) * 100)}%` }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: tier.color, boxShadow: `0 0 8px ${tier.color}60` }}
                    />
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-2">
                    {(nextTier.minXp - experience).toLocaleString()} XP until <span style={{ color: nextTier.color }} className="font-bold">{nextTier.name}</span>
                  </p>
                </>
              ) : (
                <p className="text-[11px] text-muted-foreground mt-2">You've reached the highest tier!</p>
              )}
            </div>
          </Card>

          <Card className="neon-card bg-card/80 p-4">
            <h3 className="text-xs font-bold text-foreground mb-3 flex items-center gap-2 uppercase tracking-wider">
              <Zap className="w-3.5 h-3.5 text-primary" />
              Active Perks
            </h3>
            <div className="space-y-0.5 divide-y divide-border/15">
              <PerkItem icon={Coins} label="Faucet Bonus" value={`${perks.faucetMultiplier}x`} highlight={perks.faucetMultiplier > 1} />
              <PerkItem icon={Timer} label="Cooldown" value={`${perks.cooldownMinutes}min`} highlight={perks.cooldownMinutes < 60} />
              <PerkItem icon={Activity} label="XP Multiplier" value={`${perks.xpMultiplier}x`} highlight={perks.xpMultiplier > 1} />
              <PerkItem icon={Gift} label="Daily Bonus" value={perks.dailyBonus > 0 ? `${perks.dailyBonus} Crux` : "---"} highlight={perks.dailyBonus > 0} />
              <PerkItem icon={Flame} label="Streak Bonus" value={perks.streakBonus > 0 ? `+${perks.streakBonus}%` : "---"} highlight={perks.streakBonus > 0} />
              <PerkItem icon={Award} label="Withdraw Min" value={`$${perks.withdrawMinUsd}`} highlight={false} />
              <PerkItem icon={Palette} label="Chat Color" value={tier.canCustomColor ? "Yes" : "No"} highlight={tier.canCustomColor} />
            </div>
          </Card>

          <Card className="neon-card bg-card/80 p-4">
            <h3 className="text-xs font-bold text-foreground mb-3 uppercase tracking-wider">All Tiers</h3>
            <div className="space-y-1.5">
              {USER_TIERS.map((t) => {
                const p = getTierPerks(t.name);
                const isCurrent = t.name === tier.name;
                return (
                  <div
                    key={t.name}
                    className={`flex items-center justify-between text-xs p-2 rounded-md ${isCurrent ? "bg-primary/10 border border-primary/15" : ""}`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: t.color }} />
                      <span className={isCurrent ? "font-bold text-foreground" : "text-muted-foreground"}>{t.name}</span>
                      {isCurrent && <span className="text-[10px] text-primary font-semibold">(You)</span>}
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <span className="font-mono">{t.minXp.toLocaleString()} XP</span>
                      <span className="font-mono">{p.faucetMultiplier}x</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, unit, subtitle, icon: Icon, accentColor, iconColor, valueColor }: any) {
  return (
    <Card className="neon-card bg-card/80 p-5 relative overflow-hidden stat-card-gradient">
      <div className={`absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl -mr-8 -mt-8 bg-gradient-to-br ${accentColor} pointer-events-none`} />
      <div className="relative z-10">
        <div className="flex justify-between items-start mb-3">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
          <div className={`p-1.5 rounded-md bg-secondary/50 ${iconColor}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-1.5">
          <h3 className="text-xl font-bold font-mono text-foreground" style={valueColor ? { color: valueColor } : undefined} data-testid={`stat-${title.toLowerCase().replace(/\s/g, '-')}`}>
            {value}
          </h3>
          {unit && <span className="text-xs text-muted-foreground">{unit}</span>}
        </div>
        {subtitle && <p className="text-[11px] text-muted-foreground font-mono mt-0.5">{subtitle}</p>}
      </div>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="h-8 w-40 bg-card rounded-md animate-pulse" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="h-28 bg-card rounded-md animate-pulse" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 h-80 bg-card rounded-md animate-pulse" />
        <div className="h-80 bg-card rounded-md animate-pulse" />
      </div>
    </div>
  );
}
