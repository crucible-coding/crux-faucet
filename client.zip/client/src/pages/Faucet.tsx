import { useState, useEffect, useRef, useCallback } from "react";
import { useFaucetStatus, useClaimFaucet, useUserDashboard } from "@/hooks/use-faucet";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PayoutTable } from "@/components/PayoutTable";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Loader2, Zap, Shield, Rocket, Droplets, FlaskConical, DollarSign, Crown, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { differenceInSeconds } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";
import { SUPPORTED_CRYPTOS, getUserTier } from "@shared/schema";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import faucetHeroImg from "@assets/DD0BD2D3-7458-4C6B-935B-2B26E7279F82_1771258669002.png";

export default function Faucet() {
  const { data: status, isLoading, refetch } = useFaucetStatus();
  const { data: dashboardData } = useUserDashboard();
  const claimMutation = useClaimFaucet();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { convertToUsd, btcPrice } = useBtcPrice();

  const { data: cryptoWallets } = useQuery({
    queryKey: [api.cryptoWallets.list.path],
  });

  const [selectedCryptos, setSelectedCryptos] = useState<string[]>(["usdc"]);
  const [lastRolled, setLastRolled] = useState<string | null>(null);
  const [winAmount, setWinAmount] = useState<string | null>(null);
  const [lastCryptoSplit, setLastCryptoSplit] = useState<{ crypto: string; symbol: string; amount: number }[] | null>(null);
  const [lastProvablyFair, setLastProvablyFair] = useState<{
    serverSeed: string;
    serverSeedHash: string;
    clientSeed: string;
    nonce: number;
  } | null>(null);

  const [showWelcome, setShowWelcome] = useState(() => {
    return !localStorage.getItem("crux_welcome_seen");
  });

  const dismissWelcome = () => {
    setShowWelcome(false);
    localStorage.setItem("crux_welcome_seen", "1");
  };

  const [, navigate] = useLocation();
  const [showRankModal, setShowRankModal] = useState(false);

  const testModeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/test-mode", { enable: true });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Test Mode Enabled", description: data.message });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
      queryClient.invalidateQueries({ queryKey: [api.faucet.status.path] });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const isTestMode = status?.testMode === true;

  useEffect(() => {
    if (!dashboardData?.profile || !cryptoWallets || !btcPrice) return;
    const profile = dashboardData.profile;
    const userTier = getUserTier(profile.experience);
    if (userTier.name !== "Apprentice") return;

    const wallets = cryptoWallets as any[];
    const hasWalletNear19 = wallets.some((w: any) => {
      const bal = parseFloat(w.balance || "0");
      const usdValue = (bal / 100_000_000) * btcPrice;
      return usdValue >= 18 && usdValue < 20;
    });

    if (hasWalletNear19) {
      const alreadyShown = sessionStorage.getItem("crux_rank_upsell_shown");
      if (!alreadyShown) {
        sessionStorage.setItem("crux_rank_upsell_shown", "1");
        setShowRankModal(true);
      }
    }
  }, [dashboardData, cryptoWallets, btcPrice]);

  const [showCrash, setShowCrash] = useState(false);
  const [crashBet, setCrashBet] = useState(0);
  const [crashMaxBet, setCrashMaxBet] = useState(0);
  const [crashGameId, setCrashGameId] = useState<number | null>(null);
  const [crashPoint, setCrashPoint] = useState<number | null>(null);
  const [crashMultiplier, setCrashMultiplier] = useState(1.00);
  const [crashState, setCrashState] = useState<"betting" | "running" | "crashed" | "cashedout">("betting");
  const [crashPayout, setCrashPayout] = useState(0);
  const crashIntervalRef = useRef<number | null>(null);
  const crashGameIdRef = useRef<number | null>(null);

  const cashoutMutation = useMutation({
    mutationFn: async ({ gameId, cashoutAt }: { gameId: number; cashoutAt: number }) => {
      const res = await apiRequest("POST", api.crash.cashout.path, { gameId, cashoutAt });
      return res.json();
    },
    onSuccess: (data) => {
      if (crashIntervalRef.current) {
        clearInterval(crashIntervalRef.current);
        crashIntervalRef.current = null;
      }
      if (data.won) {
        setCrashState("cashedout");
        setCrashPayout(parseInt(data.payout));
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.5 },
          colors: ["#06ffff", "#00ff88", "#ffffff"],
        });
      } else {
        setCrashState("crashed");
      }
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
      queryClient.invalidateQueries({ queryKey: [api.crash.history.path] });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const startCrashAnimation = useCallback((actualCrashPoint: number, gameId: number) => {
    if (crashIntervalRef.current) {
      clearInterval(crashIntervalRef.current);
    }
    const startTime = Date.now();
    crashIntervalRef.current = window.setInterval(() => {
      const elapsed = (Date.now() - startTime) / 1000;
      const currentMultiplier = Math.pow(Math.E, 0.08 * elapsed);
      const displayMultiplier = Math.floor(currentMultiplier * 100) / 100;

      if (displayMultiplier >= actualCrashPoint) {
        setCrashMultiplier(actualCrashPoint);
        setCrashState("crashed");
        if (crashIntervalRef.current) {
          clearInterval(crashIntervalRef.current);
          crashIntervalRef.current = null;
        }
        cashoutMutation.mutate({ gameId, cashoutAt: actualCrashPoint + 0.01 });
      } else {
        setCrashMultiplier(displayMultiplier);
      }
    }, 50);
  }, []);

  const startCrashMutation = useMutation({
    mutationFn: async (betAmount: number) => {
      const res = await apiRequest("POST", api.crash.play.path, { betAmount });
      return res.json();
    },
    onSuccess: (data) => {
      const gId = data.gameId;
      setCrashGameId(gId);
      crashGameIdRef.current = gId;
      setCrashPoint(parseFloat(data.crashPoint));
      setCrashState("running");
      startCrashAnimation(parseFloat(data.crashPoint), gId);
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  useEffect(() => {
    return () => {
      if (crashIntervalRef.current) {
        clearInterval(crashIntervalRef.current);
      }
    };
  }, []);

  const handleCashout = () => {
    const gId = crashGameIdRef.current;
    if (gId && crashState === "running") {
      if (crashIntervalRef.current) {
        clearInterval(crashIntervalRef.current);
        crashIntervalRef.current = null;
      }
      cashoutMutation.mutate({ gameId: gId, cashoutAt: crashMultiplier });
    }
  };

  const handleRoll = async () => {
    try {
      const result = await claimMutation.mutateAsync(selectedCryptos);
      setLastRolled(result.rolledValue);
      setWinAmount(result.amount);
      setLastCryptoSplit(result.cryptoSplit || null);
      setLastProvablyFair({
        serverSeed: result.serverSeed,
        serverSeedHash: result.serverSeedHash,
        clientSeed: result.clientSeed,
        nonce: result.nonce,
      });

      const isJackpot = result.rolledValue === "0000";
      const duration = isJackpot ? 5000 : 3000;
      const end = Date.now() + duration;

      (function frame() {
        confetti({
          particleCount: isJackpot ? 10 : 5,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: isJackpot ? ['#ffd700', '#ff6b00', '#ff0000'] : ['#06ffff', '#ffffff']
        });
        confetti({
          particleCount: isJackpot ? 10 : 5,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: isJackpot ? ['#ffd700', '#ff6b00', '#ff0000'] : ['#06ffff', '#ffffff']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      }());

      toast({
        title: isJackpot ? "JACKPOT!" : "Claim Successful!",
        description: `You rolled ${result.rolledValue} and won ${Number(result.amount).toLocaleString()} Crux!`,
        className: "bg-primary text-primary-foreground border-none"
      });

      const wonSats = Number(result.amount);
      if (wonSats > 0) {
        setTimeout(() => {
          setCrashMaxBet(wonSats);
          setCrashBet(wonSats);
          setCrashState("betting");
          setCrashMultiplier(1.00);
          setCrashPayout(0);
          setCrashGameId(null);
          setCrashPoint(null);
          setShowCrash(true);
        }, 1500);
      }

    } catch (error: any) {
      toast({
        title: "Claim Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleCloseCrash = () => {
    if (crashIntervalRef.current) {
      clearInterval(crashIntervalRef.current);
      crashIntervalRef.current = null;
    }
    crashGameIdRef.current = null;
    setShowCrash(false);
  };

  const crashColor = crashState === "crashed" ? "text-red-400" :
    crashState === "cashedout" ? "text-green-400" :
    crashMultiplier >= 3 ? "text-yellow-400" :
    crashMultiplier >= 2 ? "text-green-400" : "text-primary";

  const balance = Number(dashboardData?.profile.balance || 0);

  const getWalletBalance = (currencyId: string): string => {
    if (!cryptoWallets) return "0";
    const wallet = (cryptoWallets as any[]).find((w: any) => w.currency === currencyId);
    return wallet?.balance || "0";
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <div className="relative rounded-xl overflow-hidden">
        <img
          src={faucetHeroImg}
          alt="Crux Faucet"
          className="w-full h-48 md:h-56 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
        <div className="absolute inset-0 flex items-center px-6 md:px-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Droplets className="w-6 h-6 text-primary" />
              <h1 className="text-2xl md:text-3xl font-bold text-white font-display" data-testid="text-faucet-title">
                Claim Free Crypto
              </h1>
            </div>
            <p className="text-sm text-gray-300 max-w-md">
              Roll every hour to earn free Crux. Every roll is provably fair and verifiable.
            </p>
            <p className="text-xs text-primary font-mono mt-2 font-bold" data-testid="text-faucet-balance">
              Balance: {balance.toLocaleString()} Crux ({convertToUsd(balance)})
            </p>
            {isTestMode && (
              <span className="inline-block mt-1 text-[10px] font-bold text-yellow-400 bg-yellow-400/10 px-2 py-0.5 rounded" data-testid="badge-test-mode">
                TEST MODE - Unlimited Rolls
              </span>
            )}
          </div>
          <div className="ml-auto">
            <Button
              size="sm"
              variant={isTestMode ? "secondary" : "outline"}
              className="text-xs border-white/20 text-white bg-white/10"
              onClick={() => testModeMutation.mutate()}
              disabled={testModeMutation.isPending || isTestMode}
              data-testid="button-test-mode"
            >
              <FlaskConical className="w-3 h-3 mr-1" />
              {isTestMode ? "Test Mode On" : "Enable Test Mode"}
            </Button>
          </div>
        </div>
      </div>

      <div className="mb-1">
        <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2">
          Select crypto wallets to deposit into {selectedCryptos.length > 1 && <span className="text-primary">(winnings split evenly)</span>}
        </p>
        <div className="grid grid-cols-3 gap-3">
          {SUPPORTED_CRYPTOS.map((crypto) => {
            const isSelected = selectedCryptos.includes(crypto.id);
            const walletData = Array.isArray(cryptoWallets) ? (cryptoWallets as any[]).find((w: any) => w.currency === crypto.id) : null;
            const walletBalance = walletData ? Number(walletData.balance || 0) : 0;
            return (
              <button
                key={crypto.id}
                type="button"
                onClick={() => {
                  setSelectedCryptos(prev => {
                    if (prev.includes(crypto.id)) {
                      if (prev.length === 1) return prev;
                      return prev.filter(c => c !== crypto.id);
                    }
                    return [...prev, crypto.id];
                  });
                }}
                className={`rounded-lg p-4 text-center transition-all duration-200 ${
                  isSelected
                    ? "border-2 ring-1 ring-primary/30"
                    : "border border-border/30 hover-elevate"
                }`}
                style={isSelected ? {
                  borderColor: crypto.color,
                  backgroundColor: crypto.color + "12",
                  boxShadow: `0 0 12px ${crypto.color}20`,
                } : {
                  backgroundColor: "rgba(var(--card), 0.6)",
                }}
                data-testid={`faucet-crypto-${crypto.id}`}
              >
                <div
                  className="w-10 h-10 rounded-lg mx-auto flex items-center justify-center text-white text-xs font-bold mb-2"
                  style={{ backgroundColor: crypto.color }}
                >
                  {crypto.symbol}
                </div>
                <p className={`text-sm font-bold ${isSelected ? "text-foreground" : "text-foreground"}`}>{crypto.name}</p>
                <p className="text-lg font-mono font-bold text-foreground mt-1" data-testid={`text-wallet-balance-${crypto.id}`}>
                  {walletBalance.toLocaleString()}
                </p>
                <p className="text-[10px] text-muted-foreground">{crypto.symbol} Crux</p>
                <div className="mt-2">
                  {isSelected ? (
                    <span
                      className="text-[10px] font-bold px-2 py-0.5 rounded-md inline-block"
                      style={{ backgroundColor: crypto.color + "25", color: crypto.color }}
                    >
                      SELECTED
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground/50 px-2 py-0.5 rounded-md inline-block border border-border/20">
                      TAP TO SELECT
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 items-start">
        <Card className="neon-card bg-card/80 p-8 relative overflow-hidden flex flex-col items-center justify-center min-h-[340px]">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-accent/5 pointer-events-none" />

          <AnimatePresence mode="wait">
            {!isLoading && status?.canClaim ? (
              <motion.div
                key="ready"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="relative z-10 text-center w-full"
              >
                <p className="text-xs text-muted-foreground uppercase tracking-widest mb-3">Roll Result</p>
                <div className="mb-6 relative">
                  {lastRolled !== null ? (
                    <div className={`text-6xl font-mono font-bold tracking-widest ${lastRolled === "0000" ? "text-yellow-400 animate-pulse" : "text-primary neon-text"}`}>
                      {lastRolled}
                    </div>
                  ) : (
                    <div className="text-6xl font-mono font-bold text-muted/30 tracking-widest">
                      0000
                    </div>
                  )}
                </div>

                <AnimatePresence>
                  {showWelcome && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mb-5 p-4 rounded-xl border border-primary/30 bg-primary/10 text-center cursor-pointer"
                      onClick={dismissWelcome}
                      data-testid="welcome-splash"
                    >
                      <p className="text-lg font-bold text-primary mb-1">
                        Start earning free USDC now
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Hit the Roll button below to claim your first reward
                      </p>
                      <div className="flex justify-center mt-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-primary animate-bounce">
                          <path d="M12 5v14m0 0l-6-6m6 6l6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <Button
                  size="lg"
                  className="w-full text-xl font-bold rounded-xl shadow-[0_0_30px_rgba(6,255,255,0.3)] transition-all duration-300"
                  onClick={() => { dismissWelcome(); handleRoll(); }}
                  disabled={claimMutation.isPending}
                  data-testid="button-roll"
                >
                  {claimMutation.isPending ? (
                    <Loader2 className="w-6 h-6 animate-spin" />
                  ) : (
                    <>
                      <Zap className="w-6 h-6 mr-2 fill-current" />
                      ROLL
                    </>
                  )}
                </Button>

                {winAmount && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-5 space-y-2"
                  >
                    <p className="text-lg font-bold text-primary" data-testid="text-win-amount">
                      +{Number(winAmount).toLocaleString()} Crux
                    </p>
                    {lastCryptoSplit && lastCryptoSplit.length > 0 && (
                      <div className="flex items-center justify-center gap-2 flex-wrap" data-testid="crypto-split-display">
                        {lastCryptoSplit.map((split) => {
                          const cryptoDef = SUPPORTED_CRYPTOS.find(c => c.id === split.crypto);
                          return (
                            <div
                              key={split.crypto}
                              className="flex items-center gap-1.5 bg-card/80 border border-border/30 rounded-md px-2.5 py-1"
                            >
                              <div
                                className="w-4 h-4 rounded-full flex items-center justify-center text-white text-[7px] font-bold"
                                style={{ backgroundColor: cryptoDef?.color || "#666" }}
                              >
                                {split.symbol.substring(0, 2)}
                              </div>
                              <span className="text-xs font-mono font-bold text-foreground">
                                +{split.amount.toLocaleString()}
                              </span>
                              <span className="text-[10px] text-muted-foreground">{split.symbol}</span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </motion.div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="timer"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="relative z-10 w-full"
              >
                <Timer targetDate={status?.nextRollAvailableAt} onComplete={() => refetch()} />
              </motion.div>
            )}
          </AnimatePresence>
        </Card>

        <div className="space-y-4">
          <PayoutTable />

          {lastProvablyFair && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="neon-card bg-card/80 p-4 space-y-3"
            >
              <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Shield className="w-4 h-4 text-primary" />
                Provably Fair
              </div>
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-muted-foreground">Server Seed Hash:</span>
                  <p className="font-mono text-foreground/80 break-all">{lastProvablyFair.serverSeedHash.substring(0, 32)}...</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Client Seed:</span>
                  <p className="font-mono text-foreground/80">{lastProvablyFair.clientSeed}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Nonce:</span>
                  <p className="font-mono text-foreground/80">{lastProvablyFair.nonce}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Server Seed (Revealed):</span>
                  <p className="font-mono text-foreground/80 break-all">{lastProvablyFair.serverSeed.substring(0, 32)}...</p>
                </div>
              </div>
            </motion.div>
          )}

          <Card className="neon-card bg-primary/5 p-4 text-sm text-primary/80">
            <p className="flex gap-2 items-start">
              <Shield className="w-5 h-5 shrink-0 mt-0.5" />
              <span>
                All rolls are provably fair. You can verify any roll using the server seed, client seed, and nonce.
              </span>
            </p>
          </Card>
        </div>
      </div>

      <Card className="flex items-center gap-3 p-4 border-primary/30 bg-primary/5" data-testid="notice-min-cashout">
        <DollarSign className="w-5 h-5 text-primary shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-semibold text-foreground">$20 Minimum Cash Out</p>
          <p className="text-xs text-muted-foreground">
            Accumulate at least $20 in any crypto wallet and purchase a rank subscription to unlock withdrawals. Sliding fee: 5% at $20 down to 1% at $100k+.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => navigate("/ranks")} data-testid="button-view-ranks-notice">
          <Crown className="w-3 h-3 mr-1" />
          Ranks
        </Button>
      </Card>

      {dashboardData?.profile && (() => {
        const tier = getUserTier(dashboardData.profile.experience);
        const tierIdx = ["Apprentice", "Journeyman", "Foreman", "Engineer", "Boss", "Elite"].indexOf(tier.name);
        const canStake = tierIdx >= 3;
        if (!canStake || !cryptoWallets || !Array.isArray(cryptoWallets)) return null;
        const totalBal = (cryptoWallets as any[]).reduce((sum: number, w: any) => sum + Number(w.balance || 0), 0);
        if (totalBal <= 0) return null;
        return (
          <Card className="flex items-center gap-3 p-4 border-green-500/30 bg-green-500/5" data-testid="notice-quick-stake">
            <TrendingUp className="w-5 h-5 text-green-500 shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">Stake My Crypto</p>
              <p className="text-xs text-muted-foreground">
                Lock your Crux in our staking pool and earn {tier.name === "Elite" ? "2.0%" : tier.name === "Boss" ? "1.5%" : "1.0%"} APY over 6 months.
              </p>
            </div>
            <Button size="sm" onClick={() => navigate("/staking")} data-testid="button-quick-stake">
              <TrendingUp className="w-3 h-3 mr-1" />
              Stake Now
            </Button>
          </Card>
        );
      })()}

      {(() => {
        if (!dashboardData?.profile || getUserTier(dashboardData.profile.experience).name !== "Apprentice" || !cryptoWallets || !Array.isArray(cryptoWallets)) return null;
        const maxWalletUsd = Math.max(...(cryptoWallets as any[]).map((w: any) => {
          const bal = parseFloat(w.balance || "0");
          return btcPrice ? (bal / 100_000_000) * btcPrice : 0;
        }));
        if (maxWalletUsd < 15) return null;
        return (
          <Card className="flex items-center gap-3 p-4 border-yellow-500/30 bg-yellow-500/5" data-testid="notice-rank-upsell-inline">
            <Crown className="w-5 h-5 text-yellow-500 shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">
                {maxWalletUsd >= 19 ? "You're almost at $20!" : `$${maxWalletUsd.toFixed(2)} in your top wallet`}
              </p>
              <p className="text-xs text-muted-foreground">
                Purchase a rank for $19 to unlock cash out when you hit $20.
              </p>
            </div>
            <Button size="sm" onClick={() => navigate("/ranks")} data-testid="button-buy-rank-inline">
              Buy Rank
            </Button>
          </Card>
        );
      })()}

      <Dialog open={showRankModal} onOpenChange={setShowRankModal}>
        <DialogContent className="sm:max-w-md border-border/50 bg-card" data-testid="dialog-rank-purchase">
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-yellow-500" />
            Unlock Cash Out
          </DialogTitle>
          <DialogDescription>
            Your wallet balance is approaching $20. Purchase a rank to unlock withdrawals.
          </DialogDescription>
          <div className="space-y-4 mt-2">
            <div className="bg-background/50 rounded-lg p-4 border border-border/30 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">Minimum rank cost</span>
                <span className="text-sm font-bold text-foreground font-mono">$19</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">Cash out minimum</span>
                <span className="text-sm font-bold text-foreground font-mono">$20</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">Withdrawal fee</span>
                <span className="text-sm font-bold text-foreground font-mono">5% - 1%</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Higher tiers unlock better faucet multipliers, reduced cooldowns, daily bonuses, and more. The higher you withdraw, the lower the fee.
            </p>
            <div className="flex gap-2">
              <Button className="flex-1" onClick={() => { setShowRankModal(false); navigate("/ranks"); }} data-testid="button-go-to-ranks">
                <Crown className="w-4 h-4 mr-1" />
                View Ranks
              </Button>
              <Button variant="ghost" onClick={() => setShowRankModal(false)} data-testid="button-dismiss-rank-modal">
                Maybe Later
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showCrash} onOpenChange={(open) => { if (!open) handleCloseCrash(); }}>
        <DialogContent className="sm:max-w-md border-border/50 bg-card p-0 gap-0 overflow-visible" data-testid="dialog-crash-popup">
          <DialogTitle className="sr-only">Crash Game - Multiply Your Winnings</DialogTitle>
          <DialogDescription className="sr-only">Risk your faucet winnings in the Crash game</DialogDescription>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-transparent rounded-t-lg pointer-events-none" />

            <div className="p-6 pb-4 text-center relative">
              {crashState === "betting" && (
                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", bounce: 0.5 }}
                >
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Rocket className="w-6 h-6 text-primary" />
                    <h2 className="text-xl font-bold text-foreground" data-testid="text-crash-hook">Multiply Your Winnings!</h2>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">
                    You just won <span className="text-primary font-bold font-mono">{crashMaxBet.toLocaleString()} Crux</span>
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Choose how much to risk in a Crash game!
                  </p>

                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="mt-6 mb-4"
                  >
                    <div className="bg-background/50 rounded-xl p-4 border border-border/30 space-y-3">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Your bet</p>
                      <Input
                        type="number"
                        value={crashBet}
                        onChange={(e) => {
                          const val = Math.min(Math.max(0, parseInt(e.target.value) || 0), crashMaxBet);
                          setCrashBet(val);
                        }}
                        className="font-mono text-center text-xl font-bold"
                        min={1}
                        max={crashMaxBet}
                        data-testid="input-crash-bet"
                      />
                      <div className="flex gap-2 flex-wrap">
                        <Button variant="outline" size="sm" onClick={() => setCrashBet(Math.floor(crashMaxBet * 0.25))} data-testid="button-crash-25">25%</Button>
                        <Button variant="outline" size="sm" onClick={() => setCrashBet(Math.floor(crashMaxBet * 0.5))} data-testid="button-crash-50">50%</Button>
                        <Button variant="outline" size="sm" onClick={() => setCrashBet(Math.floor(crashMaxBet * 0.75))} data-testid="button-crash-75">75%</Button>
                        <Button variant="outline" size="sm" onClick={() => setCrashBet(crashMaxBet)} data-testid="button-crash-max">MAX</Button>
                      </div>
                      <p className="text-xs text-muted-foreground font-mono">{convertToUsd(crashBet)}</p>
                    </div>
                  </motion.div>

                  <motion.div
                    initial={{ y: 10, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                    className="space-y-3"
                  >
                    <Button
                      size="lg"
                      className="w-full font-bold text-lg"
                      onClick={() => startCrashMutation.mutate(crashBet)}
                      disabled={startCrashMutation.isPending || crashBet < 1}
                      data-testid="button-crash-start"
                    >
                      {startCrashMutation.isPending ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <>
                          <Rocket className="w-5 h-5 mr-2" />
                          LAUNCH {crashBet.toLocaleString()} Crux
                        </>
                      )}
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground"
                      onClick={handleCloseCrash}
                      data-testid="button-crash-skip"
                    >
                      No thanks, keep my winnings
                    </Button>
                  </motion.div>
                </motion.div>
              )}

              {crashState === "running" && (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                >
                  <div className="mb-2">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Multiplier</p>
                    <motion.div
                      animate={{ scale: [1, 1.02, 1] }}
                      transition={{ repeat: Infinity, duration: 0.5 }}
                      className={`text-6xl font-mono font-bold ${crashColor}`}
                      data-testid="text-crash-multiplier"
                    >
                      {crashMultiplier.toFixed(2)}x
                    </motion.div>
                  </div>

                  <div className="bg-background/50 rounded-xl p-3 border border-border/30 my-4">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs text-muted-foreground">Potential payout</span>
                      <span className="text-sm font-mono font-bold text-primary">
                        {Math.floor(crashBet * crashMultiplier).toLocaleString()} Crux
                      </span>
                    </div>
                  </div>

                  <Button
                    size="lg"
                    className="w-full font-bold text-lg bg-green-600 text-white"
                    onClick={handleCashout}
                    disabled={cashoutMutation.isPending}
                    data-testid="button-crash-cashout"
                  >
                    {cashoutMutation.isPending ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        CASH OUT {Math.floor(crashBet * crashMultiplier).toLocaleString()} Crux
                      </>
                    )}
                  </Button>

                  <div className="w-full bg-background/30 rounded-full h-1.5 mt-4 overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-primary via-green-400 to-yellow-400 rounded-full"
                      initial={{ width: "5%" }}
                      animate={{ width: `${Math.min(crashMultiplier / 10 * 100, 100)}%` }}
                      transition={{ duration: 0.1 }}
                    />
                  </div>
                </motion.div>
              )}

              {crashState === "crashed" && (
                <AnimatePresence mode="wait">
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                  >
                    <div className="mb-4">
                      <p className="text-xs text-red-400 uppercase tracking-wider mb-2">Crashed!</p>
                      <div className="text-5xl font-mono font-bold text-red-400" data-testid="text-crash-result-loss">
                        {(crashPoint || crashMultiplier).toFixed(2)}x
                      </div>
                    </div>

                    <p className="text-lg font-bold text-red-400 mb-1">
                      You lost {crashBet.toLocaleString()} Crux
                    </p>
                    <p className="text-xs text-muted-foreground mb-4">Better luck next time!</p>

                    <Button
                      variant="default"
                      className="w-full"
                      onClick={handleCloseCrash}
                      data-testid="button-crash-close"
                    >
                      Close
                    </Button>
                  </motion.div>
                </AnimatePresence>
              )}

              {crashState === "cashedout" && (
                <AnimatePresence mode="wait">
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                  >
                    <div className="mb-4">
                      <p className="text-xs text-green-400 uppercase tracking-wider mb-2">Cashed Out!</p>
                      <div className="text-5xl font-mono font-bold text-green-400" data-testid="text-crash-result-win">
                        {crashMultiplier.toFixed(2)}x
                      </div>
                    </div>

                    <div className="bg-background/50 rounded-xl p-4 border border-border/30 mb-4 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">Bet</span>
                        <span className="text-sm font-mono text-foreground">{crashBet.toLocaleString()} Crux</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">Payout</span>
                        <span className="text-sm font-mono font-bold text-green-400">{crashPayout.toLocaleString()} Crux</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">Profit</span>
                        <span className="text-sm font-mono font-bold text-green-400">+{(crashPayout - crashBet).toLocaleString()} Crux</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">Crashed at</span>
                        <span className="text-sm font-mono text-red-400">{(crashPoint || 0).toFixed(2)}x</span>
                      </div>
                    </div>

                    <Button
                      variant="default"
                      className="w-full"
                      onClick={handleCloseCrash}
                      data-testid="button-crash-close-win"
                    >
                      Collect Winnings
                    </Button>
                  </motion.div>
                </AnimatePresence>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Timer({ targetDate, onComplete }: { targetDate?: string | null, onComplete: () => void }) {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    if (!targetDate) return;

    const interval = setInterval(() => {
      const now = new Date();
      const target = new Date(targetDate);
      const diff = differenceInSeconds(target, now);

      if (diff <= 0) {
        clearInterval(interval);
        onComplete();
        return;
      }

      const m = Math.floor(diff / 60);
      const s = diff % 60;
      setTimeLeft(`${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`);
    }, 1000);

    return () => clearInterval(interval);
  }, [targetDate, onComplete]);

  if (!targetDate) return <div className="text-center text-muted-foreground">Loading...</div>;

  return (
    <div className="text-center py-8">
      <p className="text-muted-foreground uppercase tracking-widest text-sm font-semibold mb-4">Next Roll In</p>
      <div className="text-7xl font-mono font-bold text-foreground tabular-nums tracking-tight">
        {timeLeft}
      </div>
      <p className="mt-6 text-sm text-muted-foreground/50">Come back soon!</p>
    </div>
  );
}
