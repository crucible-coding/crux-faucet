import { useState, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useUserDashboard } from "@/hooks/use-faucet";
import { useBtcPrice } from "@/hooks/use-btc-price";
import { api } from "@shared/routes";
import { getUserTier, getTierPerks } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, History, Zap, Target, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import confetti from "canvas-confetti";

const KENO_PAYOUTS: Record<number, Record<number, number>> = {
  1:  { 0: 0, 1: 3.5 },
  2:  { 0: 0, 1: 1.5, 2: 5 },
  3:  { 0: 0, 1: 1, 2: 3, 3: 16 },
  4:  { 0: 0, 1: 0.5, 2: 2, 3: 6, 4: 40 },
  5:  { 0: 0, 1: 0, 2: 1, 3: 3, 4: 15, 5: 100 },
  6:  { 0: 0, 1: 0, 2: 0.5, 3: 2, 4: 8, 5: 50, 6: 250 },
  7:  { 0: 0, 1: 0, 2: 0, 3: 1.5, 4: 5, 5: 20, 6: 100, 7: 500 },
  8:  { 0: 0, 1: 0, 2: 0, 3: 1, 4: 3, 5: 10, 6: 50, 7: 250, 8: 1000 },
  9:  { 0: 0, 1: 0, 2: 0, 3: 0.5, 4: 2, 5: 6, 6: 25, 7: 100, 8: 500, 9: 2500 },
  10: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 4, 6: 15, 7: 60, 8: 250, 9: 1000, 10: 5000 },
};

export default function Keno() {
  const { data: dashboardData } = useUserDashboard();
  const { convertToUsd } = useBtcPrice();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [betAmount, setBetAmount] = useState("10");
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [isRevealing, setIsRevealing] = useState(false);
  const [revealedDrawn, setRevealedDrawn] = useState<number[]>([]);
  const [lastResult, setLastResult] = useState<{
    selectedNumbers: number[];
    drawnNumbers: number[];
    hits: number;
    multiplier: string;
    betAmount: string;
    payout: string;
    newBalance: string;
    serverSeed: string;
    serverSeedHash: string;
    clientSeed: string;
    nonce: number;
  } | null>(null);

  const balance = Number(dashboardData?.profile?.balance || 0);
  const experience = dashboardData?.profile?.experience || 0;
  const tier = getUserTier(experience);
  const perks = getTierPerks(tier.name);

  const { data: history } = useQuery({
    queryKey: [api.keno.history.path],
    queryFn: async () => {
      const res = await fetch(api.keno.history.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch history");
      return res.json();
    },
  });

  const toggleNumber = useCallback((num: number) => {
    if (isRevealing) return;
    setSelectedNumbers((prev) => {
      if (prev.includes(num)) return prev.filter((n) => n !== num);
      if (prev.length >= 10) return prev;
      return [...prev, num];
    });
    setLastResult(null);
    setRevealedDrawn([]);
  }, [isRevealing]);

  const clearSelection = () => {
    if (isRevealing) return;
    setSelectedNumbers([]);
    setLastResult(null);
    setRevealedDrawn([]);
  };

  const quickPick = (count: number) => {
    if (isRevealing) return;
    const nums: number[] = [];
    while (nums.length < count) {
      const n = Math.floor(Math.random() * 40) + 1;
      if (!nums.includes(n)) nums.push(n);
    }
    setSelectedNumbers(nums.sort((a, b) => a - b));
    setLastResult(null);
    setRevealedDrawn([]);
  };

  const playMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.keno.play.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          betAmount: parseInt(betAmount),
          selectedNumbers,
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: (data) => {
      setIsRevealing(true);
      setRevealedDrawn([]);

      const drawn: number[] = data.drawnNumbers;
      drawn.forEach((num: number, i: number) => {
        setTimeout(() => {
          setRevealedDrawn((prev) => [...prev, num]);

          if (i === drawn.length - 1) {
            setIsRevealing(false);
            setLastResult(data);
            queryClient.invalidateQueries({ queryKey: [api.keno.history.path] });
            queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });

            if (Number(data.payout) > 0) {
              confetti({ particleCount: 80, spread: 60 });
              toast({ title: "You won!", description: `${Number(data.payout).toLocaleString()} Crux (${data.multiplier}x)` });
            } else {
              toast({ title: "No luck", description: `${data.hits} hits - try again!`, variant: "destructive" });
            }
          }
        }, 150 * (i + 1));
      });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const numPicks = selectedNumbers.length;
  const payoutTable = numPicks > 0 ? KENO_PAYOUTS[numPicks] : null;
  const betNum = parseInt(betAmount) || 0;

  const getNumberState = (num: number) => {
    const isSelected = selectedNumbers.includes(num);
    const isDrawn = revealedDrawn.includes(num);
    const isHit = isSelected && isDrawn;
    const isMiss = isSelected && lastResult && !lastResult.drawnNumbers.includes(num);
    return { isSelected, isDrawn, isHit, isMiss };
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-bold font-display gradient-text-cyan-purple" data-testid="text-keno-title">Keno</h1>
        <p className="text-sm text-muted-foreground">Pick up to 10 numbers, bet, and watch the draw.</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="neon-card bg-card/80 p-5 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Balance</p>
          <p className="text-xl font-mono font-bold text-foreground" data-testid="text-keno-balance">
            {balance.toLocaleString()}
          </p>
          <p className="text-xs text-muted-foreground">Crux ({convertToUsd(balance)})</p>
        </Card>
        <Card className="neon-card bg-card/80 p-5 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Picks</p>
          <p className="text-xl font-mono font-bold text-primary" data-testid="text-keno-picks">
            {numPicks}/10
          </p>
          <p className="text-xs text-muted-foreground">min 1, max 10</p>
        </Card>
        <Card className="neon-card bg-card/80 p-5 text-center">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Max Bet</p>
          <p className="text-xl font-mono font-bold text-foreground">
            {perks.maxHiloBet.toLocaleString()}
          </p>
          <p className="text-xs text-muted-foreground">{tier.name} tier</p>
        </Card>
      </div>

      <Card className="neon-card bg-card/80">
        <div className="flex flex-row items-center justify-between gap-2 p-5 pb-3">
          <div className="flex items-center gap-2 text-sm font-bold text-foreground uppercase tracking-wider">
            <Target className="w-4 h-4 text-primary" />
            Pick Your Numbers
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={() => quickPick(3)} disabled={isRevealing} data-testid="button-quick-3">
              Quick 3
            </Button>
            <Button variant="outline" size="sm" onClick={() => quickPick(5)} disabled={isRevealing} data-testid="button-quick-5">
              Quick 5
            </Button>
            <Button variant="outline" size="sm" onClick={() => quickPick(10)} disabled={isRevealing} data-testid="button-quick-10">
              Quick 10
            </Button>
            <Button variant="ghost" size="sm" onClick={clearSelection} disabled={isRevealing} data-testid="button-clear-picks">
              Clear
            </Button>
          </div>
        </div>
        <div className="px-5 pb-5">
          <div className="grid grid-cols-8 gap-2" data-testid="keno-grid">
            {Array.from({ length: 40 }, (_, i) => i + 1).map((num) => {
              const { isSelected, isDrawn, isHit, isMiss } = getNumberState(num);
              return (
                <motion.button
                  type="button"
                  key={num}
                  onClick={() => toggleNumber(num)}
                  disabled={isRevealing || (!isSelected && selectedNumbers.length >= 10)}
                  aria-label={`Select number ${num}`}
                  aria-pressed={isSelected}
                  className={`
                    aspect-square rounded-md border text-sm font-mono font-bold
                    flex items-center justify-center transition-colors
                    ${isHit
                      ? "bg-green-500 border-green-400 text-white"
                      : isMiss
                        ? "bg-red-500/30 border-red-400/50 text-red-400"
                        : isDrawn
                          ? "bg-yellow-500/30 border-yellow-400/50 text-yellow-400"
                          : isSelected
                            ? "bg-primary border-primary text-primary-foreground"
                            : "border-border/50 text-foreground hover-elevate"
                    }
                    disabled:opacity-40 disabled:cursor-not-allowed
                  `}
                  whileTap={!isRevealing ? { scale: 0.9 } : undefined}
                  animate={isHit ? { scale: [1, 1.2, 1] } : undefined}
                  data-testid={`keno-number-${num}`}
                >
                  {num}
                </motion.button>
              );
            })}
          </div>
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="neon-card bg-card/80 p-5">
          <h3 className="flex items-center gap-2 text-sm font-bold text-foreground uppercase tracking-wider mb-4">
            <Zap className="w-4 h-4 text-primary" />
            Place Bet
          </h3>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground block mb-2">Bet Amount (Crux)</label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  className="font-mono"
                  min={1}
                  max={perks.maxHiloBet}
                  disabled={isRevealing}
                  data-testid="input-keno-bet"
                />
              </div>
              <div className="flex gap-2 mt-2 flex-wrap">
                {[10, 50, 100, 500, 1000].map((amt) => (
                  <Button
                    key={amt}
                    variant="outline"
                    size="sm"
                    onClick={() => setBetAmount(amt.toString())}
                    disabled={isRevealing}
                    data-testid={`button-bet-${amt}`}
                  >
                    {amt}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setBetAmount(Math.min(balance, perks.maxHiloBet).toString())}
                  disabled={isRevealing}
                  data-testid="button-bet-max"
                >
                  Max
                </Button>
              </div>
            </div>

            <Button
              className="w-full"
              onClick={() => playMutation.mutate()}
              disabled={
                playMutation.isPending ||
                isRevealing ||
                numPicks === 0 ||
                betNum < 1 ||
                betNum > balance ||
                betNum > perks.maxHiloBet
              }
              data-testid="button-play-keno"
            >
              {playMutation.isPending || isRevealing ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2" />
              )}
              {isRevealing ? "Drawing..." : `Play Keno (${betNum.toLocaleString()} Crux)`}
            </Button>

            {betNum > balance && (
              <p className="text-xs text-red-400 text-center">Insufficient balance</p>
            )}
          </div>
        </Card>

        <Card className="neon-card bg-card/80 p-5">
          <h3 className="text-xs font-bold text-foreground uppercase tracking-wider mb-3">Payout Table ({numPicks || "?"} picks)</h3>
            {payoutTable ? (
              <div className="space-y-1">
                {Object.entries(payoutTable).map(([hits, mult]) => {
                  const isCurrentHits = lastResult && Number(hits) === lastResult.hits;
                  return (
                    <div
                      key={hits}
                      className={`flex items-center justify-between text-sm px-2 py-1 rounded-md ${
                        isCurrentHits ? "bg-primary/10 border border-primary/30" : ""
                      }`}
                    >
                      <span className="text-muted-foreground">
                        {hits} hit{Number(hits) !== 1 ? "s" : ""}
                      </span>
                      <span className={`font-mono font-bold ${mult > 0 ? "text-foreground" : "text-muted-foreground/50"}`}>
                        {mult > 0 ? `${mult}x` : "---"}
                        {mult > 0 && betNum > 0 && (
                          <span className="text-xs text-muted-foreground ml-2">
                            ({Math.floor(betNum * mult).toLocaleString()})
                          </span>
                        )}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                Pick 1-10 numbers to see payouts
              </p>
            )}
        </Card>
      </div>

      <AnimatePresence>
        {lastResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className={`neon-card bg-card/80 p-6 ${Number(lastResult.payout) > 0 ? "border-green-500/30" : "border-red-500/30"}`}>
                <div className="text-center space-y-3">
                  <p className="text-sm text-muted-foreground uppercase tracking-wider">Result</p>
                  <div className="flex items-center justify-center gap-3 flex-wrap">
                    <span className="text-4xl font-mono font-bold text-foreground" data-testid="text-keno-hits">
                      {lastResult.hits}/{numPicks}
                    </span>
                    <Badge variant={Number(lastResult.payout) > 0 ? "default" : "secondary"}>
                      {lastResult.multiplier}x
                    </Badge>
                  </div>
                  <p className={`text-2xl font-mono font-bold ${Number(lastResult.payout) > 0 ? "text-green-400" : "text-red-400"}`}
                     data-testid="text-keno-payout">
                    {Number(lastResult.payout) > 0
                      ? `+${Number(lastResult.payout).toLocaleString()} Crux`
                      : `-${Number(lastResult.betAmount).toLocaleString()} Crux`}
                  </p>
                  <div className="flex items-center justify-center gap-2 flex-wrap">
                    <p className="text-xs text-muted-foreground">Drawn: </p>
                    {lastResult.drawnNumbers.map((n: number) => (
                      <Badge
                        key={n}
                        variant={lastResult.selectedNumbers.includes(n) ? "default" : "outline"}
                        className="font-mono text-xs"
                      >
                        {n}
                      </Badge>
                    ))}
                  </div>
                </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {history && history.length > 0 && (
        <Card className="neon-card bg-card/80 p-5">
          <div className="flex items-center gap-2 mb-3">
            <History className="w-4 h-4 text-muted-foreground" />
            <h3 className="text-xs font-bold text-foreground uppercase tracking-wider">Recent Games</h3>
          </div>
            <div className="space-y-2">
              {history.slice(0, 10).map((game: any) => {
                const won = Number(game.payout) > 0;
                const selected = JSON.parse(game.selectedNumbers);
                return (
                  <div
                    key={game.id}
                    className="flex items-center justify-between flex-wrap gap-2 border border-border/30 rounded-md p-3 text-sm"
                    data-testid={`keno-history-${game.id}`}
                  >
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={won ? "default" : "secondary"} className="text-[10px]">
                        {game.hits}/{selected.length}
                      </Badge>
                      <span className="font-mono text-muted-foreground text-xs">
                        {Number(game.multiplier)}x
                      </span>
                      <span className={`font-mono font-bold ${won ? "text-green-400" : "text-red-400"}`}>
                        {won ? `+${Number(game.payout).toLocaleString()}` : `-${Number(game.betAmount).toLocaleString()}`}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      Bet: {Number(game.betAmount).toLocaleString()} Crux
                    </span>
                  </div>
                );
              })}
            </div>
        </Card>
      )}
    </div>
  );
}
