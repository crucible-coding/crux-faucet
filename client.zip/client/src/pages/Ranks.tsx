import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";
import { getUserTier, TIER_PERKS, USER_TIERS, RANK_SUBSCRIPTIONS } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Crown, Loader2, CheckCircle, Zap, Clock, Coins, TrendingUp, Shield, Star, MessageCircle, Sparkles, Lock, Unlock, Gift, Trophy } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { SiEthereum } from "react-icons/si";

type RankPlan = {
  tier: string;
  monthlyPrice: number;
  monthlyCrux: number;
  priceId?: string;
  productId?: string;
};

type RankStatus = {
  hasSubscription: boolean;
  subscribedTier: string | null;
  nextBillingDate: string | null;
};

const tierColors: Record<string, string> = {
  Apprentice: "#94a3b8",
  Journeyman: "#22c55e",
  Foreman: "#3b82f6",
  Engineer: "#a855f7",
  Boss: "#f59e0b",
  Elite: "#ef4444",
};

const tierIcons: Record<string, typeof Star> = {
  Apprentice: Shield,
  Journeyman: Star,
  Foreman: Zap,
  Engineer: TrendingUp,
  Boss: Crown,
  Elite: Crown,
};

function getNextRaffleDate(): Date {
  const now = new Date();
  const year = now.getFullYear();
  const jan = new Date(year, 0, 1);
  const jul = new Date(year, 6, 1);
  if (now < jan) return jan;
  if (now < jul) return jul;
  return new Date(year + 1, 0, 1);
}

function getRaffleDaysRemaining(): number {
  const next = getNextRaffleDate();
  const now = new Date();
  return Math.max(0, Math.ceil((next.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
}

const PAST_RAFFLE_WINNERS = [
  { name: "Marcus T.", tier: "Elite", date: "July 2025", ethPrice: "$3,842" },
  { name: "Jessica K.", tier: "Boss", date: "January 2025", ethPrice: "$3,215" },
  { name: "Devon R.", tier: "Engineer", date: "July 2024", ethPrice: "$2,987" },
  { name: "Aaliyah M.", tier: "Foreman", date: "January 2024", ethPrice: "$2,450" },
  { name: "Chris W.", tier: "Elite", date: "July 2023", ethPrice: "$1,892" },
];

function RaffleWinnersBoard({ compact }: { compact?: boolean }) {
  const displayWinners = compact ? PAST_RAFFLE_WINNERS.slice(0, 3) : PAST_RAFFLE_WINNERS;

  return (
    <div className="space-y-2" data-testid="raffle-winners-board">
      <div className="flex items-center gap-2">
        <Trophy className="w-3.5 h-3.5 text-yellow-500" />
        <p className="text-xs font-bold text-foreground uppercase tracking-wider">Recent Winners</p>
      </div>
      <div className="space-y-1.5">
        {displayWinners.map((winner, i) => (
          <div
            key={i}
            className="flex items-center justify-between gap-2 rounded-md bg-background/40 border border-border/20 px-3 py-2"
            data-testid={`raffle-winner-${i}`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-6 h-6 rounded-full bg-[#627eea]/15 flex items-center justify-center shrink-0">
                <SiEthereum className="w-3 h-3 text-[#627eea]" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-foreground truncate">{winner.name}</p>
                <div className="flex items-center gap-1.5">
                  <Badge
                    variant="outline"
                    className="text-[8px] px-1 py-0 h-3.5 no-default-hover-elevate no-default-active-elevate"
                    style={{
                      borderColor: (tierColors[winner.tier] || "#94a3b8") + "40",
                      color: tierColors[winner.tier] || "#94a3b8",
                    }}
                  >
                    {winner.tier}
                  </Badge>
                  <span className="text-[10px] text-muted-foreground">{winner.date}</span>
                </div>
              </div>
            </div>
            <div className="text-right shrink-0">
              <p className="text-xs font-mono font-bold text-[#627eea]">1 ETH</p>
              <p className="text-[9px] text-muted-foreground">{winner.ethPrice}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RaffleBanner({ isSubscribed, compact }: { isSubscribed: boolean; compact?: boolean }) {
  const daysLeft = getRaffleDaysRemaining();
  const nextDate = getNextRaffleDate();
  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const dateLabel = `${monthNames[nextDate.getMonth()]} ${nextDate.getFullYear()}`;

  if (compact) {
    return (
      <Card className="neon-card overflow-visible" data-testid="raffle-banner-compact">
        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-[#627eea]/15 border border-[#627eea]/30 flex items-center justify-center shrink-0">
                <SiEthereum className="w-5 h-5 text-[#627eea]" />
              </div>
              <div>
                <p className="text-sm font-bold text-foreground">1 ETH Raffle</p>
                <p className="text-xs text-muted-foreground">
                  {isSubscribed ? (
                    <span className="text-green-400">You're entered</span>
                  ) : (
                    "Subscribe to any rank to enter"
                  )}
                  {" \u00b7 "}{daysLeft} days left
                </p>
              </div>
            </div>
            <Badge variant="outline" className="text-[10px] border-[#627eea]/30 text-[#627eea] no-default-hover-elevate no-default-active-elevate">
              {dateLabel}
            </Badge>
          </div>
          <RaffleWinnersBoard compact />
        </div>
      </Card>
    );
  }

  return (
    <Card className="neon-card overflow-visible relative" data-testid="raffle-banner">
      <div className="absolute inset-0 opacity-10 rounded-lg" style={{ background: "linear-gradient(135deg, #627eea 0%, #3b82f6 50%, #06b6d4 100%)" }} />
      <div className="relative p-6 space-y-5">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-lg bg-[#627eea]/15 border border-[#627eea]/30 flex items-center justify-center shrink-0">
              <SiEthereum className="w-7 h-7 text-[#627eea]" />
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-display font-bold text-foreground" data-testid="text-raffle-title">
                Win 1 Ethereum
              </h3>
              <p className="text-sm text-muted-foreground">
                Every 6 months, one lucky subscriber wins 1 full ETH
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold font-mono text-[#627eea]" data-testid="text-raffle-days">{daysLeft}</p>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">days left</p>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            {isSubscribed ? (
              <Badge className="bg-green-500/15 text-green-400 border-green-500/30" data-testid="badge-raffle-entered">
                <CheckCircle className="w-3 h-3 mr-1" />
                You're Entered
              </Badge>
            ) : (
              <Badge variant="outline" className="border-[#627eea]/30 text-[#627eea]">
                <Lock className="w-3 h-3 mr-1" />
                Subscribe to Enter
              </Badge>
            )}
            <span className="text-xs text-muted-foreground">Next drawing: {dateLabel}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Trophy className="w-3 h-3 text-yellow-500" />
            All ranked subscribers get 1 entry
          </div>
        </div>

        <RaffleWinnersBoard />
      </div>
    </Card>
  );
}

function CelebrationModal({ tier, crux, onClose }: { tier: string; crux: number; onClose: () => void }) {
  const color = tierColors[tier] || "#94a3b8";
  const perks = TIER_PERKS[tier as keyof typeof TIER_PERKS];
  const tierDef = USER_TIERS.find(t => t.name === tier);

  useEffect(() => {
    const end = Date.now() + 3000;
    const colors = [color, "#ffffff", "#06ffff"];
    (function frame() {
      confetti({ particleCount: 8, angle: 60, spread: 55, origin: { x: 0 }, colors });
      confetti({ particleCount: 8, angle: 120, spread: 55, origin: { x: 1 }, colors });
      if (Date.now() < end) requestAnimationFrame(frame);
    }());
  }, []);

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-lg border-border/50 bg-card p-0 gap-0 overflow-hidden" data-testid="dialog-rank-celebration">
        <DialogTitle className="sr-only">Rank Activated</DialogTitle>
        <DialogDescription className="sr-only">Congratulations on your new rank</DialogDescription>

        <div className="relative">
          <div
            className="absolute inset-0 opacity-20"
            style={{ background: `linear-gradient(135deg, ${color}40, transparent, ${color}20)` }}
          />

          <div className="relative p-8 text-center space-y-5">
            <motion.div
              initial={{ scale: 0, rotate: -20 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", bounce: 0.5, duration: 0.8 }}
            >
              <div
                className="w-20 h-20 rounded-xl mx-auto flex items-center justify-center mb-3"
                style={{ backgroundColor: color + "20", border: `2px solid ${color}60` }}
              >
                <Crown className="w-10 h-10" style={{ color }} />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-2"
            >
              <h2 className="text-2xl font-bold font-display text-foreground" data-testid="text-celebration-title">
                Congratulations!
              </h2>
              <p className="text-lg" style={{ color }}>
                You are now a <span className="font-bold">{tier}</span>
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-background/50 rounded-xl p-4 border border-border/30"
            >
              <div className="flex items-center justify-center gap-2 mb-3">
                <Coins className="w-5 h-5 text-primary" />
                <span className="text-xl font-bold font-mono text-primary" data-testid="text-celebration-crux">
                  +{crux.toLocaleString()} Crux
                </span>
              </div>
              <p className="text-xs text-muted-foreground">Added to your balance</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="space-y-3"
            >
              <p className="text-xs font-bold text-foreground uppercase tracking-wider flex items-center justify-center gap-1.5">
                <Unlock className="w-3.5 h-3.5 text-primary" />
                Perks Unlocked
              </p>
              <div className="grid grid-cols-2 gap-2 text-left">
                {perks && (
                  <>
                    <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                      <Zap className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                      <span className="text-xs text-foreground">{perks.faucetMultiplier}x Faucet</span>
                    </div>
                    <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                      <Clock className="w-3.5 h-3.5 text-green-400 shrink-0" />
                      <span className="text-xs text-foreground">{perks.cooldownMinutes}min Cooldown</span>
                    </div>
                    <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                      <TrendingUp className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                      <span className="text-xs text-foreground">{perks.maxHiloBet.toLocaleString()} Max Bet</span>
                    </div>
                    <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                      <Sparkles className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
                      <span className="text-xs text-foreground">{perks.boostChance}% Boost</span>
                    </div>
                  </>
                )}
                {tierDef && (
                  <>
                    <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                      <MessageCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="text-xs text-foreground">{tierDef.maxMessageLength} char chat</span>
                    </div>
                    {tierDef.canCustomColor && (
                      <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                        <Star className="w-3.5 h-3.5 shrink-0" style={{ color }} />
                        <span className="text-xs text-foreground">Custom chat color</span>
                      </div>
                    )}
                    {tierDef.canSendLinks && (
                      <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                        <Unlock className="w-3.5 h-3.5 text-green-400 shrink-0" />
                        <span className="text-xs text-foreground">Send links</span>
                      </div>
                    )}
                    {perks?.canStake && (
                      <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                        <Shield className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span className="text-xs text-foreground">{perks.stakingApy}% APY Staking</span>
                      </div>
                    )}
                  </>
                )}
                {perks?.dailyBonus > 0 && (
                  <div className="flex items-center gap-2 bg-background/40 rounded-md p-2">
                    <Coins className="w-3.5 h-3.5 text-primary shrink-0" />
                    <span className="text-xs text-foreground">{perks.dailyBonus} daily Crux</span>
                  </div>
                )}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 }}
            >
              <Button onClick={onClose} className="w-full" data-testid="button-celebration-close">
                <Sparkles className="w-4 h-4 mr-2" />
                Start Using Your Perks
              </Button>
            </motion.div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function Ranks() {
  const { toast } = useToast();
  const [celebrationTier, setCelebrationTier] = useState<string | null>(null);
  const [celebrationCrux, setCelebrationCrux] = useState(0);

  const { data: dashboardData } = useQuery<{ profile: { experience: number } }>({
    queryKey: ["/api/user/dashboard"],
  });

  const { data: ranks, isLoading: loadingRanks } = useQuery<RankPlan[]>({
    queryKey: [api.ranks.list.path],
  });

  const { data: rankStatus } = useQuery<RankStatus>({
    queryKey: [api.ranks.status.path],
  });

  const checkoutMutation = useMutation({
    mutationFn: async (tier: string) => {
      const res = await apiRequest("POST", api.ranks.checkout.path, { tier });
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const fulfillMutation = useMutation({
    mutationFn: async (tier: string) => {
      const res = await apiRequest("POST", "/api/ranks/fulfill", { tier });
      return await res.json();
    },
    onSuccess: (data, tier) => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/dashboard"] });
      queryClient.invalidateQueries({ queryKey: [api.ranks.status.path] });

      const rankInfo = RANK_SUBSCRIPTIONS[tier as keyof typeof RANK_SUBSCRIPTIONS];
      if (rankInfo) {
        setCelebrationTier(tier);
        setCelebrationCrux(rankInfo.monthlyCrux);
      } else {
        toast({ title: "Rank Activated", description: data.message });
      }
    },
    onError: () => {},
  });

  const fulfilledRef = useRef(false);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const success = params.get("success");
    const tier = params.get("tier");
    if (success === "true" && tier && !fulfilledRef.current) {
      fulfilledRef.current = true;
      const attemptFulfill = (retries: number) => {
        fulfillMutation.mutate(tier, {
          onError: () => {
            if (retries > 0) {
              setTimeout(() => attemptFulfill(retries - 1), 3000);
            }
          },
        });
      };
      setTimeout(() => attemptFulfill(3), 2000);
      window.history.replaceState({}, "", "/ranks");
    }
  }, []);

  const currentTier = getUserTier(dashboardData?.profile?.experience || 0);
  const currentTierName = currentTier.name;

  const tierOrder = ["Apprentice", "Journeyman", "Foreman", "Engineer", "Boss", "Elite"];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {celebrationTier && (
        <CelebrationModal
          tier={celebrationTier}
          crux={celebrationCrux}
          onClose={() => setCelebrationTier(null)}
        />
      )}

      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold font-display tracking-tight gradient-text-cyan-purple" data-testid="text-page-title">
          <Crown className="w-8 h-8 inline mr-2" />
          Rank Subscriptions
        </h1>
        <p className="text-sm text-muted-foreground">
          Subscribe monthly to instantly unlock tier perks + monthly Crux allowance
        </p>
        {rankStatus?.hasSubscription && (
          <Badge
            variant="outline"
            className="text-sm px-3 py-1"
            style={{ borderColor: tierColors[rankStatus.subscribedTier || ""] || "#94a3b8", color: tierColors[rankStatus.subscribedTier || ""] || "#94a3b8" }}
          >
            <CheckCircle className="w-3 h-3 mr-1" />
            Active: {rankStatus.subscribedTier} Subscription
          </Badge>
        )}
      </div>

      <RaffleBanner isSubscribed={rankStatus?.hasSubscription || false} />

      {loadingRanks ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(ranks || []).map((plan, idx) => {
            const color = tierColors[plan.tier] || "#94a3b8";
            const perks = TIER_PERKS[plan.tier as keyof typeof TIER_PERKS];
            const tierDef = USER_TIERS.find(t => t.name === plan.tier);
            const isCurrentSub = rankStatus?.subscribedTier === plan.tier;
            const tierIdx = tierOrder.indexOf(plan.tier);
            const currentTierIdx = tierOrder.indexOf(currentTierName);
            const IconComp = tierIcons[plan.tier] || Star;

            return (
              <motion.div
                key={plan.tier}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <Card
                  className={`neon-card p-5 relative overflow-visible ${
                    isCurrentSub ? "ring-1 ring-primary/40" : ""
                  }`}
                  style={{ borderColor: `${color}30` }}
                  data-testid={`rank-card-${plan.tier}`}
                >
                  {isCurrentSub && (
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground text-[10px]">
                        <CheckCircle className="w-3 h-3 mr-1" /> Active
                      </Badge>
                    </div>
                  )}

                  <div className="text-center mb-4">
                    <div
                      className="w-12 h-12 rounded-md flex items-center justify-center mx-auto mb-2"
                      style={{ backgroundColor: `${color}20`, border: `1px solid ${color}40` }}
                    >
                      <IconComp className="w-6 h-6" style={{ color }} />
                    </div>
                    <h3 className="font-display font-bold text-lg" style={{ color }} data-testid={`text-tier-name-${plan.tier}`}>
                      {plan.tier}
                    </h3>
                    <div className="mt-1">
                      <span className="text-2xl font-bold font-mono text-foreground">${plan.monthlyPrice}</span>
                      <span className="text-xs text-muted-foreground">/month</span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4 text-xs">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Coins className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span><strong className="text-foreground">{plan.monthlyCrux.toLocaleString()}</strong> Crux/month</span>
                    </div>
                    {perks && (
                      <>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Zap className="w-3 h-3 text-orange-400 shrink-0" />
                          <span>{perks.faucetMultiplier}x Faucet Multiplier</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="w-3 h-3 text-green-400 shrink-0" />
                          <span>{perks.cooldownMinutes}min Cooldown</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <TrendingUp className="w-3 h-3 text-purple-400 shrink-0" />
                          <span>{perks.maxHiloBet.toLocaleString()} Max Bet</span>
                        </div>
                        {perks.boostChance > 0 && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Sparkles className="w-3 h-3 text-yellow-400 shrink-0" />
                            <span>{perks.boostChance}% Random Boost</span>
                          </div>
                        )}
                        {perks.canStake && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Shield className="w-3 h-3 text-cyan-400 shrink-0" />
                            <span>{perks.stakingApy}% Staking APY</span>
                          </div>
                        )}
                      </>
                    )}
                    {tierDef && (
                      <>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MessageCircle className="w-3 h-3 text-blue-400 shrink-0" />
                          <span>{tierDef.maxMessageLength} char messages</span>
                        </div>
                        {tierDef.canCustomColor && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Star className="w-3 h-3 shrink-0" style={{ color }} />
                            <span>Custom chat color</span>
                          </div>
                        )}
                        {tierDef.canSendLinks && (
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Unlock className="w-3 h-3 text-green-400 shrink-0" />
                            <span>Send links in chat</span>
                          </div>
                        )}
                      </>
                    )}
                  </div>

                  <Button
                    className="w-full"
                    variant={isCurrentSub ? "outline" : "default"}
                    disabled={isCurrentSub || checkoutMutation.isPending}
                    onClick={() => checkoutMutation.mutate(plan.tier)}
                    data-testid={`button-subscribe-${plan.tier}`}
                  >
                    {checkoutMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-1" />
                    ) : isCurrentSub ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Subscribed
                      </>
                    ) : (
                      <>
                        <Crown className="w-4 h-4 mr-1" />
                        Subscribe
                      </>
                    )}
                  </Button>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      <Card className="neon-card bg-card/80 p-6">
        <div className="text-center space-y-3">
          <h3 className="font-display font-bold text-foreground uppercase tracking-wider text-sm">
            <Zap className="w-4 h-4 inline mr-1 text-primary" />
            How Subscriptions Work
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-muted-foreground">
            <div className="space-y-1">
              <p className="font-bold text-foreground">Instant Perks</p>
              <p>All tier perks activate immediately when you subscribe</p>
            </div>
            <div className="space-y-1">
              <p className="font-bold text-foreground">Monthly Crux</p>
              <p>Receive your Crux allowance each billing cycle</p>
            </div>
            <div className="space-y-1">
              <p className="font-bold text-foreground">Cancel Anytime</p>
              <p>No lock-in. Cancel and keep perks until the period ends</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
