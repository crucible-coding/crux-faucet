import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";
import { getUserTier, type Duel } from "@shared/schema";
import { PixelCharacter } from "@/components/PixelCharacter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Swords, Loader2, Trophy, XCircle, Clock, Users, Zap, Grid3X3, ArrowUpDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

function DuelResultDisplay({ duel, currentUserId }: { duel: Duel; currentUserId: string }) {
  const challengerWon = duel.winnerId === duel.challengerId;
  const payout = Number(duel.winnerPayout || 0);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-4 rounded-md border border-border/30 bg-card/40 space-y-4"
      data-testid={`duel-result-${duel.id}`}
    >
      <div className="flex items-center justify-center gap-2 text-sm font-bold text-primary uppercase tracking-wider">
        <Swords className="w-4 h-4" />
        {(duel.gameType || "hilo").toUpperCase()} Duel Result
      </div>

      <div className="flex items-center justify-center gap-6">
        <div className="flex flex-col items-center gap-2">
          <PixelCharacter avatarId="steve" size={80} facing="right" winner={challengerWon} loser={!challengerWon} idle={false} />
          <div className="text-center">
            <p className="text-xs font-bold text-foreground truncate max-w-[100px]">{duel.challengerName}</p>
            <p className="text-lg font-mono font-bold text-cyan-400" data-testid={`text-challenger-roll-${duel.id}`}>
              {duel.challengerRoll}
            </p>
          </div>
        </div>

        <div className="flex flex-col items-center gap-1">
          <span className="text-xs text-muted-foreground uppercase">vs</span>
          <Swords className="w-6 h-6 text-primary/60" />
        </div>

        <div className="flex flex-col items-center gap-2">
          <PixelCharacter avatarId="alex" size={80} facing="left" winner={!challengerWon} loser={challengerWon} idle={false} />
          <div className="text-center">
            <p className="text-xs font-bold text-foreground truncate max-w-[100px]">{duel.opponentName}</p>
            <p className="text-lg font-mono font-bold text-cyan-400" data-testid={`text-opponent-roll-${duel.id}`}>
              {duel.opponentRoll}
            </p>
          </div>
        </div>
      </div>

      <div className="text-center space-y-1">
        <motion.p
          className="text-sm font-bold"
          style={{
            color: duel.winnerId === currentUserId ? "#22c55e" : "#ef4444",
            textShadow: duel.winnerId === currentUserId ? "0 0 12px rgba(34,197,94,0.5)" : "0 0 12px rgba(239,68,68,0.4)",
          }}
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          data-testid={`text-winner-${duel.id}`}
        >
          <Trophy className="w-4 h-4 inline mr-1" />
          {challengerWon ? duel.challengerName : duel.opponentName} wins!
        </motion.p>
        <p className="text-xs text-muted-foreground font-mono" data-testid={`text-payout-${duel.id}`}>
          Payout: {payout.toLocaleString()} Crux (after 4% house cut)
        </p>
      </div>
    </motion.div>
  );
}

type OnlinePlayer = {
  userId: string;
  username: string;
  tier: string;
  avatar: string;
  lastSeen: string;
};

export default function Duels() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [betAmount, setBetAmount] = useState("100");
  const [gameType, setGameType] = useState<"hilo" | "keno">("hilo");
  const [targetUserId, setTargetUserId] = useState<string | undefined>(undefined);
  const [activeTab, setActiveTab] = useState("open");

  useEffect(() => {
    const interval = setInterval(() => {
      apiRequest("POST", api.online.heartbeat.path).catch(() => {});
    }, 30000);
    apiRequest("POST", api.online.heartbeat.path).catch(() => {});
    return () => clearInterval(interval);
  }, []);

  const { data: dashboardData } = useQuery<{ profile: { balance: string; experience: number; avatar: string } }>({
    queryKey: ["/api/user/dashboard"],
  });

  const { data: openDuels, isLoading: loadingOpen } = useQuery<Duel[]>({
    queryKey: [api.duel.list.path],
    refetchInterval: 5000,
  });

  const { data: historyDuels, isLoading: loadingHistory } = useQuery<Duel[]>({
    queryKey: [api.duel.history.path],
  });

  const { data: onlinePlayers } = useQuery<OnlinePlayer[]>({
    queryKey: [api.online.players.path],
    refetchInterval: 15000,
  });

  const createMutation = useMutation({
    mutationFn: async (data: { betAmount: number; gameType: string; targetUserId?: string }) => {
      const res = await apiRequest("POST", api.duel.create.path, data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.duel.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/dashboard"] });
      toast({ title: data.message });
      setBetAmount("100");
      setTargetUserId(undefined);
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const acceptMutation = useMutation({
    mutationFn: async (data: { duelId: number }) => {
      const res = await apiRequest("POST", api.duel.accept.path, data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.duel.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.duel.history.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/dashboard"] });
      toast({ title: data.message });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async (data: { duelId: number }) => {
      const res = await apiRequest("POST", api.duel.cancel.path, data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.duel.list.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/dashboard"] });
      toast({ title: data.message });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const balance = Number(dashboardData?.profile?.balance || 0);
  const bet = parseInt(betAmount) || 0;
  const experience = dashboardData?.profile?.experience || 0;
  const tier = getUserTier(experience);

  const quickBets = [50, 100, 500, 1000, 5000];

  const tierColors: Record<string, string> = {
    Apprentice: "#94a3b8",
    Journeyman: "#22c55e",
    Foreman: "#3b82f6",
    Engineer: "#a855f7",
    Boss: "#f59e0b",
    Elite: "#ef4444",
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="text-center space-y-1">
        <h1 className="text-3xl font-bold font-display tracking-tight gradient-text-cyan-purple" data-testid="text-page-title">
          <Swords className="w-8 h-8 inline mr-2" />
          Duel Arena
        </h1>
        <p className="text-sm text-muted-foreground">Challenge other players to PvP duels in Hi-Lo or Keno. Winner takes all (minus 4% house cut).</p>
      </div>

      {onlinePlayers && onlinePlayers.length > 0 && (
        <Card className="neon-card bg-card/80 p-4">
          <div className="flex items-center gap-2 mb-3">
            <Users className="w-4 h-4 text-green-400" />
            <h3 className="text-sm font-bold text-foreground uppercase tracking-wider">
              Online Players ({onlinePlayers.length})
            </h3>
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          </div>
          <div className="flex flex-wrap gap-2">
            {onlinePlayers.map((player) => (
              <motion.button
                key={player.userId}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setTargetUserId(player.userId === targetUserId ? undefined : player.userId);
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-md border transition-all cursor-pointer ${
                  targetUserId === player.userId
                    ? "border-primary bg-primary/10"
                    : "border-border/30 bg-card/50"
                }`}
                data-testid={`online-player-${player.userId}`}
              >
                <PixelCharacter avatarId={player.avatar} size={28} idle />
                <div className="text-left">
                  <p className="text-xs font-bold text-foreground">{player.username}</p>
                  <Badge
                    variant="outline"
                    className="text-[9px] px-1 py-0"
                    style={{ borderColor: tierColors[player.tier] || "#94a3b8", color: tierColors[player.tier] || "#94a3b8" }}
                  >
                    {player.tier}
                  </Badge>
                </div>
                {targetUserId === player.userId && (
                  <Swords className="w-3 h-3 text-primary" />
                )}
              </motion.button>
            ))}
          </div>
          {targetUserId && (
            <p className="text-xs text-primary mt-2">
              <Zap className="w-3 h-3 inline mr-1" />
              Targeting: {onlinePlayers.find(p => p.userId === targetUserId)?.username || "Selected player"} - They'll get a duel notification!
            </p>
          )}
        </Card>
      )}

      <Card className="neon-card bg-card/80 p-6">
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Swords className="w-5 h-5 text-primary" />
            <h2 className="font-display font-bold text-foreground uppercase tracking-wider text-sm">Create a Duel</h2>
          </div>

          <div className="text-center mb-2">
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Your Balance</p>
            <p className="text-xl font-bold font-mono text-foreground" data-testid="text-balance">
              {balance.toLocaleString()} Crux
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">Game Type</label>
              <Select value={gameType} onValueChange={(v) => setGameType(v as "hilo" | "keno")}>
                <SelectTrigger data-testid="select-game-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hilo">
                    <span className="flex items-center gap-2">
                      <ArrowUpDown className="w-3 h-3" />
                      Hi-Lo
                    </span>
                  </SelectItem>
                  <SelectItem value="keno">
                    <span className="flex items-center gap-2">
                      <Grid3X3 className="w-3 h-3" />
                      Keno
                    </span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground mb-2 block">Bet Amount (Crux)</label>
              <Input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(e.target.value)}
                min="10"
                max="1000000"
                className="font-mono"
                data-testid="input-bet-amount"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {quickBets.map((qb) => (
              <Button
                key={qb}
                variant="outline"
                size="sm"
                onClick={() => setBetAmount(qb.toString())}
                disabled={qb > balance}
                data-testid={`button-quickbet-${qb}`}
              >
                {qb.toLocaleString()}
              </Button>
            ))}
          </div>

          <Button
            className="w-full text-lg font-bold bg-primary text-primary-foreground"
            onClick={() => createMutation.mutate({ betAmount: bet, gameType, targetUserId })}
            disabled={createMutation.isPending || bet < 10 || bet > 1000000 || bet > balance}
            data-testid="button-create-duel"
          >
            {createMutation.isPending ? (
              <Loader2 className="w-5 h-5 animate-spin mr-2" />
            ) : (
              <Swords className="w-5 h-5 mr-2" />
            )}
            {createMutation.isPending
              ? "Creating..."
              : targetUserId
                ? `Challenge Player - ${bet.toLocaleString()} Crux ${gameType.toUpperCase()}`
                : `Create ${gameType.toUpperCase()} Duel - ${bet.toLocaleString()} Crux`
            }
          </Button>
        </div>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-2" data-testid="tabs-duels">
          <TabsTrigger value="open" data-testid="tab-open-duels">
            <Clock className="w-4 h-4 mr-1" />
            Open Duels
          </TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-history">
            <Trophy className="w-4 h-4 mr-1" />
            My History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="open" className="mt-4 space-y-3">
          {loadingOpen ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : !openDuels || openDuels.length === 0 ? (
            <Card className="neon-card bg-card/80 p-8 text-center">
              <Swords className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">No open duels right now. Create one!</p>
            </Card>
          ) : (
            <AnimatePresence>
              {openDuels.map((duel) => (
                <motion.div
                  key={duel.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <Card className="neon-card bg-card/80 p-4" data-testid={`card-duel-${duel.id}`}>
                    <div className="flex items-center justify-between gap-4 flex-wrap">
                      <div className="flex items-center gap-3">
                        <PixelCharacter avatarId="steve" size={48} facing="right" idle />
                        <div>
                          <p className="font-bold text-sm text-foreground" data-testid={`text-challenger-name-${duel.id}`}>
                            {duel.challengerName}
                          </p>
                          <div className="flex items-center gap-1">
                            <Badge variant="outline" className="text-[9px] px-1 py-0">
                              {(duel.gameType || "hilo").toUpperCase()}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {duel.targetUserId ? "Direct challenge" : "Open to all"}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="text-center">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">Bet</p>
                        <p className="text-lg font-mono font-bold text-cyan-400" data-testid={`text-bet-amount-${duel.id}`}>
                          {Number(duel.betAmount).toLocaleString()} Crux
                        </p>
                      </div>

                      <div>
                        {duel.challengerId === user?.id ? (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => cancelMutation.mutate({ duelId: duel.id })}
                            disabled={cancelMutation.isPending}
                            data-testid={`button-cancel-duel-${duel.id}`}
                          >
                            {cancelMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4 mr-1" />}
                            Cancel
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => acceptMutation.mutate({ duelId: duel.id })}
                            disabled={acceptMutation.isPending || Number(duel.betAmount) > balance}
                            data-testid={`button-accept-duel-${duel.id}`}
                          >
                            {acceptMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Swords className="w-4 h-4 mr-1" />}
                            Accept
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </TabsContent>

        <TabsContent value="history" className="mt-4 space-y-3">
          {loadingHistory ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : !historyDuels || historyDuels.length === 0 ? (
            <Card className="neon-card bg-card/80 p-8 text-center">
              <Trophy className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">No duel history yet. Challenge someone!</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {historyDuels.map((duel) => (
                <div key={duel.id}>
                  {duel.status === "completed" && duel.winnerId ? (
                    <DuelResultDisplay duel={duel} currentUserId={user?.id || ""} />
                  ) : (
                    <Card className="neon-card bg-card/80 p-4" data-testid={`card-history-duel-${duel.id}`}>
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <div>
                          <p className="text-sm font-bold text-foreground">
                            {duel.challengerName} vs {duel.opponentName || "???"}
                          </p>
                          <p className="text-xs text-muted-foreground font-mono">
                            {Number(duel.betAmount).toLocaleString()} Crux - {(duel.gameType || "hilo").toUpperCase()}
                          </p>
                        </div>
                        <span className="text-xs font-mono text-muted-foreground uppercase">{duel.status}</span>
                      </div>
                    </Card>
                  )}
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
