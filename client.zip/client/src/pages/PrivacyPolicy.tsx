import { Card } from "@/components/ui/card";
import { Shield } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Shield className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold font-display text-foreground" data-testid="text-privacy-title">Privacy Policy</h1>
        </div>
        <p className="text-sm text-muted-foreground">Last updated: February 18, 2026</p>
      </div>

      <Card className="p-6 space-y-6 text-sm text-foreground/90 leading-relaxed">
        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">1. Information We Collect</h2>
          <p className="mb-2">Crux Faucet is a cryptocurrency savings and investment platform. We collect information you provide directly when you:</p>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>Create an account using email/password or social login</li>
            <li>Use the faucet to claim free cryptocurrency rewards</li>
            <li>Participate in platform activities and investment features</li>
            <li>Communicate with other users through the community chat</li>
            <li>Purchase membership tiers through our subscription system</li>
          </ul>
          <p className="mt-3 mb-2">Information collected automatically includes:</p>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>Usage data (platform activity, faucet claims, transaction history)</li>
            <li>Device and browser information</li>
            <li>IP address and approximate location</li>
            <li>Cookies and similar tracking technologies</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">2. How We Use Your Information</h2>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>To provide, maintain, and improve our cryptocurrency savings platform</li>
            <li>To process transactions and manage your crypto wallet balances</li>
            <li>To verify your age and identity as required by law</li>
            <li>To ensure the provably fair integrity of all platform operations</li>
            <li>To communicate with you about your account and service updates</li>
            <li>To detect and prevent fraud, abuse, and security incidents</li>
            <li>To comply with applicable federal, state, and local laws</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">3. Information Sharing</h2>
          <p className="text-muted-foreground">
            We do not sell your personal information to third parties. We may share information with:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground mt-2">
            <li>Payment processors (Stripe) to process membership subscriptions and withdrawals</li>
            <li>Authentication service providers for secure account management</li>
            <li>Law enforcement when required by law or to protect our legal rights</li>
            <li>Service providers who assist us in operating the platform under strict confidentiality agreements</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">4. Your California Privacy Rights (CCPA/CPRA)</h2>
          <p className="text-muted-foreground mb-2">
            If you are a California resident, you have the following rights under the California Consumer Privacy Act (CCPA) and the California Privacy Rights Act (CPRA):
          </p>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li><strong className="text-foreground">Right to Know:</strong> Request what personal information we collect, use, disclose, and share about you.</li>
            <li><strong className="text-foreground">Right to Delete:</strong> Request deletion of your personal information, subject to certain exceptions.</li>
            <li><strong className="text-foreground">Right to Opt-Out:</strong> Opt out of the sale or sharing of your personal information. We do not sell your personal information.</li>
            <li><strong className="text-foreground">Right to Non-Discrimination:</strong> We will not discriminate against you for exercising your privacy rights.</li>
            <li><strong className="text-foreground">Right to Correct:</strong> Request correction of inaccurate personal information.</li>
            <li><strong className="text-foreground">Right to Limit Use:</strong> Limit the use of your sensitive personal information.</li>
          </ul>
          <p className="text-muted-foreground mt-3">
            To exercise these rights, please contact us through the platform's support channels. We will respond to verifiable consumer requests within 45 days.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">5. Do Not Sell My Personal Information</h2>
          <p className="text-muted-foreground">
            We do not sell, rent, or trade your personal information to third parties for monetary or other valuable consideration. If our practices change in the future, we will update this policy and provide you with the ability to opt out.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">6. Cookies and Tracking</h2>
          <p className="text-muted-foreground mb-2">
            We use cookies and similar technologies to:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
            <li>Maintain your session and authentication state</li>
            <li>Remember your preferences (theme, display settings)</li>
            <li>Analyze usage patterns to improve our platform</li>
          </ul>
          <p className="text-muted-foreground mt-2">
            You can control cookie preferences through your browser settings. Disabling essential cookies may affect the functionality of our services.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">7. Data Security</h2>
          <p className="text-muted-foreground">
            We implement industry-standard security measures to protect your personal information, including encryption of sensitive data, secure authentication protocols, and regular security audits. However, no method of electronic transmission or storage is 100% secure.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">8. Data Retention</h2>
          <p className="text-muted-foreground">
            We retain your personal information for as long as your account is active or as needed to provide our services. We may retain certain information as required by law or for legitimate business purposes such as resolving disputes and enforcing our agreements.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">9. Age Requirement</h2>
          <p className="text-muted-foreground">
            Our platform is intended for individuals 21 years of age and older. We do not knowingly collect personal information from individuals under 21. If we discover that we have collected information from someone under 21, we will take steps to delete it promptly.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">10. Governing Law</h2>
          <p className="text-muted-foreground">
            This Privacy Policy is governed by the laws of the State of Nevada, without regard to its conflict of laws provisions, and applicable federal laws including CCPA/CPRA for California residents.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">11. Changes to This Policy</h2>
          <p className="text-muted-foreground">
            We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
          </p>
        </section>

        <section>
          <h2 className="text-lg font-bold text-foreground mb-2">12. Contact Us</h2>
          <p className="text-muted-foreground">
            If you have questions about this Privacy Policy or wish to exercise your privacy rights, please contact us through the platform's support channels.
          </p>
        </section>
      </Card>
    </div>
  );
}
