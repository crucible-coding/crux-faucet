import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import { SiGoogle, SiApple, SiFacebook } from "react-icons/si";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

import cruxLogoDark from "@assets/6C3D0F33-0C60-4291-91CC-087E152520DE_1771538612388.png";
import cruxLogoBlueprint from "@assets/E8D84844-E946-4380-B45B-E09988DEA2CC_1771583769146.png";
import cruxGoldShield from "@assets/A4E47610-CC26-492E-B199-C72B07D28390_1771583769146.png";

/* ⭐ 5× BIG — MOBILE SAFE */
const SPLASH_LOGO =
  "w-[320px] xs:w-[380px] sm:w-[520px] md:w-[750px] lg:w-[900px]";
const HERO_LOGO =
  "w-[380px] xs:w-[460px] sm:w-[700px] md:w-[1100px] lg:w-[1500px]";

export default function Landing() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { login, register, isLoggingIn, isRegistering } = useAuth();
  const { toast } = useToast();

  const { data: authStatus } = useQuery<{ providers: Record<string, boolean> }>({
    queryKey: ["/api/auth/status"],
  });

  const isSubmitting = isLoggingIn || isRegistering;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      if (mode === "login") await login({ email, password });
      else await register({ email, password });
    } catch (err: any) {
      toast({
        title: "Auth Failed",
        description: err.message,
        variant: "destructive",
      });
    }
  }

  function handleSocialClick(provider: string) {
    const key = provider.toLowerCase();
    const ok = authStatus?.providers?.[key];
    if (ok) window.location.href = `/api/auth/${key}`;
  }

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">

      {/* blueprint bg */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage: `url(${cruxLogoBlueprint})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />

      <main className="relative z-10 max-w-6xl mx-auto px-4 py-10">

        {/* SPLASH */}
        <motion.section className="text-center mb-12">

          <motion.img
            src={cruxLogoDark}
            alt="CruxCrypto.com"
            className={`${SPLASH_LOGO} mx-auto mb-6 drop-shadow-2xl will-change-transform`}
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
          />

          <h2 className="text-3xl md:text-5xl text-primary">
            Your Gateway to Crypto
          </h2>
        </motion.section>

        {/* HERO */}
        <div className="flex flex-col lg:flex-row gap-6 items-center">

          <div className="flex-1 text-center lg:text-left">

            <motion.img
              src={cruxLogoDark}
              alt="CruxCrypto.com"
              className={`${HERO_LOGO} max-w-full mx-auto lg:mx-0 mb-6 drop-shadow-2xl will-change-transform`}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
            />

            <Badge className="mb-4">Provably Fair Crypto Faucet</Badge>

            <h1 className="text-3xl md:text-4xl font-bold mb-3">
              Earn Free Crux Every Hour
            </h1>

            <p className="text-muted-foreground max-w-md mx-auto lg:mx-0">
              Claim BTC, ETH, USDC every hour.
            </p>
          </div>

          {/* AUTH */}
          <div className="w-full max-w-sm">
            <Card className="p-6">

              <div className="flex gap-3 mb-5">
                <Button variant="outline" className="flex-1" onClick={()=>handleSocialClick("Google")}><SiGoogle/></Button>
                <Button variant="outline" className="flex-1" onClick={()=>handleSocialClick("Apple")}><SiApple/></Button>
                <Button variant="outline" className="flex-1" onClick={()=>handleSocialClick("Facebook")}><SiFacebook/></Button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3">
                <Input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/>
                <Input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/>

                <Button className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="animate-spin mr-2"/> : null}
                  {mode==="login"?"Sign In":"Create"}
                </Button>
              </form>

              <p className="text-xs text-center mt-4">
                {mode==="login"
                  ? <button onClick={()=>setMode("signup")}>Sign Up</button>
                  : <button onClick={()=>setMode("login")}>Sign In</button>}
              </p>

            </Card>
          </div>
        </div>

        {/* CTA */}
        <div
          className="relative rounded-xl overflow-hidden mt-16 border border-primary/10"
          style={{
            backgroundImage:`url(${cruxGoldShield})`,
            backgroundSize:"contain",
            backgroundRepeat:"no-repeat",
            backgroundPosition:"center"
          }}
        >
          <div className="text-center py-12">
            <p className="text-3xl md:text-4xl font-extrabold">
              Sign Up for Your Free Faucet
            </p>
          </div>
        </div>

      </main>
    </div>
  );
}