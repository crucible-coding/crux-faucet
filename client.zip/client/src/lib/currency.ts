const BTC_SATS = 100_000_000;

let cachedBtcPrice: number | null = null;
let lastFetchTime = 0;
const CACHE_DURATION = 5 * 60 * 1000;

export async function fetchBtcPrice(): Promise<number> {
  const now = Date.now();
  if (cachedBtcPrice && now - lastFetchTime < CACHE_DURATION) {
    return cachedBtcPrice;
  }

  try {
    const res = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd");
    if (res.ok) {
      const data = await res.json();
      cachedBtcPrice = data.bitcoin.usd;
      lastFetchTime = now;
      return cachedBtcPrice!;
    }
  } catch {
  }

  return cachedBtcPrice || 100000;
}

export function satsToUsd(sats: number, btcPrice: number): string {
  const btc = sats / BTC_SATS;
  const usd = btc * btcPrice;
  if (usd < 0.01) {
    return `$${usd.toFixed(6)}`;
  }
  return `$${usd.toFixed(2)}`;
}

export function formatSats(sats: number): string {
  return sats.toLocaleString();
}
