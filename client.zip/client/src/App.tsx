import { useState } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useMutation, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { useUserDashboard } from "@/hooks/use-faucet";
import { Loader2, ShieldAlert, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

// Pages
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import Faucet from "@/pages/Faucet";
import Wallet from "@/pages/Wallet";
import HiLo from "@/pages/HiLo";
import Crash from "@/pages/Crash";
import Bitcoin from "@/pages/Bitcoin";
import Chat from "@/pages/Chat";
import Staking from "@/pages/Staking";
import Keno from "@/pages/Keno";
import Duels from "@/pages/Duels";
import Inbox from "@/pages/Inbox";
import Ranks from "@/pages/Ranks";
import Leaderboard from "@/pages/Leaderboard";
import PrivacyPolicy from "@/pages/PrivacyPolicy";
import TermsOfService from "@/pages/TermsOfService";

// Components
import { Sidebar } from "@/components/Sidebar";
import { TopBar } from "@/components/TopBar";
import { CookieConsent } from "@/components/CookieConsent";
import { CashoutPopups } from "@/components/CashoutPopups";
import AiChat from "@/components/AiChat";

import bgBlueprint from "@assets/E8D84844-E946-4380-B45B-E09988DEA2CC_1771583769146.png";
import bgLogoWatermark from "@assets/2DF682A5-5CD9-4C88-B4B2-C135566AF02C_1771583769146.png";

function AgeGate() {
  const { logout } = useAuth();
  const qc = useQueryClient();
  const [declined, setDeclined] = useState(false);

  const verifyMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/verify-age", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ confirmed: true }),
      });
      if (!res.ok) throw new Error("Verification failed");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/user/dashboard"] });
    },
  });

  if (declined) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <Card className="max-w-md w-full p-8 text-center space-y-4">
          <AlertTriangle className="w-12 h-12 text-yellow-500 mx-auto" />
          <h2 className="text-xl font-bold text-foreground">Access Denied</h2>
          <p className="text-sm text-muted-foreground">
            You must be 21 years or older to use Crux Faucet. You have been signed out.
          </p>
          <Button variant="outline" onClick={() => logout()} data-testid="button-age-signout">
            Return to Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <Card className="max-w-md w-full p-8 text-center space-y-5">
        <ShieldAlert className="w-14 h-14 text-primary mx-auto" />
        <h2 className="text-2xl font-bold text-foreground">Age Verification Required</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Welcome to <span className="text-primary font-bold">Crux</span>, a Crucible Forge website.
          You must be at least <span className="font-bold text-foreground">21 years old</span> to use this platform.
        </p>
        <p className="text-xs text-muted-foreground">
          By clicking "I am 21 or older" you confirm that you meet the minimum age requirement.
        </p>
        <div className="space-y-3 pt-2">
          <Button
            className="w-full"
            onClick={() => verifyMutation.mutate()}
            disabled={verifyMutation.isPending}
            data-testid="button-confirm-age"
          >
            {verifyMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            I am 21 or older
          </Button>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => { setDeclined(true); logout(); }}
            data-testid="button-decline-age"
          >
            I am under 21
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground leading-relaxed pt-2">
          Investing in cryptocurrency is volatile and carries risk. Past performance does not guarantee future results.
        </p>
      </Card>
    </div>
  );
}

function CryptoDisclaimer() {
  return (
    <footer className="border-t border-border/30 bg-card/30 backdrop-blur-sm py-4 px-6 text-center" data-testid="footer-disclaimer">
      <p className="text-[11px] text-muted-foreground leading-relaxed max-w-2xl mx-auto">
        Investing in cryptocurrency is volatile and carries significant risk. The value of digital assets can fluctuate widely and you may lose some or all of your investment.
        This platform does not provide financial advice. Always do your own research before making investment decisions.
        Crux is a Crucible Forge product.
      </p>
    </footer>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();
  const { data: dashData, isLoading: dashLoading } = useUserDashboard();
  const [, setLocation] = useLocation();

  if (isLoading || dashLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-primary">
        <Loader2 className="w-10 h-10 animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  if (dashData?.profile && !dashData.profile.ageVerified) {
    return <AgeGate />;
  }

  return (
    <div className="flex min-h-screen bg-background text-foreground font-body selection:bg-primary/30 bg-gradient-mesh">
      <div className="fixed inset-0 bg-grid-pattern opacity-20 pointer-events-none" />
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url(${bgBlueprint})`,
          backgroundSize: "800px",
          backgroundPosition: "center",
          backgroundRepeat: "repeat",
        }}
      />
      <div
        className="fixed inset-0 pointer-events-none flex items-center justify-center opacity-[0.025]"
      >
        <img src={bgLogoWatermark} alt="" className="w-[500px] max-w-[60vw]" />
      </div>
      <Sidebar />
      <div className="flex-1 lg:ml-64 flex flex-col relative z-10">
        <TopBar />
        <main className="flex-1 p-5 lg:p-7 overflow-x-hidden pt-20 lg:pt-5">
          <Component />
        </main>
        <CryptoDisclaimer />
      </div>
      <CashoutPopups />
    </div>
  );
}

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-primary">
        <Loader2 className="w-10 h-10 animate-spin" />
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/">
        {isAuthenticated ? (
          <ProtectedRoute component={Faucet} />
        ) : (
          <Landing />
        )}
      </Route>

      <Route path="/faucet">
        <ProtectedRoute component={Faucet} />
      </Route>
      <Route path="/wallet">
        <ProtectedRoute component={Wallet} />
      </Route>
      <Route path="/crash">
        <ProtectedRoute component={Crash} />
      </Route>
      <Route path="/hilo">
        <ProtectedRoute component={HiLo} />
      </Route>
      <Route path="/keno">
        <ProtectedRoute component={Keno} />
      </Route>
      <Route path="/bitcoin">
        <ProtectedRoute component={Bitcoin} />
      </Route>
      <Route path="/chat">
        <ProtectedRoute component={Chat} />
      </Route>
      <Route path="/staking">
        <ProtectedRoute component={Staking} />
      </Route>
      <Route path="/duels">
        <ProtectedRoute component={Duels} />
      </Route>
      <Route path="/inbox">
        <ProtectedRoute component={Inbox} />
      </Route>
      <Route path="/ranks">
        <ProtectedRoute component={Ranks} />
      </Route>
      <Route path="/leaderboard">
        <ProtectedRoute component={Leaderboard} />
      </Route>
      <Route path="/privacy" component={PrivacyPolicy} />
      <Route path="/terms" component={TermsOfService} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
        <CookieConsent />
        <AiChat />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;