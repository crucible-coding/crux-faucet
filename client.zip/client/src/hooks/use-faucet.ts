import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type FaucetStatusResponse, type FaucetClaimResponse, type UserDashboardResponse } from "@shared/routes";

export function useUserDashboard() {
  return useQuery({
    queryKey: [api.user.dashboard.path],
    queryFn: async () => {
      const res = await fetch(api.user.dashboard.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch dashboard data");
      return api.user.dashboard.responses[200].parse(await res.json());
    },
  });
}

export function useFaucetStatus() {
  return useQuery({
    queryKey: [api.faucet.status.path],
    queryFn: async () => {
      const res = await fetch(api.faucet.status.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch faucet status");
      return api.faucet.status.responses[200].parse(await res.json());
    },
    refetchInterval: 60000, 
  });
}

export function useClaimFaucet() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (cryptos?: string | string[]) => {
      const cryptoArray = Array.isArray(cryptos) ? cryptos : [cryptos || "usdc"];
      const res = await fetch(api.faucet.claim.path, {
        method: api.faucet.claim.method,
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cryptos: cryptoArray }),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Cooldown active");
        }
        throw new Error("Failed to claim faucet");
      }
      
      return api.faucet.claim.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.faucet.status.path] });
      queryClient.invalidateQueries({ queryKey: [api.user.dashboard.path] });
      queryClient.invalidateQueries({ queryKey: [api.cryptoWallets?.list?.path] });
    },
  });
}
