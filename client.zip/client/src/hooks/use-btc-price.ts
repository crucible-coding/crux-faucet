import { useQuery } from "@tanstack/react-query";
import { fetchBtcPrice, satsToUsd } from "@/lib/currency";

export function useBtcPrice() {
  const { data: btcPrice } = useQuery({
    queryKey: ["btc-price"],
    queryFn: fetchBtcPrice,
    refetchInterval: 5 * 60 * 1000,
    staleTime: 5 * 60 * 1000,
  });

  const convertToUsd = (sats: number) => {
    if (!btcPrice) return "";
    return satsToUsd(sats, btcPrice);
  };

  return { btcPrice: btcPrice || 0, convertToUsd };
}
