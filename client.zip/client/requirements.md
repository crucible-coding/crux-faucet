## Packages
framer-motion | For smooth page transitions and micro-interactions
canvas-confetti | For the winning animation when a user rolls
@types/canvas-confetti | Types for confetti
date-fns | For formatting dates and calculating time differences

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
