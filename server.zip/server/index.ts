import express from "express";
import { createServer } from "http";
import { runMigrations } from "stripe-replit-sync";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic } from "./vite";
import { getStripeSync, getStripePublishableKey } from "./stripeClient";
import { WebhookHandlers } from "./webhookHandlers";

const app = express();

async function initStripe() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.error("[Stripe] DATABASE_URL not set, skipping Stripe init");
    return;
  }

  try {
    console.log("[Stripe] Initializing schema...");
    await runMigrations({ databaseUrl, schema: "stripe" });
    console.log("[Stripe] Schema ready");

    const stripeSync = await getStripeSync();

    console.log("[Stripe] Setting up managed webhook...");
    const webhookBaseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;
    try {
      const webhookResult = await stripeSync.findOrCreateManagedWebhook(
        `${webhookBaseUrl}/api/stripe/webhook`
      );
      console.log(`[Stripe] Webhook configured:`, webhookResult?.webhook?.url || "OK");
    } catch (whErr: any) {
      console.warn("[Stripe] Webhook setup warning:", whErr.message);
    }

    stripeSync
      .syncBackfill()
      .then(() => console.log("[Stripe] Data synced"))
      .catch((err: any) => console.error("[Stripe] Sync error:", err));
  } catch (error) {
    console.error("[Stripe] Init failed:", error);
  }
}

(async () => {
  await initStripe();

  app.post(
    "/api/stripe/webhook",
    express.raw({ type: "application/json" }),
    async (req, res) => {
      const signature = req.headers["stripe-signature"];
      if (!signature) {
        return res.status(400).json({ error: "Missing stripe-signature" });
      }
      try {
        const sig = Array.isArray(signature) ? signature[0] : signature;
        if (!Buffer.isBuffer(req.body)) {
          console.error("[Stripe] Webhook body is not a Buffer");
          return res.status(500).json({ error: "Webhook processing error" });
        }
        await WebhookHandlers.processWebhook(req.body as Buffer, sig);
        res.status(200).json({ received: true });
      } catch (error: any) {
        console.error("[Stripe] Webhook error:", error.message);
        res.status(400).json({ error: "Webhook processing error" });
      }
    }
  );

  app.get("/api/stripe/publishable-key", async (_req, res) => {
    try {
      const key = await getStripePublishableKey();
      res.json({ publishableKey: key });
    } catch {
      res.json({ publishableKey: "" });
    }
  });

  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));

  await setupAuth(app);
  registerAuthRoutes(app);
  registerRoutes(app);

  const server = createServer(app);

  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });

  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = 5000;
  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running on port ${port}`);
  });
})();
