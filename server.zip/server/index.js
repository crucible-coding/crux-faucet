import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { spawn } from "child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

process.env.NODE_ENV = process.env.NODE_ENV || "development";

const tsxBin = path.resolve(__dirname, "..", "node_modules", ".bin", "tsx");
const child = spawn(tsxBin, [path.resolve(__dirname, "index.ts")], {
  stdio: "inherit",
  env: process.env,
  cwd: path.resolve(__dirname, ".."),
});

child.on("exit", (code) => {
  process.exit(code || 0);
});
