import type { Express } from "express";
import crypto from "crypto";
import { isAuthenticated } from "./replit_integrations/auth";
import { storage } from "./storage";
import { getUserTier, getTierPerks, canUseCustomChatColor, getAvailableAvatars, getAvailableDuelClasses, calculateEloChange, TIER_PERKS, RANK_SUBSCRIPTIONS, SUPPORTED_CRYPTOS } from "@shared/schema";
import { getUncachableStripeClient } from "./stripeClient";
import { db } from "./db";
import { sql } from "drizzle-orm";
import { buildLiquidityState, computeHealth, getMode, getRewardMultiplier, getCooldown, canWithdraw, getUnlockRate, isEmergency, tickUnlockBalance, mapTierToUserTier, TIER_WITHDRAW_LIMITS, DAILY_BUDGET_LIMIT, WHALE_THRESHOLD } from "./liquidityController";
import { openai } from "./replit_integrations/audio/client";

function getSessionUserId(req: any): string {
  return req.session?.userId;
}

async function getOrCreateProfile(userId: string) {
  let profile = await storage.getProfile(userId);
  if (!profile) {
    profile = await storage.createProfile(userId);
  }
  return profile;
}

function generateServerSeed(): string {
  return crypto.randomBytes(32).toString("hex");
}

function hashSeed(seed: string): string {
  return crypto.createHash("sha256").update(seed).digest("hex");
}

function computeRoll(serverSeed: string, clientSeed: string, nonce: number): number {
  const combined = `${serverSeed}-${clientSeed}-${nonce}`;
  const hash = crypto.createHash("sha256").update(combined).digest("hex");
  const hex = hash.substring(0, 8);
  return parseInt(hex, 16) % 10000;
}

function getFaucetPayout(roll: number): number {
  if (roll === 0) return 50000;
  if (roll <= 10) return 5000;
  if (roll <= 100) return 500;
  if (roll <= 1000) return 50;
  if (roll <= 5000) return 10;
  return 5;
}

async function getLiquidityFactor(): Promise<number> {
  const state = await buildLiquidityState();
  const health = computeHealth(state);
  return getRewardMultiplier(health);
}

function computeCrashPoint(serverSeed: string, clientSeed: string, nonce: number): number {
  const combined = `${serverSeed}-${clientSeed}-${nonce}-crash`;
  const hash = crypto.createHash("sha256").update(combined).digest("hex");
  const h = parseInt(hash.substring(0, 8), 16);
  const e = Math.pow(2, 32);
  const houseEdge = 0.04;
  const result = (1 - houseEdge) * e / (e - h);
  return Math.max(1.0, Math.floor(result * 100) / 100);
}

const KENO_MULTIPLIERS: Record<number, Record<number, number>> = {
  1: { 0: 0, 1: 3.5 },
  2: { 0: 0, 1: 1, 2: 9 },
  3: { 0: 0, 1: 0, 2: 2.5, 3: 25 },
  4: { 0: 0, 1: 0, 2: 1.5, 3: 8, 4: 75 },
  5: { 0: 0, 1: 0, 2: 1, 3: 3, 4: 15, 5: 200 },
  6: { 0: 0, 1: 0, 2: 0, 3: 2, 4: 6, 5: 50, 6: 500 },
  7: { 0: 0, 1: 0, 2: 0, 3: 1, 4: 4, 5: 15, 6: 100, 7: 1000 },
  8: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 2, 5: 8, 6: 50, 7: 250, 8: 2500 },
  9: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 1, 5: 5, 6: 20, 7: 100, 8: 500, 9: 5000 },
  10: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 3, 6: 10, 7: 50, 8: 250, 9: 1000, 10: 5000 },
};

function drawKenoNumbers(serverSeed: string, clientSeed: string, nonce: number, count: number): number[] {
  const drawn: number[] = [];
  let i = 0;
  while (drawn.length < count) {
    const combined = `${serverSeed}-${clientSeed}-${nonce}-keno-${i}`;
    const hash = crypto.createHash("sha256").update(combined).digest("hex");
    const num = (parseInt(hash.substring(0, 8), 16) % 40) + 1;
    if (!drawn.includes(num)) {
      drawn.push(num);
    }
    i++;
  }
  return drawn;
}

export function registerRoutes(app: Express) {
  app.get("/api/faucet/status", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);
      const cooldownMs = perks.cooldownMinutes * 60 * 1000;

      let canClaim = true;
      let nextRollAvailableAt: string | null = null;

      if (profile.lastHourlyRoll) {
        const nextAvailable = new Date(profile.lastHourlyRoll.getTime() + cooldownMs);
        if (nextAvailable > new Date()) {
          canClaim = false;
          nextRollAvailableAt = nextAvailable.toISOString();
        }
      }

      res.json({ canClaim, nextRollAvailableAt });
    } catch (error) {
      console.error("Faucet status error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/faucet/claim", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);
      const cooldownMs = perks.cooldownMinutes * 60 * 1000;

      if (profile.lastHourlyRoll) {
        const nextAvailable = new Date(profile.lastHourlyRoll.getTime() + cooldownMs);
        if (nextAvailable > new Date()) {
          return res.status(400).json({
            message: "Cooldown active",
            nextRollAvailableAt: nextAvailable.toISOString(),
          });
        }
      }

      const serverSeed = profile.serverSeed || generateServerSeed();
      const clientSeed = profile.clientSeed || "cruxfaucet";
      const nonce = profile.nonce;
      const roll = computeRoll(serverSeed, clientSeed, nonce);
      let basePayout = getFaucetPayout(roll);
      basePayout = Math.floor(basePayout * perks.faucetMultiplier);
      const lf = await getLiquidityFactor();
      const payout = Math.max(1, Math.floor(basePayout * lf));

      const newServerSeed = generateServerSeed();
      const newServerSeedHash = hashSeed(newServerSeed);
      const newBalance = (parseFloat(profile.balance) + payout).toString();
      const xpGain = Math.max(1, Math.floor(basePayout / 10));

      await storage.updateProfile(userId, {
        balance: newBalance,
        lastHourlyRoll: new Date(),
        serverSeed: newServerSeed,
        serverSeedHash: newServerSeedHash,
        nonce: nonce + 1,
        experience: profile.experience + xpGain,
        totalGamesPlayed: profile.totalGamesPlayed + 1,
      });

      await storage.createTransaction({
        userId,
        amount: payout.toString(),
        type: "faucet_claim",
        description: `Faucet roll: ${roll.toString().padStart(4, "0")} - Won ${payout} Crux`,
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
        rollResult: roll.toString().padStart(4, "0"),
      });

      const cryptos = req.body?.cryptos || ["usdc"];
      const splitAmount = Math.floor(payout / cryptos.length);
      const cryptoSplit = cryptos.map((c: string) => {
        const cryptoDef = SUPPORTED_CRYPTOS.find(sc => sc.id === c);
        return {
          crypto: c,
          symbol: cryptoDef?.symbol || c.toUpperCase(),
          amount: splitAmount,
        };
      });

      const nextAvailable = new Date(Date.now() + cooldownMs);

      res.json({
        amount: payout.toString(),
        newBalance,
        nextRollAvailableAt: nextAvailable.toISOString(),
        message: `You rolled ${roll.toString().padStart(4, "0")} and won ${payout} Crux!`,
        rolledValue: roll.toString().padStart(4, "0"),
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
        newServerSeedHash,
        cryptoSplit,
      });
    } catch (error) {
      console.error("Faucet claim error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/provably-fair/settings", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      res.json({
        serverSeedHash: profile.serverSeedHash || "",
        clientSeed: profile.clientSeed || "cruxfaucet",
        nonce: profile.nonce,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/provably-fair/client-seed", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { clientSeed } = req.body;
      if (!clientSeed || typeof clientSeed !== "string" || clientSeed.length > 64) {
        return res.status(400).json({ message: "Invalid client seed" });
      }
      await storage.updateProfile(userId, { clientSeed });
      res.json({ clientSeed, message: "Client seed updated" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/provably-fair/rotate-seed", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const previousServerSeed = profile.serverSeed || "";
      const newServerSeed = generateServerSeed();
      const newServerSeedHash = hashSeed(newServerSeed);
      await storage.updateProfile(userId, {
        serverSeed: newServerSeed,
        serverSeedHash: newServerSeedHash,
      });
      res.json({
        previousServerSeed,
        newServerSeedHash,
        message: "Server seed rotated",
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/provably-fair/verify", async (req, res) => {
    try {
      const { serverSeed, clientSeed, nonce } = req.body;
      if (!serverSeed || !clientSeed || nonce === undefined) {
        return res.status(400).json({ message: "Missing parameters" });
      }
      const result = computeRoll(serverSeed, clientSeed, nonce);
      const hash = hashSeed(serverSeed);
      res.json({
        result: result.toString().padStart(4, "0"),
        hash,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/hilo/play", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { betAmount, guess } = req.body;

      if (!betAmount || !guess || !["higher", "lower"].includes(guess)) {
        return res.status(400).json({ message: "Invalid bet or guess" });
      }

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      if (betAmount > perks.maxHiloBet) {
        return res.status(400).json({ message: `Max bet for your tier is ${perks.maxHiloBet}` });
      }
      if (parseFloat(profile.balance) < betAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const serverSeed = profile.serverSeed || generateServerSeed();
      const clientSeed = profile.clientSeed || "cruxfaucet";
      const nonce = profile.nonce;

      const currentNumber = (computeRoll(serverSeed, clientSeed, nonce) % 100) + 1;
      const nextNumber = (computeRoll(serverSeed, clientSeed, nonce + 1) % 100) + 1;

      let won = false;
      if (guess === "higher" && nextNumber > currentNumber) won = true;
      if (guess === "lower" && nextNumber < currentNumber) won = true;
      if (nextNumber === currentNumber) won = false;

      const multiplier = won ? 1.9 : 0;
      let basePayout = won ? Math.floor(betAmount * multiplier) : 0;

      let newStreak = won ? profile.hiloStreak + 1 : 0;
      if (won && newStreak >= 3 && perks.streakBonus > 0) {
        const streakBonusAmount = Math.floor(basePayout * (perks.streakBonus / 100));
        basePayout += streakBonusAmount;
      }

      const lf = await getLiquidityFactor();
      const payout = won ? Math.max(1, Math.floor(basePayout * lf)) : 0;

      const balanceChange = won ? payout - betAmount : -betAmount;
      const newBalance = (parseFloat(profile.balance) + balanceChange).toString();
      const xpGain = won ? Math.max(1, Math.floor(betAmount / 100)) : 1;

      const newServerSeed = generateServerSeed();
      const newServerSeedHash = hashSeed(newServerSeed);

      await storage.updateProfile(userId, {
        balance: newBalance,
        hiloStreak: newStreak,
        serverSeed: newServerSeed,
        serverSeedHash: newServerSeedHash,
        nonce: nonce + 2,
        experience: profile.experience + xpGain,
        totalGamesPlayed: profile.totalGamesPlayed + 1,
      });

      await storage.createHiloGame({
        userId,
        betAmount: betAmount.toString(),
        currentNumber,
        nextNumber,
        guess,
        won,
        payout: payout.toString(),
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
      });

      await storage.createTransaction({
        userId,
        amount: balanceChange.toString(),
        type: "hilo",
        description: won ? `Hi-Lo: Won ${payout} Crux` : `Hi-Lo: Lost ${betAmount} Crux`,
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
        rollResult: `${currentNumber}-${nextNumber}`,
      });

      res.json({
        currentNumber,
        nextNumber,
        guess,
        won,
        betAmount: betAmount.toString(),
        payout: payout.toString(),
        newBalance,
        multiplier: multiplier.toString(),
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
      });
    } catch (error) {
      console.error("HiLo error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/hilo/history", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const history = await storage.getHiloHistory(userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/keno/play", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { betAmount, selectedNumbers } = req.body;

      if (!betAmount || !selectedNumbers || !Array.isArray(selectedNumbers) || selectedNumbers.length < 1 || selectedNumbers.length > 10) {
        return res.status(400).json({ message: "Invalid bet or number selection" });
      }

      const profile = await getOrCreateProfile(userId);
      if (parseFloat(profile.balance) < betAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const serverSeed = profile.serverSeed || generateServerSeed();
      const clientSeed = profile.clientSeed || "cruxfaucet";
      const nonce = profile.nonce;

      const drawnNumbers = drawKenoNumbers(serverSeed, clientSeed, nonce, 10);
      const hits = selectedNumbers.filter((n: number) => drawnNumbers.includes(n)).length;
      const numSelected = selectedNumbers.length;
      const multiplierTable = KENO_MULTIPLIERS[numSelected] || {};
      const multiplier = multiplierTable[hits] || 0;
      const basePayout = Math.floor(betAmount * multiplier);
      const lf = await getLiquidityFactor();
      const payout = basePayout > betAmount ? Math.floor(betAmount + (basePayout - betAmount) * lf) : basePayout;
      const balanceChange = payout - betAmount;
      const newBalance = (parseFloat(profile.balance) + balanceChange).toString();

      const newServerSeed = generateServerSeed();
      const newServerSeedHash = hashSeed(newServerSeed);

      await storage.updateProfile(userId, {
        balance: newBalance,
        serverSeed: newServerSeed,
        serverSeedHash: newServerSeedHash,
        nonce: nonce + 1,
        experience: profile.experience + 1,
        totalGamesPlayed: profile.totalGamesPlayed + 1,
      });

      await storage.createKenoGame({
        userId,
        betAmount: betAmount.toString(),
        selectedNumbers: JSON.stringify(selectedNumbers),
        drawnNumbers: JSON.stringify(drawnNumbers),
        hits,
        payout: payout.toString(),
        multiplier: multiplier.toString(),
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
      });

      await storage.createTransaction({
        userId,
        amount: balanceChange.toString(),
        type: "keno",
        description: `Keno: ${hits} hits, ${multiplier}x multiplier`,
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
        rollResult: drawnNumbers.join(","),
      });

      res.json({
        selectedNumbers,
        drawnNumbers,
        hits,
        multiplier: multiplier.toString(),
        betAmount: betAmount.toString(),
        payout: payout.toString(),
        newBalance,
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
      });
    } catch (error) {
      console.error("Keno error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/keno/history", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const history = await storage.getKenoHistory(userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/crash/play", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { betAmount } = req.body;
      if (!betAmount || betAmount < 1) {
        return res.status(400).json({ message: "Invalid bet amount" });
      }

      const profile = await getOrCreateProfile(userId);
      if (parseFloat(profile.balance) < betAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const serverSeed = profile.serverSeed || generateServerSeed();
      const clientSeed = profile.clientSeed || "cruxfaucet";
      const nonce = profile.nonce;
      const crashPoint = computeCrashPoint(serverSeed, clientSeed, nonce);

      const newBalance = (parseFloat(profile.balance) - betAmount).toString();
      await storage.updateProfile(userId, { balance: newBalance });

      const game = await storage.createCrashGame({
        userId,
        betAmount: betAmount.toString(),
        crashPoint: crashPoint.toString(),
        cashedOutAt: null,
        payout: "0",
        won: false,
        serverSeed,
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
        clientSeed,
        nonce,
      });

      res.json({
        gameId: game.id,
        crashPoint: crashPoint.toString(),
        serverSeedHash: profile.serverSeedHash || hashSeed(serverSeed),
      });
    } catch (error) {
      console.error("Crash play error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/crash/cashout", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { gameId, cashoutAt } = req.body;

      const game = await storage.getCrashGame(gameId);
      if (!game || game.userId !== userId) {
        return res.status(400).json({ message: "Game not found" });
      }
      if (game.cashedOutAt) {
        return res.status(400).json({ message: "Already cashed out" });
      }

      const crashPoint = parseFloat(game.crashPoint);
      const won = cashoutAt <= crashPoint;
      const betAmt = parseFloat(game.betAmount);
      const basePayout = won ? Math.floor(betAmt * cashoutAt) : 0;
      const lf = await getLiquidityFactor();
      const payout = basePayout > betAmt ? Math.floor(betAmt + (basePayout - betAmt) * lf) : basePayout;

      await storage.updateCrashGame(gameId, {
        cashedOutAt: cashoutAt.toString(),
        payout: payout.toString(),
        won,
      });

      const profile = await getOrCreateProfile(userId);
      const newBalance = (parseFloat(profile.balance) + payout).toString();

      const newServerSeed = generateServerSeed();
      const newServerSeedHash = hashSeed(newServerSeed);

      await storage.updateProfile(userId, {
        balance: newBalance,
        serverSeed: newServerSeed,
        serverSeedHash: newServerSeedHash,
        nonce: profile.nonce + 1,
        experience: profile.experience + (won ? Math.max(1, Math.floor(payout / 100)) : 1),
        totalGamesPlayed: profile.totalGamesPlayed + 1,
      });

      await storage.createTransaction({
        userId,
        amount: (payout - parseFloat(game.betAmount)).toString(),
        type: "crash",
        description: won ? `Crash: Cashed out at ${cashoutAt}x, won ${payout} Crux` : `Crash: Crashed at ${crashPoint}x, lost ${game.betAmount} Crux`,
        serverSeed: game.serverSeed,
        serverSeedHash: game.serverSeedHash,
        clientSeed: game.clientSeed,
        nonce: game.nonce,
        rollResult: crashPoint.toString(),
      });

      res.json({
        won,
        crashPoint: game.crashPoint,
        cashedOutAt: cashoutAt.toString(),
        payout: payout.toString(),
        newBalance,
        serverSeed: game.serverSeed || "",
        serverSeedHash: game.serverSeedHash || "",
        clientSeed: game.clientSeed || "",
        nonce: game.nonce || 0,
      });
    } catch (error) {
      console.error("Crash cashout error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/crash/history", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const history = await storage.getCrashHistory(userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/chat/messages", isAuthenticated, async (req, res) => {
    try {
      const messages = await storage.getChatMessages();
      res.json(messages.reverse());
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/chat/send", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { message } = req.body;
      if (!message || typeof message !== "string" || message.trim().length === 0) {
        return res.status(400).json({ message: "Message is required" });
      }

      const profile = await getOrCreateProfile(userId);
      const user = await storage.getUser(userId);
      const tier = getUserTier(profile.experience);
      const username = user?.firstName || user?.email || "Anonymous";

      const msg = await storage.createChatMessage({
        userId,
        username,
        message: message.trim().substring(0, tier.maxMessageLength),
        tier: tier.name,
        chatColor: profile.chatColor,
      });

      res.json(msg);
    } catch (error) {
      console.error("Chat send error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/chat/color", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { color } = req.body;
      if (!color || !/^#[0-9a-fA-F]{6}$/.test(color)) {
        return res.status(400).json({ message: "Invalid hex color" });
      }

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      if (!canUseCustomChatColor(tier.name)) {
        return res.status(403).json({ message: "Your tier does not allow custom chat colors" });
      }

      await storage.updateProfile(userId, { chatColor: color });
      res.json({ chatColor: color, message: "Chat color updated" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/daily-bonus/status", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      if (perks.dailyBonus === 0) {
        return res.json({ canClaim: false, nextAvailableAt: null, bonusAmount: 0 });
      }

      let canClaim = true;
      let nextAvailableAt: string | null = null;

      if (profile.lastDailyBonus) {
        const nextAvailable = new Date(profile.lastDailyBonus.getTime() + 24 * 60 * 60 * 1000);
        if (nextAvailable > new Date()) {
          canClaim = false;
          nextAvailableAt = nextAvailable.toISOString();
        }
      }

      res.json({ canClaim, nextAvailableAt, bonusAmount: perks.dailyBonus });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/daily-bonus/claim", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      if (perks.dailyBonus === 0) {
        return res.status(400).json({ message: "Your tier does not receive daily bonuses" });
      }

      if (profile.lastDailyBonus) {
        const nextAvailable = new Date(profile.lastDailyBonus.getTime() + 24 * 60 * 60 * 1000);
        if (nextAvailable > new Date()) {
          return res.status(400).json({ message: "Daily bonus already claimed" });
        }
      }

      const lf = await getLiquidityFactor();
      const dailyPayout = Math.max(1, Math.floor(perks.dailyBonus * lf));
      const newBalance = (parseFloat(profile.balance) + dailyPayout).toString();
      await storage.updateProfile(userId, {
        balance: newBalance,
        lastDailyBonus: new Date(),
      });

      await storage.createTransaction({
        userId,
        amount: perks.dailyBonus.toString(),
        type: "daily_bonus",
        description: `Daily bonus: ${perks.dailyBonus} Crux (${tier.name} tier)`,
        serverSeed: null,
        serverSeedHash: null,
        clientSeed: null,
        nonce: null,
        rollResult: null,
      });

      res.json({
        amount: perks.dailyBonus,
        newBalance,
        tierName: tier.name,
        message: `Claimed ${perks.dailyBonus} Crux daily bonus!`,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/staking/create", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { satoshiAmount } = req.body;

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      if (!perks.canStake) {
        return res.status(400).json({ message: "Your tier cannot stake" });
      }
      if (parseFloat(profile.balance) < satoshiAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const btcPrice = 50000;
      const ethPrice = 3000;
      const btcAmount = satoshiAmount / 100000000;
      const usdValue = btcAmount * btcPrice;
      const ethAmount = usdValue / ethPrice;

      const unlocksAt = new Date(Date.now() + 60 * 24 * 60 * 60 * 1000);

      const stake = await storage.createStake({
        userId,
        satoshiAmount: satoshiAmount.toString(),
        ethAmount: ethAmount.toString(),
        ethAddress: `0x${crypto.randomBytes(20).toString("hex")}`,
        btcPriceAtStake: btcPrice.toString(),
        ethPriceAtStake: ethPrice.toString(),
        status: "locked",
        stakedAt: new Date(),
        unlocksAt,
        withdrawnAt: null,
      });

      const newBalance = (parseFloat(profile.balance) - satoshiAmount).toString();
      await storage.updateProfile(userId, { balance: newBalance });

      res.json({
        stake,
        message: "Stake created successfully",
        newBalance,
        stakingApy: perks.stakingApy,
      });
    } catch (error) {
      console.error("Staking create error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/staking/list", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const userStakes = await storage.getStakes(userId);
      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      const totalEthStaked = userStakes.reduce((sum, s) => sum + parseFloat(s.ethAmount), 0);
      const totalSatoshiStaked = userStakes.reduce((sum, s) => sum + parseFloat(s.satoshiAmount), 0);

      res.json({
        stakes: userStakes,
        totalEthStaked: totalEthStaked.toString(),
        totalSatoshiStaked: totalSatoshiStaked.toString(),
        stakingApy: perks.stakingApy,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/staking/withdraw", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { stakeId } = req.body;

      const stake = await storage.getStake(stakeId);
      if (!stake || stake.userId !== userId) {
        return res.status(400).json({ message: "Stake not found" });
      }
      if (stake.status !== "locked") {
        return res.status(400).json({ message: "Stake already withdrawn" });
      }
      if (new Date(stake.unlocksAt) > new Date()) {
        return res.status(400).json({ message: "Stake is still locked" });
      }

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      const daysLocked = Math.floor((Date.now() - new Date(stake.stakedAt).getTime()) / (24 * 60 * 60 * 1000));
      const apyReward = parseFloat(stake.ethAmount) * (perks.stakingApy / 100) * (daysLocked / 365);
      const ethWithRewards = parseFloat(stake.ethAmount) + apyReward;
      const satoshiReturned = parseFloat(stake.satoshiAmount);

      await storage.updateStake(stakeId, {
        status: "withdrawn",
        withdrawnAt: new Date(),
      });

      const newBalance = (parseFloat(profile.balance) + satoshiReturned).toString();
      await storage.updateProfile(userId, { balance: newBalance });

      res.json({
        message: "Stake withdrawn successfully",
        ethAmount: stake.ethAmount,
        ethWithRewards: ethWithRewards.toString(),
        satoshiReturned: satoshiReturned.toString(),
        newBalance,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/staking/prices", async (req, res) => {
    try {
      const btcPrice = 50000;
      const ethPrice = 3000;
      res.json({
        btcPrice,
        ethPrice,
        btcToEthRate: btcPrice / ethPrice,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/wallet/withdraw", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { amount, btcAddress } = req.body;

      if (!amount || amount < 1) {
        return res.status(400).json({ message: "Invalid amount" });
      }

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);

      if (parseFloat(profile.balance) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const tierLimit = TIER_WITHDRAW_LIMITS[tier.name] || 50_000;
      if (amount > tierLimit) {
        return res.status(400).json({
          message: `Your tier allows withdrawals up to ${tierLimit.toLocaleString()} Crux per transaction.`,
          reason: "tier_limit",
          maxAmount: tierLimit,
        });
      }

      if (amount > WHALE_THRESHOLD) {
        return res.status(400).json({
          message: "Large withdrawals require manual approval. Please contact support.",
          reason: "whale_review",
        });
      }

      const liquidityState = await buildLiquidityState();
      const health = computeHealth(liquidityState);
      const mode = getMode(health);

      const cooldownMs = getCooldown(tier.name, mode);
      if (profile.lastWithdrawal && cooldownMs > 0) {
        const cooldownEnd = new Date(profile.lastWithdrawal.getTime() + cooldownMs);
        if (cooldownEnd > new Date()) {
          const minutesLeft = Math.ceil((cooldownEnd.getTime() - Date.now()) / 60000);
          return res.status(429).json({
            message: `Withdrawal cooldown active. Available in ${minutesLeft} minutes.`,
            reason: "cooldown",
            retryAfterMinutes: minutesLeft,
            cooldownEndsAt: cooldownEnd.toISOString(),
          });
        }
      }

      const { newSpendable, newLastTick } = tickUnlockBalance(profile, mode);

      const userState = {
        tier: mapTierToUserTier(tier.name),
        lastWithdrawalAt: profile.lastWithdrawal ? profile.lastWithdrawal.getTime() : undefined,
        balanceUnlocked: newSpendable,
        requestedAmount: amount,
      };

      const result = canWithdraw(liquidityState, userState);

      if (!result.allowed) {
        const messages: Record<string, string> = {
          daily_budget: "Daily withdrawal limit reached. Please try again tomorrow.",
          locked_balance: `Only ${Math.floor(newSpendable).toLocaleString()} Crux is currently unlocked. The rest is still vesting.`,
          liquidity_low: "Withdrawals temporarily delayed — system reserves are low. Try again soon.",
        };
        return res.status(result.reason === "daily_budget" ? 429 : 400).json({
          message: messages[result.reason] || "Withdrawal not available right now.",
          reason: result.reason,
          queued: true,
          spendableBalance: Math.floor(newSpendable),
        });
      }

      const btcPrice = 50000;
      const usdValue = (amount / 100000000) * btcPrice;
      if (usdValue < perks.withdrawMinUsd) {
        return res.status(400).json({ message: `Minimum withdrawal is $${perks.withdrawMinUsd}` });
      }

      const newBalance = (parseFloat(profile.balance) - amount).toString();
      const newSpendableAfter = Math.max(0, newSpendable - amount);
      const newTotalWithdrawn = (parseFloat(profile.totalWithdrawn || "0") + amount).toString();

      await storage.updateProfile(userId, {
        balance: newBalance,
        spendableBalance: newSpendableAfter.toString(),
        lastUnlockTick: newLastTick,
        lastWithdrawal: new Date(),
        withdrawalCount: profile.withdrawalCount + 1,
        totalWithdrawn: newTotalWithdrawn,
      });

      await storage.createTransaction({
        userId,
        amount: (-amount).toString(),
        type: "withdraw",
        description: `Withdrawal of ${amount} Crux to ${btcAddress}`,
        serverSeed: null,
        serverSeedHash: null,
        clientSeed: null,
        nonce: null,
        rollResult: null,
      });

      res.json({
        message: "Withdrawal initiated",
        newBalance,
        spendableBalance: newSpendableAfter,
        withdrawalCount: profile.withdrawalCount + 1,
        mode,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/liquidity/status", isAuthenticated, async (req, res) => {
    try {
      const state = await buildLiquidityState();
      const health = computeHealth(state);
      const mode = getMode(health);
      const multiplier = getRewardMultiplier(health);

      res.json({
        mode,
        healthScore: health,
        liquidityFactor: multiplier,
        emergencyMode: isEmergency(state),
        rewardMultiplier: `${Math.round(multiplier * 100)}%`,
        unlockRate: getUnlockRate(mode),
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/wallet/withdraw-status", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);

      const state = await buildLiquidityState();
      const health = computeHealth(state);
      const mode = getMode(health);

      const { newSpendable } = tickUnlockBalance(profile, mode);
      const balance = parseFloat(profile.balance);
      const locked = Math.max(0, balance - newSpendable);
      const tierLimit = TIER_WITHDRAW_LIMITS[tier.name] || 50_000;

      let cooldownRemaining = 0;
      if (profile.lastWithdrawal) {
        const cooldownMs = getCooldown(tier.name, mode);
        const cooldownEnd = new Date(profile.lastWithdrawal.getTime() + cooldownMs);
        if (cooldownEnd > new Date()) {
          cooldownRemaining = Math.ceil((cooldownEnd.getTime() - Date.now()) / 60000);
        }
      }

      const dailyBudgetRemaining = Math.max(0, state.dailyBudgetLimit - state.dailyBudgetUsed);

      res.json({
        balance: Math.floor(balance),
        spendableBalance: Math.floor(newSpendable),
        lockedBalance: Math.floor(locked),
        tierLimit,
        cooldownMinutesRemaining: cooldownRemaining,
        withdrawalCount: profile.withdrawalCount,
        totalWithdrawn: Math.floor(parseFloat(profile.totalWithdrawn || "0")),
        dailyBudgetRemaining: Math.floor(dailyBudgetRemaining),
        systemMode: mode,
        healthScore: health,
        canWithdraw: cooldownRemaining === 0 && !isEmergency(state) && newSpendable > 0 && dailyBudgetRemaining > 0,
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/user/dashboard", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const profile = await getOrCreateProfile(userId);
      const txns = await storage.getTransactions(userId, 20);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);
      const cooldownMs = perks.cooldownMinutes * 60 * 1000;

      let nextRollAvailableAt: string | null = null;
      if (profile.lastHourlyRoll) {
        const nextAvailable = new Date(profile.lastHourlyRoll.getTime() + cooldownMs);
        if (nextAvailable > new Date()) {
          nextRollAvailableAt = nextAvailable.toISOString();
        }
      }

      res.json({ profile, transactions: txns, nextRollAvailableAt });
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/referral/apply", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { code } = req.body;

      if (!code) {
        return res.status(400).json({ message: "Referral code is required" });
      }

      const profile = await getOrCreateProfile(userId);
      if (profile.referredBy) {
        return res.status(400).json({ message: "You have already used a referral code" });
      }

      if (profile.referralCode === code) {
        return res.status(400).json({ message: "You cannot use your own referral code" });
      }

      const referrerProfiles = await storage.getProfile(code);
      if (!referrerProfiles) {
        return res.status(400).json({ message: "Invalid referral code" });
      }

      const referrerBonus = 100;
      const referredBonus = 50;

      await storage.updateProfile(userId, {
        referredBy: code,
        balance: (parseFloat(profile.balance) + referredBonus).toString(),
      });

      const newBalance = (parseFloat(profile.balance) + referredBonus).toString();
      res.json({ message: `Referral applied! You received ${referredBonus} Crux`, newBalance });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/avatar/update", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { avatarId } = req.body;
      if (!avatarId) {
        return res.status(400).json({ message: "Avatar ID is required" });
      }

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const available = getAvailableAvatars(tier.name);
      if (!available.find(a => a.id === avatarId)) {
        return res.status(400).json({ message: "Avatar not available for your tier" });
      }

      await storage.updateProfile(userId, { avatar: avatarId });
      res.json({ avatar: avatarId, message: "Avatar updated" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/duel/create", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { betAmount, gameType, targetUserId } = req.body;

      const profile = await getOrCreateProfile(userId);
      const user = await storage.getUser(userId);

      if (parseFloat(profile.balance) < betAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const serverSeed = generateServerSeed();
      const serverSeedHash = hashSeed(serverSeed);

      const newBalance = (parseFloat(profile.balance) - betAmount).toString();
      await storage.updateProfile(userId, { balance: newBalance });

      const duel = await storage.createDuel({
        challengerId: userId,
        challengerName: user?.firstName || "Anonymous",
        opponentId: null,
        opponentName: null,
        targetUserId: targetUserId || null,
        gameType: gameType || "hilo",
        betAmount: betAmount.toString(),
        status: "open",
        challengerRoll: null,
        opponentRoll: null,
        winnerId: null,
        winnerPayout: null,
        serverSeed,
        serverSeedHash,
        clientSeed: profile.clientSeed || "cruxfaucet",
        nonce: profile.nonce,
      });

      res.json({ duel, message: "Duel created", newBalance });
    } catch (error) {
      console.error("Duel create error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/duel/accept", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { duelId } = req.body;

      const duel = await storage.getDuel(duelId);
      if (!duel || duel.status !== "open") {
        return res.status(400).json({ message: "Duel not available" });
      }
      if (duel.challengerId === userId) {
        return res.status(400).json({ message: "Cannot accept your own duel" });
      }

      const profile = await getOrCreateProfile(userId);
      const user = await storage.getUser(userId);
      const betAmount = parseFloat(duel.betAmount);

      if (parseFloat(profile.balance) < betAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const challengerRoll = computeRoll(duel.serverSeed || "", duel.clientSeed || "", duel.nonce || 0);
      const opponentRoll = computeRoll(duel.serverSeed || "", duel.clientSeed || "", (duel.nonce || 0) + 1);

      const challengerWins = challengerRoll > opponentRoll;
      const isDraw = challengerRoll === opponentRoll;
      const winnerId = isDraw ? null : (challengerWins ? duel.challengerId : userId);
      const winnerPayout = isDraw ? betAmount : betAmount * 2 * 0.95;

      const newBalance = (parseFloat(profile.balance) - betAmount).toString();
      await storage.updateProfile(userId, { balance: newBalance });

      if (winnerId) {
        const winnerProfile = await storage.getProfile(winnerId);
        if (winnerProfile) {
          const winnerNewBalance = (parseFloat(winnerProfile.balance) + winnerPayout).toString();
          await storage.updateProfile(winnerId, { balance: winnerNewBalance });
        }

        const loserId = winnerId === userId ? duel.challengerId : userId;
        const { winnerGain, loserLoss } = calculateEloChange(
          winnerId === userId ? profile.duelElo : 1200,
          winnerId === userId ? 1200 : profile.duelElo
        );

        const winnerP = await storage.getProfile(winnerId);
        if (winnerP) {
          await storage.updateProfile(winnerId, {
            duelWins: winnerP.duelWins + 1,
            duelElo: winnerP.duelElo + winnerGain,
          });
        }

        const loserP = await storage.getProfile(loserId);
        if (loserP) {
          await storage.updateProfile(loserId, {
            duelLosses: loserP.duelLosses + 1,
            duelElo: Math.max(0, loserP.duelElo - loserLoss),
          });
        }
      } else {
        const challengerProfile = await storage.getProfile(duel.challengerId);
        if (challengerProfile) {
          await storage.updateProfile(duel.challengerId, {
            balance: (parseFloat(challengerProfile.balance) + betAmount).toString(),
          });
        }
        await storage.updateProfile(userId, {
          balance: (parseFloat(profile.balance)).toString(),
        });
      }

      const updatedDuel = await storage.updateDuel(duelId, {
        opponentId: userId,
        opponentName: user?.firstName || "Anonymous",
        challengerRoll,
        opponentRoll,
        winnerId,
        winnerPayout: winnerPayout.toString(),
        status: "completed",
        resolvedAt: new Date(),
      });

      const updatedProfile = await storage.getProfile(userId);
      res.json({
        duel: updatedDuel,
        message: winnerId === userId ? "You won!" : winnerId ? "You lost" : "Draw!",
        newBalance: updatedProfile?.balance || newBalance,
      });
    } catch (error) {
      console.error("Duel accept error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/duel/cancel", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { duelId } = req.body;

      const duel = await storage.getDuel(duelId);
      if (!duel || duel.challengerId !== userId || duel.status !== "open") {
        return res.status(400).json({ message: "Cannot cancel this duel" });
      }

      await storage.updateDuel(duelId, { status: "cancelled" });

      const profile = await storage.getProfile(userId);
      const newBalance = (parseFloat(profile!.balance) + parseFloat(duel.betAmount)).toString();
      await storage.updateProfile(userId, { balance: newBalance });

      res.json({ message: "Duel cancelled", newBalance });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/duel/list", isAuthenticated, async (req, res) => {
    try {
      const openDuels = await storage.getOpenDuels();
      res.json(openDuels);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/duel/history", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const history = await storage.getDuelHistory(userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/inbox/messages", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const messages = await storage.getInboxMessages(userId);
      const unreadCount = messages.filter(m => !m.isRead).length;
      res.json({ messages, unreadCount });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/inbox/read", isAuthenticated, async (req, res) => {
    try {
      const { messageId } = req.body;
      await storage.updateInboxMessage(messageId, { isRead: true });
      res.json({ message: "Message marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/inbox/verify-email", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { messageId } = req.body;

      await storage.updateInboxMessage(messageId, { actionCompleted: true });
      const profile = await getOrCreateProfile(userId);
      const bonus = 100;
      const newBalance = (parseFloat(profile.balance) + bonus).toString();
      await storage.updateProfile(userId, {
        emailVerified: true,
        balance: newBalance,
      });

      res.json({ message: "Email verified! You received a bonus.", newBalance });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/ranks/list", async (req, res) => {
    try {
      const ranks = [];
      for (const [tier, info] of Object.entries(RANK_SUBSCRIPTIONS)) {
        let priceId: string | undefined;
        let productId: string | undefined;
        try {
          const result = await db.execute(
            sql`SELECT p.id as product_id, pr.id as price_id
                FROM stripe.products p
                JOIN stripe.prices pr ON pr.product = p.id AND pr.active = true
                WHERE p.active = true AND p.metadata->>'crux_tier' = ${tier}
                LIMIT 1`
          );
          if (result.rows.length > 0) {
            priceId = result.rows[0].price_id as string;
            productId = result.rows[0].product_id as string;
          }
        } catch {}
        ranks.push({
          tier,
          monthlyPrice: info.monthlyPriceUsd,
          monthlyCrux: info.monthlyCrux,
          description: info.description,
          priceId,
          productId,
        });
      }
      res.json(ranks);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/ranks/checkout", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { tier } = req.body;

      if (!tier || !RANK_SUBSCRIPTIONS[tier as keyof typeof RANK_SUBSCRIPTIONS]) {
        return res.status(400).json({ message: "Invalid tier" });
      }

      const result = await db.execute(
        sql`SELECT p.id as product_id, pr.id as price_id
            FROM stripe.products p
            JOIN stripe.prices pr ON pr.product = p.id AND pr.active = true
            WHERE p.active = true AND p.metadata->>'crux_tier' = ${tier}
            LIMIT 1`
      );

      if (result.rows.length === 0) {
        return res.status(400).json({ message: "Subscription product not found for this tier. Please try again later." });
      }

      const priceId = result.rows[0].price_id as string;
      const stripe = await getUncachableStripeClient();

      const user = await storage.getUser(userId);
      let customerId: string | undefined;

      if (user?.email) {
        const customers = await stripe.customers.list({ email: user.email, limit: 1 });
        if (customers.data.length > 0) {
          customerId = customers.data[0].id;
        } else {
          const customer = await stripe.customers.create({
            email: user.email,
            metadata: { userId, tier },
          });
          customerId = customer.id;
        }
      }

      const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ["card"],
        line_items: [{ price: priceId, quantity: 1 }],
        mode: "subscription",
        success_url: `${baseUrl}/ranks?success=true&tier=${tier}`,
        cancel_url: `${baseUrl}/ranks?canceled=true`,
        metadata: { userId, tier },
      });

      res.json({ url: session.url });
    } catch (error: any) {
      console.error("[Stripe Checkout] Error:", error.message);
      res.status(500).json({ message: "Failed to create checkout session" });
    }
  });

  app.post("/api/ranks/fulfill", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { tier } = req.body;

      if (!tier || !RANK_SUBSCRIPTIONS[tier as keyof typeof RANK_SUBSCRIPTIONS]) {
        return res.status(400).json({ message: "Invalid tier" });
      }

      const stripe = await getUncachableStripeClient();
      const user = await storage.getUser(userId);

      if (!user?.email) {
        return res.status(400).json({ message: "User email not found" });
      }

      const customers = await stripe.customers.list({ email: user.email, limit: 1 });
      if (customers.data.length === 0) {
        return res.status(400).json({ message: "No payment found. Please complete checkout first." });
      }

      const subs = await stripe.subscriptions.list({
        customer: customers.data[0].id,
        status: "active",
        limit: 10,
      });

      let verified = false;
      for (const sub of subs.data) {
        const productId = sub.items.data[0]?.price?.product;
        if (productId) {
          const product = await stripe.products.retrieve(productId as string);
          if (product.metadata?.crux_tier === tier) {
            verified = true;
            break;
          }
        }
      }

      if (!verified) {
        return res.status(403).json({ message: "No active subscription found for this tier. Please complete checkout first." });
      }

      const rankInfo = RANK_SUBSCRIPTIONS[tier as keyof typeof RANK_SUBSCRIPTIONS];
      const profile = await getOrCreateProfile(userId);

      const tierOrder = ["Apprentice", "Journeyman", "Foreman", "Engineer", "Boss", "Elite"];
      const targetIdx = tierOrder.indexOf(tier);
      const currentTier = getUserTier(profile.experience);
      const currentIdx = tierOrder.indexOf(currentTier.name);

      if (targetIdx <= currentIdx) {
        return res.json({ message: "Already at or above this tier", tier: currentTier.name });
      }

      const targetTierDef = [
        { name: "Apprentice", xpRequired: 0 },
        { name: "Journeyman", xpRequired: 1000 },
        { name: "Foreman", xpRequired: 5000 },
        { name: "Engineer", xpRequired: 15000 },
        { name: "Boss", xpRequired: 50000 },
        { name: "Elite", xpRequired: 150000 },
      ];
      const targetXp = targetTierDef[targetIdx]?.xpRequired || 0;
      const xpNeeded = Math.max(0, targetXp - profile.experience);

      if (xpNeeded > 0) {
        await storage.updateProfile(userId, {
          experience: profile.experience + xpNeeded,
        });
      }

      const newBalance = profile.balance + rankInfo.monthlyCrux;
      await storage.updateProfile(userId, { balance: newBalance });

      await storage.createTransaction({
        userId,
        type: "subscription",
        amount: rankInfo.monthlyCrux,
        description: `${tier} rank subscription - ${rankInfo.monthlyCrux.toLocaleString()} Crux`,
      });

      res.json({ message: `${tier} rank activated!`, tier, crux: rankInfo.monthlyCrux });
    } catch (error) {
      console.error("[Ranks Fulfill] Error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/ranks/status", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const user = await storage.getUser(userId);

      let hasSubscription = false;
      let subscribedTier: string | null = null;
      let nextBillingDate: string | null = null;

      if (user?.email) {
        try {
          const stripe = await getUncachableStripeClient();
          const customers = await stripe.customers.list({ email: user.email, limit: 1 });
          if (customers.data.length > 0) {
            const subs = await stripe.subscriptions.list({
              customer: customers.data[0].id,
              status: "active",
              limit: 1,
            });
            if (subs.data.length > 0) {
              hasSubscription = true;
              nextBillingDate = new Date(subs.data[0].current_period_end * 1000).toISOString();
              const productId = subs.data[0].items.data[0]?.price?.product;
              if (productId) {
                const product = await stripe.products.retrieve(productId as string);
                subscribedTier = product.metadata?.crux_tier || null;
              }
            }
          }
        } catch (stripeErr: any) {
          console.error("[Ranks Status] Stripe lookup error:", stripeErr.message);
        }
      }

      res.json({ hasSubscription, subscribedTier, nextBillingDate });
    } catch (error) {
      console.error("[Ranks Status] Error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/crypto-wallets/list", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      await storage.ensureCryptoWallets(userId);
      const wallets = await storage.getCryptoWallets(userId);
      res.json(wallets);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/duel-class/update", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { duelClass } = req.body;

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const available = getAvailableDuelClasses(tier.name);
      if (!available.find(c => c.id === duelClass)) {
        return res.status(400).json({ message: "Class not available for your tier" });
      }

      await storage.updateProfile(userId, { duelClass });
      res.json({ duelClass, message: "Duel class updated" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/online/heartbeat", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      await storage.updateProfile(userId, { lastSeen: new Date() });
      res.json({ ok: true });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/online/players", isAuthenticated, async (req, res) => {
    try {
      const players = await storage.getOnlinePlayers();
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/leaderboard", isAuthenticated, async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });


  app.post("/api/verify-age", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { confirmed } = req.body;
      if (!confirmed) {
        return res.status(400).json({ message: "Age verification not confirmed" });
      }
      await storage.updateProfile(userId, { ageVerified: true });
      res.json({ message: "Age verified" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/ai/chat", isAuthenticated, async (req, res) => {
    try {
      const userId = getSessionUserId(req);
      const { messages } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ message: "Messages array is required" });
      }

      const profile = await getOrCreateProfile(userId);
      const tier = getUserTier(profile.experience);
      const perks = getTierPerks(tier.name);
      const systemPrompt = `You are Crux Assistant, the helpful AI for Crux Faucet — a provably fair crypto faucet platform.

ABOUT THE USER:
- Username: ${profile.username || "User"}
- Balance: ${Number(profile.balance).toLocaleString()} Crux
- Tier: ${tier.name} (${profile.experience} XP)
- Next tier: ${tier.name === "Elite" ? "Max tier reached" : `needs more XP`}

PLATFORM FEATURES:
1. **Faucet**: Claim free Crux every ${perks.cooldownMinutes} minutes. Rolls 0000-9999. Jackpot (0000) = 50,000 Crux. Your tier multiplier: ${perks.faucetMultiplier}x.
2. **Hi-Lo Game**: Guess if the next number is higher or lower. Max bet: ${(perks.maxHiloBet || 10000).toLocaleString()} Crux. Win streaks (3+) give bonus payouts.
3. **Keno**: Pick 1-10 numbers from 40. Payouts up to 5000x your bet.
4. **Crash**: Place a bet, watch the multiplier rise, cash out before it crashes.
5. **Duels**: Challenge other players in 1v1 Hi-Lo or Keno matches.
6. **Staking**: Lock Crux to earn APY rewards (Engineer tier and above). ${perks.stakingApy > 0 ? `Your APY: ${perks.stakingApy}%` : "Unlock at Engineer tier."}
7. **Daily Bonus**: ${(perks.dailyBonus || 0) > 0 ? `Claim ${perks.dailyBonus} Crux daily.` : "Available from Journeyman tier."}

TIERS (earn XP from games & faucet):
- Apprentice (0 XP): 1.0x faucet, 30min cooldown
- Journeyman (100 XP): 1.1x faucet, 25min cooldown, 5 daily bonus
- Foreman (500 XP): 1.2x faucet, 20min cooldown, 15 daily bonus
- Engineer (2,000 XP): 1.5x faucet, 15min cooldown, 50 daily bonus, staking
- Boss (10,000 XP): 2.0x faucet, 12min cooldown, 150 daily bonus
- Elite (50,000 XP): 3.0x faucet, 10min cooldown, 500 daily bonus

WITHDRAWALS:
- Minimum $20 USD in any crypto wallet to withdraw
- Balance vests at 20% per day (earned vs spendable)
- Rewards may scale based on system conditions
- Tier withdrawal limits: Apprentice 50k, Journeyman 100k, Foreman 250k, Engineer 500k, Boss 2M, Elite 5M Crux

PROVABLY FAIR:
All rolls use SHA256(serverSeed-clientSeed-nonce). The server seed hash is shown before each roll, and the seed is revealed after so users can verify.

RULES:
- Be helpful, friendly, and concise
- Never reveal internal system details like health scores, liquidity numbers, or house edge calculations
- Encourage users to play games and claim the faucet to earn XP
- If asked about withdrawals being slow, explain the vesting system positively (protects all users)
- Recommend rank upgrades when relevant (better perks, faster cooldowns, higher limits)
- Keep responses under 200 words unless the user asks for detailed explanations`;

      const chatMessages = [
        { role: "system" as const, content: systemPrompt },
        ...messages.slice(-20).map((m: any) => ({
          role: m.role as "user" | "assistant",
          content: String(m.content),
        })),
      ];

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const stream = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: chatMessages,
        stream: true,
        max_tokens: 1024,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error) {
      console.error("AI chat error:", error);
      if (res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: "Something went wrong" })}\n\n`);
        res.end();
      } else {
        res.status(500).json({ message: "AI assistant error" });
      }
    }
  });
}
