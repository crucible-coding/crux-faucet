import { canWithdraw, computeHealth, getMode, type LiquidityState } from "./liquidityController";

export type QueueItem = {
  id: string;
  userId: string;
  amount: number;
  address: string;
  createdAt: number;
  tier: "new" | "normal" | "trusted" | "vip";
  botRisk?: number;
  status: "pending" | "approved" | "sent" | "failed" | "delayed";
};

let queue: QueueItem[] = [];

function score(item: QueueItem): number {
  let s = 0;

  if (item.tier === "vip") s += 50;
  else if (item.tier === "trusted") s += 30;
  else if (item.tier === "normal") s += 10;

  s += Math.max(0, 20 - item.amount / 100_000);

  const waitMinutes = (Date.now() - item.createdAt) / 60000;
  s += Math.min(waitMinutes, 30);

  if (item.botRisk) s -= item.botRisk * 40;

  return s;
}

export function enqueue(item: Omit<QueueItem, "status">): QueueItem {
  const entry: QueueItem = {
    ...item,
    status: "pending",
  };
  queue.push(entry);
  return entry;
}

function sortedQueue(): QueueItem[] {
  return [...queue].sort((a, b) => score(b) - score(a));
}

export async function processQueue(
  liquidityState: LiquidityState,
  sendFn: (item: QueueItem) => Promise<boolean>
): Promise<void> {
  const health = computeHealth(liquidityState);
  const mode = getMode(health);

  const ordered = sortedQueue();

  for (const item of ordered) {
    if (item.status !== "pending" && item.status !== "delayed") continue;

    const result = canWithdraw(liquidityState, {
      tier: item.tier,
      balanceUnlocked: item.amount,
      requestedAmount: item.amount,
    });

    if (!result.allowed) {
      item.status = "delayed";
      continue;
    }

    if (mode !== "healthy" && item.amount > liquidityState.hotWallet * 0.15) {
      item.status = "delayed";
      continue;
    }

    try {
      const ok = await sendFn(item);
      item.status = ok ? "sent" : "failed";

      if (ok) {
        liquidityState.hotWallet -= item.amount;
        liquidityState.dailyBudgetUsed += item.amount;
      }
    } catch {
      item.status = "failed";
    }
  }
}

export function cleanupQueue(): void {
  queue = queue.filter((q) => q.status !== "sent" && q.status !== "failed");
}

export function getQueue(): QueueItem[] {
  return queue;
}

export function getUserQueue(userId: string): QueueItem[] {
  return queue.filter((item) => item.userId === userId);
}
