import type { Express, RequestHandler } from "express";
import express from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import bcrypt from "bcryptjs";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as FacebookStrategy } from "passport-facebook";
import { getUser, getUserByEmail, upsertUser } from "./storage";
import crypto from "crypto";

const PgSession = connectPgSimple(session);

function getAppUrl(): string {
  if (process.env.REPLIT_DEV_DOMAIN) {
    return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  }
  if (process.env.REPLIT_DEPLOYMENT_URL) {
    return `https://${process.env.REPLIT_DEPLOYMENT_URL}`;
  }
  return process.env.APP_URL || "http://localhost:5000";
}

function getSession() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL must be set");
  }
  if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET must be set");
  }
  return session({
    store: new PgSession({
      conString: process.env.DATABASE_URL,
      tableName: "sessions",
      createTableIfMissing: false,
    }),
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false,
      maxAge: 30 * 24 * 60 * 60 * 1000,
    },
  });
}

function loginSession(req: any, user: any) {
  (req.session as any).userId = user.id;
  (req.session as any).user = user;
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
  app.use(passport.initialize());
  app.use(passport.session());

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await getUser(id);
      done(null, user);
    } catch (err) {
      done(err, null);
    }
  });

  // --- Google OAuth ---
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    passport.use(
      new GoogleStrategy(
        {
          clientID: process.env.GOOGLE_CLIENT_ID,
          clientSecret: process.env.GOOGLE_CLIENT_SECRET,
          callbackURL: `${getAppUrl()}/api/auth/callback/google`,
          scope: ["profile", "email"],
        },
        async (_accessToken, _refreshToken, profile, done) => {
          try {
            const email = profile.emails?.[0]?.value?.toLowerCase();
            if (!email) {
              return done(new Error("No email from Google"), undefined);
            }

            let user = await getUserByEmail(email);
            if (user) {
              user = await upsertUser({
                id: user.id,
                email,
                firstName: profile.name?.givenName || user.firstName,
                lastName: profile.name?.familyName || user.lastName,
                profileImageUrl: profile.photos?.[0]?.value || user.profileImageUrl,
                authProvider: user.authProvider || "google",
              });
            } else {
              user = await upsertUser({
                id: crypto.randomUUID(),
                email,
                firstName: profile.name?.givenName || null,
                lastName: profile.name?.familyName || null,
                profileImageUrl: profile.photos?.[0]?.value || null,
                authProvider: "google",
              });
            }
            done(null, user);
          } catch (err) {
            done(err as Error, undefined);
          }
        }
      )
    );

    app.get(
      "/api/auth/google",
      passport.authenticate("google", { scope: ["profile", "email"] })
    );

    app.get(
      "/api/auth/callback/google",
      passport.authenticate("google", { failureRedirect: "/?error=google_failed" }),
      (req, res) => {
        loginSession(req, req.user);
        res.redirect("/dashboard");
      }
    );

    console.log("[Auth] Google OAuth configured");
  } else {
    console.log("[Auth] Google OAuth not configured (missing GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET)");
  }

  // --- Facebook OAuth ---
  if (process.env.FACEBOOK_APP_ID && process.env.FACEBOOK_APP_SECRET) {
    passport.use(
      new FacebookStrategy(
        {
          clientID: process.env.FACEBOOK_APP_ID,
          clientSecret: process.env.FACEBOOK_APP_SECRET,
          callbackURL: `${getAppUrl()}/api/auth/callback/facebook`,
          profileFields: ["id", "emails", "name", "photos"],
        },
        async (_accessToken: string, _refreshToken: string, profile: any, done: any) => {
          try {
            const email = profile.emails?.[0]?.value?.toLowerCase();
            if (!email) {
              return done(new Error("No email from Facebook"), undefined);
            }

            let user = await getUserByEmail(email);
            if (user) {
              user = await upsertUser({
                id: user.id,
                email,
                firstName: profile.name?.givenName || user.firstName,
                lastName: profile.name?.familyName || user.lastName,
                profileImageUrl: profile.photos?.[0]?.value || user.profileImageUrl,
                authProvider: user.authProvider || "facebook",
              });
            } else {
              user = await upsertUser({
                id: crypto.randomUUID(),
                email,
                firstName: profile.name?.givenName || null,
                lastName: profile.name?.familyName || null,
                profileImageUrl: profile.photos?.[0]?.value || null,
                authProvider: "facebook",
              });
            }
            done(null, user);
          } catch (err) {
            done(err as Error, undefined);
          }
        }
      )
    );

    app.get(
      "/api/auth/facebook",
      passport.authenticate("facebook", { scope: ["email"] })
    );

    app.get(
      "/api/auth/callback/facebook",
      passport.authenticate("facebook", { failureRedirect: "/?error=facebook_failed" }),
      (req, res) => {
        loginSession(req, req.user);
        res.redirect("/dashboard");
      }
    );

    console.log("[Auth] Facebook OAuth configured");
  } else {
    console.log("[Auth] Facebook OAuth not configured (missing FACEBOOK_APP_ID / FACEBOOK_APP_SECRET)");
  }

  // --- Apple Sign In ---
  if (process.env.APPLE_CLIENT_ID && process.env.APPLE_TEAM_ID && process.env.APPLE_KEY_ID && process.env.APPLE_PRIVATE_KEY) {
    const appleSignIn = await import("apple-signin-auth");

    app.use("/api/auth/callback/apple", express.urlencoded({ extended: true }));

    app.get("/api/auth/apple", (req, res) => {
      const state = crypto.randomBytes(16).toString("hex");
      (req.session as any).appleOAuthState = state;
      const url = appleSignIn.getAuthorizationUrl({
        clientID: process.env.APPLE_CLIENT_ID!,
        redirectUri: `${getAppUrl()}/api/auth/callback/apple`,
        scope: "name email",
        state,
      });
      res.redirect(url);
    });

    async function handleAppleCallback(req: any, res: any) {
      try {
        const body = req.body || req.query || {};
        const { code, id_token: idToken, user: appleUser, state } = body;

        const savedState = (req.session as any)?.appleOAuthState;
        if (state && savedState && state !== savedState) {
          return res.redirect("/?error=apple_state_mismatch");
        }
        delete (req.session as any)?.appleOAuthState;

        if (!code && !idToken) {
          return res.redirect("/?error=apple_failed");
        }

        let tokenResponse;
        if (code) {
          tokenResponse = await appleSignIn.getAuthorizationToken(code, {
            clientID: process.env.APPLE_CLIENT_ID!,
            teamID: process.env.APPLE_TEAM_ID!,
            keyIdentifier: process.env.APPLE_KEY_ID!,
            privateKey: process.env.APPLE_PRIVATE_KEY!,
            redirectUri: `${getAppUrl()}/api/auth/callback/apple`,
          });
        }

        const tokenToVerify = tokenResponse?.id_token || idToken;
        const claims = await appleSignIn.verifyIdToken(tokenToVerify, {
          audience: process.env.APPLE_CLIENT_ID!,
        });

        const email = claims.email?.toLowerCase();
        if (!email) {
          return res.redirect("/?error=apple_no_email");
        }

        let parsedAppleUser: any = {};
        if (appleUser) {
          try {
            parsedAppleUser = typeof appleUser === "string" ? JSON.parse(appleUser) : appleUser;
          } catch {}
        }

        let user = await getUserByEmail(email);
        if (user) {
          user = await upsertUser({
            id: user.id,
            email,
            firstName: parsedAppleUser?.name?.firstName || user.firstName,
            lastName: parsedAppleUser?.name?.lastName || user.lastName,
            authProvider: user.authProvider || "apple",
          });
        } else {
          user = await upsertUser({
            id: crypto.randomUUID(),
            email,
            firstName: parsedAppleUser?.name?.firstName || null,
            lastName: parsedAppleUser?.name?.lastName || null,
            authProvider: "apple",
          });
        }

        loginSession(req, user);
        res.redirect("/dashboard");
      } catch (error) {
        console.error("Apple auth error:", error);
        res.redirect("/?error=apple_failed");
      }
    }

    app.get("/api/auth/callback/apple", handleAppleCallback);
    app.post("/api/auth/callback/apple", handleAppleCallback);

    console.log("[Auth] Apple Sign In configured");
  } else {
    console.log("[Auth] Apple Sign In not configured (missing APPLE_CLIENT_ID / APPLE_TEAM_ID / APPLE_KEY_ID / APPLE_PRIVATE_KEY)");
  }

  // --- Auth status endpoint ---
  app.get("/api/auth/status", (_req, res) => {
    const providers: Record<string, boolean> = {
      google: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
      facebook: !!(process.env.FACEBOOK_APP_ID && process.env.FACEBOOK_APP_SECRET),
      apple: !!(process.env.APPLE_CLIENT_ID && process.env.APPLE_TEAM_ID && process.env.APPLE_KEY_ID && process.env.APPLE_PRIVATE_KEY),
    };
    res.json({ providers });
  });

  // --- Email/Password Auth ---
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, firstName, lastName } = req.body;

      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      if (password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters" });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ message: "Please enter a valid email address" });
      }

      const existing = await getUserByEmail(email.toLowerCase());
      if (existing) {
        return res.status(400).json({ message: "An account with this email already exists" });
      }

      const passwordHash = await bcrypt.hash(password, 12);
      const id = crypto.randomUUID();

      const user = await upsertUser({
        id,
        email: email.toLowerCase(),
        passwordHash,
        firstName: firstName || null,
        lastName: lastName || null,
        authProvider: "email",
      });

      loginSession(req, user);

      const { passwordHash: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Register error:", error);
      res.status(500).json({ message: "Registration failed. Please try again." });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await getUserByEmail(email.toLowerCase());
      if (!user || !user.passwordHash) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const valid = await bcrypt.compare(password, user.passwordHash);
      if (!valid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      loginSession(req, user);

      const { passwordHash: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed. Please try again." });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) console.error("Logout error:", err);
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) console.error("Logout error:", err);
      res.redirect("/");
    });
  });
}

export const isAuthenticated: RequestHandler = (req, res, next) => {
  if ((req.session as any)?.userId) {
    next();
  } else {
    res.status(401).json({ message: "Unauthorized" });
  }
};
