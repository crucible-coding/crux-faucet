export { setupAuth, isAuthenticated } from "./replitAuth";
export { registerAuthRoutes } from "./routes";
export { getUser, upsertUser } from "./storage";
