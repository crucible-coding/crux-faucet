import { getUncachableStripeClient } from "./stripeClient";

const RANK_PRODUCTS = [
  { tier: "Journeyman", priceUsd: 20, monthlyCrux: 20000, description: "1.1x faucet, daily bonus, colored badge" },
  { tier: "Foreman", priceUsd: 40, monthlyCrux: 50000, description: "1.2x faucet, bold username, streak bonus" },
  { tier: "Engineer", priceUsd: 60, monthlyCrux: 100000, description: "1.5x faucet, custom chat color, ETH staking" },
  { tier: "Boss", priceUsd: 80, monthlyCrux: 250000, description: "2x faucet, glowing name, VIP support" },
  { tier: "Elite", priceUsd: 100, monthlyCrux: 500000, description: "3x faucet, rainbow effects, no withdraw min" },
];

async function seedProducts() {
  const stripe = await getUncachableStripeClient();

  for (const rank of RANK_PRODUCTS) {
    const existing = await stripe.products.search({
      query: `metadata['crux_tier']:'${rank.tier}'`,
    });

    if (existing.data.length > 0) {
      console.log(`[Seed] ${rank.tier} already exists (${existing.data[0].id}), skipping`);
      continue;
    }

    const product = await stripe.products.create({
      name: `Crux ${rank.tier} Rank`,
      description: rank.description,
      metadata: {
        crux_tier: rank.tier,
        monthly_crux: String(rank.monthlyCrux),
      },
    });

    const price = await stripe.prices.create({
      product: product.id,
      unit_amount: rank.priceUsd * 100,
      currency: "usd",
      recurring: { interval: "month" },
      metadata: {
        crux_tier: rank.tier,
      },
    });

    console.log(`[Seed] Created ${rank.tier}: product=${product.id}, price=${price.id}, $${rank.priceUsd}/mo`);
  }

  console.log("[Seed] Done!");
}

seedProducts().catch(console.error);
