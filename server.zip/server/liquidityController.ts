import { db } from "./db";
import { sql } from "drizzle-orm";

export type LiquidityState = {
  hotWallet: number;
  projectedRevenue: number;
  projectedWithdrawals: number;
  dailyBudgetUsed: number;
  dailyBudgetLimit: number;
};

export type UserState = {
  tier: "new" | "normal" | "trusted" | "vip";
  lastWithdrawalAt?: number;
  balanceUnlocked: number;
  requestedAmount: number;
};

const TARGET_HOT_WALLET = 10_000_000;
const DAILY_BUDGET_LIMIT = 2_000_000;
const WHALE_THRESHOLD = 1_000_000;

export const TIER_WITHDRAW_LIMITS: Record<string, number> = {
  Apprentice: 50_000,
  Journeyman: 100_000,
  Foreman: 250_000,
  Engineer: 500_000,
  Boss: 1_000_000,
  Elite: 5_000_000,
};

export { DAILY_BUDGET_LIMIT, WHALE_THRESHOLD };

export function computeHealth(state: LiquidityState): number {
  if (state.projectedWithdrawals <= 0) return 3;
  const health = (state.hotWallet + state.projectedRevenue) / state.projectedWithdrawals;
  return Number(health.toFixed(2));
}

export function getMode(health: number): "healthy" | "caution" | "protection" | "emergency" {
  if (health >= 2) return "healthy";
  if (health >= 1.2) return "caution";
  if (health >= 1) return "protection";
  return "emergency";
}

export function getRewardMultiplier(health: number): number {
  const raw = health / 2;
  return clamp(raw, 0.3, 1);
}

export function getCooldown(tier: string, mode: string): number {
  const tierMap: Record<string, number> = {
    Elite: 1 * 60 * 60 * 1000,
    Boss: 2 * 60 * 60 * 1000,
    Engineer: 3 * 60 * 60 * 1000,
    Foreman: 6 * 60 * 60 * 1000,
    Journeyman: 8 * 60 * 60 * 1000,
    Apprentice: 12 * 60 * 60 * 1000,
  };
  const base = tierMap[tier] || 12 * 60 * 60 * 1000;

  if (mode === "caution") return base * 1.5;
  if (mode === "protection") return base * 2;
  if (mode === "emergency") return base * 4;
  return base;
}

export function canWithdraw(
  state: LiquidityState,
  user: UserState
): { allowed: boolean; reason: string; health?: number; mode?: string } {
  const health = computeHealth(state);
  const mode = getMode(health);

  if (state.dailyBudgetUsed + user.requestedAmount > state.dailyBudgetLimit) {
    return { allowed: false, reason: "daily_budget" };
  }

  if (user.balanceUnlocked < user.requestedAmount) {
    return { allowed: false, reason: "locked_balance" };
  }

  const safetyMultiplier = 2;
  if (state.hotWallet < user.requestedAmount * safetyMultiplier) {
    return { allowed: false, reason: "liquidity_low" };
  }

  return { allowed: true, reason: "ok", health, mode };
}

export function getUnlockRate(mode: string): number {
  if (mode === "healthy") return 1;
  if (mode === "caution") return 0.6;
  if (mode === "protection") return 0.4;
  return 0.2;
}

export function isEmergency(state: LiquidityState): boolean {
  return computeHealth(state) < 1;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export async function buildLiquidityState(): Promise<LiquidityState> {
  const [hotWalletResult, revenueResult, withdrawalResult, dailyUsedResult] = await Promise.all([
    db.execute(
      sql`SELECT COALESCE(SUM(CAST(balance AS numeric)), 0) as total FROM user_profiles`
    ),
    db.execute(
      sql`SELECT COALESCE(SUM(ABS(CAST(amount AS numeric))), 0) as total
          FROM transactions
          WHERE type IN ('game_loss', 'crash_bet', 'hilo_loss', 'keno_loss', 'duel_loss')
          AND created_at > NOW() - INTERVAL '24 hours'`
    ),
    db.execute(
      sql`SELECT COALESCE(SUM(ABS(CAST(amount AS numeric))), 0) as total
          FROM transactions
          WHERE type = 'withdraw'
          AND created_at > NOW() - INTERVAL '24 hours'`
    ),
    db.execute(
      sql`SELECT COALESCE(SUM(ABS(CAST(amount AS numeric))), 0) as total
          FROM transactions
          WHERE type = 'withdraw'
          AND created_at > NOW() - INTERVAL '24 hours'`
    ),
  ]);

  const totalUserBalances = parseFloat((hotWalletResult.rows[0] as any)?.total || "0");
  const hotWallet = Math.max(0, TARGET_HOT_WALLET - totalUserBalances);
  const projectedRevenue = parseFloat((revenueResult.rows[0] as any)?.total || "0");
  const projectedWithdrawals = parseFloat((withdrawalResult.rows[0] as any)?.total || "0");
  const dailyBudgetUsed = parseFloat((dailyUsedResult.rows[0] as any)?.total || "0");

  return {
    hotWallet,
    projectedRevenue,
    projectedWithdrawals,
    dailyBudgetUsed,
    dailyBudgetLimit: DAILY_BUDGET_LIMIT,
  };
}

export function mapTierToUserTier(tierName: string): "new" | "normal" | "trusted" | "vip" {
  if (tierName === "Elite" || tierName === "Boss") return "vip";
  if (tierName === "Engineer" || tierName === "Foreman") return "trusted";
  if (tierName === "Journeyman") return "normal";
  return "new";
}

export function tickUnlockBalance(profile: any, mode: string): { newSpendable: number; newLastTick: Date } {
  const balance = parseFloat(profile.balance);
  const spendable = parseFloat(profile.spendableBalance || "0");
  const lastTick = profile.lastUnlockTick ? new Date(profile.lastUnlockTick) : profile.createdAt ? new Date(profile.createdAt) : new Date();
  const now = new Date();
  const hoursSinceTick = (now.getTime() - lastTick.getTime()) / (1000 * 60 * 60);

  if (hoursSinceTick < 1) {
    return { newSpendable: spendable, newLastTick: lastTick };
  }

  const daysFraction = hoursSinceTick / 24;
  const locked = Math.max(0, balance - spendable);
  const rate = getUnlockRate(mode);
  const unlockAmount = Math.min(locked, locked * 0.20 * rate * daysFraction);
  const newSpendable = Math.min(balance, spendable + unlockAmount);

  return { newSpendable: Math.floor(newSpendable), newLastTick: now };
}
