import {
  userProfiles, transactions, hiloGames, kenoGames, crashGames,
  chatMessages, stakes, duels, inboxMessages, referrals,
  achievements, userAchievements, userWallets,
  type UserProfile, type Transaction, type HiloGame, type KenoGame, type CrashGame,
  type ChatMessage, type Stake, type Duel, type InboxMessage, type Referral,
  SUPPORTED_CRYPTOS,
} from "@shared/schema";
import { users, type User } from "@shared/models/auth";
import { db } from "./db";
import { eq, desc, and, sql, gt, lt, or, ne } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | null>;
  getProfile(userId: string): Promise<UserProfile | null>;
  createProfile(userId: string): Promise<UserProfile>;
  updateProfile(userId: string, data: Partial<UserProfile>): Promise<UserProfile>;
  getTransactions(userId: string, limit?: number): Promise<Transaction[]>;
  createTransaction(data: Omit<Transaction, "id" | "createdAt">): Promise<Transaction>;
  createHiloGame(data: Omit<HiloGame, "id" | "createdAt">): Promise<HiloGame>;
  getHiloHistory(userId: string, limit?: number): Promise<HiloGame[]>;
  createKenoGame(data: Omit<KenoGame, "id" | "createdAt">): Promise<KenoGame>;
  getKenoHistory(userId: string, limit?: number): Promise<KenoGame[]>;
  createCrashGame(data: Omit<CrashGame, "id" | "createdAt">): Promise<CrashGame>;
  getCrashGame(id: number): Promise<CrashGame | null>;
  updateCrashGame(id: number, data: Partial<CrashGame>): Promise<CrashGame>;
  getCrashHistory(userId: string, limit?: number): Promise<CrashGame[]>;
  getChatMessages(limit?: number): Promise<ChatMessage[]>;
  createChatMessage(data: Omit<ChatMessage, "id" | "createdAt">): Promise<ChatMessage>;
  createStake(data: Omit<Stake, "id" | "createdAt">): Promise<Stake>;
  getStakes(userId: string): Promise<Stake[]>;
  getStake(id: number): Promise<Stake | null>;
  updateStake(id: number, data: Partial<Stake>): Promise<Stake>;
  createDuel(data: Omit<Duel, "id" | "createdAt" | "resolvedAt">): Promise<Duel>;
  getDuel(id: number): Promise<Duel | null>;
  updateDuel(id: number, data: Partial<Duel>): Promise<Duel>;
  getOpenDuels(): Promise<Duel[]>;
  getDuelHistory(userId: string, limit?: number): Promise<Duel[]>;
  getInboxMessages(userId: string): Promise<InboxMessage[]>;
  createInboxMessage(data: Omit<InboxMessage, "id" | "createdAt">): Promise<InboxMessage>;
  updateInboxMessage(id: number, data: Partial<InboxMessage>): Promise<InboxMessage>;
  getCryptoWallets(userId: string): Promise<any[]>;
  ensureCryptoWallets(userId: string): Promise<void>;
  updateCryptoWallet(userId: string, currency: string, amount: string): Promise<void>;
  getOnlinePlayers(): Promise<any[]>;
  getLeaderboard(): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | null> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user ?? null;
  }

  async getProfile(userId: string): Promise<UserProfile | null> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return profile ?? null;
  }

  async createProfile(userId: string): Promise<UserProfile> {
    const crypto = await import("crypto");
    const serverSeed = crypto.randomBytes(32).toString("hex");
    const serverSeedHash = crypto.createHash("sha256").update(serverSeed).digest("hex");
    const referralCode = crypto.randomBytes(4).toString("hex");

    const [profile] = await db.insert(userProfiles).values({
      userId,
      balance: "0",
      level: 1,
      experience: 0,
      serverSeed,
      serverSeedHash,
      clientSeed: "cruxfaucet",
      nonce: 0,
      referralCode,
    }).returning();

    await this.ensureCryptoWallets(userId);
    return profile;
  }

  async updateProfile(userId: string, data: Partial<UserProfile>): Promise<UserProfile> {
    const [profile] = await db.update(userProfiles).set({
      ...data,
      updatedAt: new Date(),
    }).where(eq(userProfiles.userId, userId)).returning();
    return profile;
  }

  async getTransactions(userId: string, limit = 50): Promise<Transaction[]> {
    return db.select().from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt))
      .limit(limit);
  }

  async createTransaction(data: Omit<Transaction, "id" | "createdAt">): Promise<Transaction> {
    const [tx] = await db.insert(transactions).values(data).returning();
    return tx;
  }

  async createHiloGame(data: Omit<HiloGame, "id" | "createdAt">): Promise<HiloGame> {
    const [game] = await db.insert(hiloGames).values(data).returning();
    return game;
  }

  async getHiloHistory(userId: string, limit = 20): Promise<HiloGame[]> {
    return db.select().from(hiloGames)
      .where(eq(hiloGames.userId, userId))
      .orderBy(desc(hiloGames.createdAt))
      .limit(limit);
  }

  async createKenoGame(data: Omit<KenoGame, "id" | "createdAt">): Promise<KenoGame> {
    const [game] = await db.insert(kenoGames).values(data).returning();
    return game;
  }

  async getKenoHistory(userId: string, limit = 20): Promise<KenoGame[]> {
    return db.select().from(kenoGames)
      .where(eq(kenoGames.userId, userId))
      .orderBy(desc(kenoGames.createdAt))
      .limit(limit);
  }

  async createCrashGame(data: Omit<CrashGame, "id" | "createdAt">): Promise<CrashGame> {
    const [game] = await db.insert(crashGames).values(data).returning();
    return game;
  }

  async getCrashGame(id: number): Promise<CrashGame | null> {
    const [game] = await db.select().from(crashGames).where(eq(crashGames.id, id));
    return game ?? null;
  }

  async updateCrashGame(id: number, data: Partial<CrashGame>): Promise<CrashGame> {
    const [game] = await db.update(crashGames).set(data).where(eq(crashGames.id, id)).returning();
    return game;
  }

  async getCrashHistory(userId: string, limit = 20): Promise<CrashGame[]> {
    return db.select().from(crashGames)
      .where(eq(crashGames.userId, userId))
      .orderBy(desc(crashGames.createdAt))
      .limit(limit);
  }

  async getChatMessages(limit = 50): Promise<ChatMessage[]> {
    return db.select().from(chatMessages)
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  async createChatMessage(data: Omit<ChatMessage, "id" | "createdAt">): Promise<ChatMessage> {
    const [msg] = await db.insert(chatMessages).values(data).returning();
    return msg;
  }

  async createStake(data: Omit<Stake, "id" | "createdAt">): Promise<Stake> {
    const [stake] = await db.insert(stakes).values(data).returning();
    return stake;
  }

  async getStakes(userId: string): Promise<Stake[]> {
    return db.select().from(stakes)
      .where(eq(stakes.userId, userId))
      .orderBy(desc(stakes.createdAt));
  }

  async getStake(id: number): Promise<Stake | null> {
    const [stake] = await db.select().from(stakes).where(eq(stakes.id, id));
    return stake ?? null;
  }

  async updateStake(id: number, data: Partial<Stake>): Promise<Stake> {
    const [stake] = await db.update(stakes).set(data).where(eq(stakes.id, id)).returning();
    return stake;
  }

  async createDuel(data: Omit<Duel, "id" | "createdAt" | "resolvedAt">): Promise<Duel> {
    const [duel] = await db.insert(duels).values(data).returning();
    return duel;
  }

  async getDuel(id: number): Promise<Duel | null> {
    const [duel] = await db.select().from(duels).where(eq(duels.id, id));
    return duel ?? null;
  }

  async updateDuel(id: number, data: Partial<Duel>): Promise<Duel> {
    const [duel] = await db.update(duels).set(data).where(eq(duels.id, id)).returning();
    return duel;
  }

  async getOpenDuels(): Promise<Duel[]> {
    return db.select().from(duels)
      .where(eq(duels.status, "open"))
      .orderBy(desc(duels.createdAt));
  }

  async getDuelHistory(userId: string, limit = 20): Promise<Duel[]> {
    return db.select().from(duels)
      .where(
        and(
          or(eq(duels.challengerId, userId), eq(duels.opponentId, userId)),
          ne(duels.status, "open")
        )
      )
      .orderBy(desc(duels.createdAt))
      .limit(limit);
  }

  async getInboxMessages(userId: string): Promise<InboxMessage[]> {
    return db.select().from(inboxMessages)
      .where(eq(inboxMessages.userId, userId))
      .orderBy(desc(inboxMessages.createdAt));
  }

  async createInboxMessage(data: Omit<InboxMessage, "id" | "createdAt">): Promise<InboxMessage> {
    const [msg] = await db.insert(inboxMessages).values(data).returning();
    return msg;
  }

  async updateInboxMessage(id: number, data: Partial<InboxMessage>): Promise<InboxMessage> {
    const [msg] = await db.update(inboxMessages).set(data).where(eq(inboxMessages.id, id)).returning();
    return msg;
  }

  async getCryptoWallets(userId: string): Promise<any[]> {
    return db.select().from(userWallets)
      .where(eq(userWallets.userId, userId));
  }

  async ensureCryptoWallets(userId: string): Promise<void> {
    const existing = await this.getCryptoWallets(userId);
    const existingCurrencies = existing.map(w => w.currency);
    for (const crypto of SUPPORTED_CRYPTOS) {
      if (!existingCurrencies.includes(crypto.id)) {
        await db.insert(userWallets).values({
          userId,
          currency: crypto.id,
          balance: "0",
        });
      }
    }
  }

  async updateCryptoWallet(userId: string, currency: string, amount: string): Promise<void> {
    await db.update(userWallets)
      .set({ balance: amount })
      .where(and(eq(userWallets.userId, userId), eq(userWallets.currency, currency)));
  }

  async getOnlinePlayers(): Promise<any[]> {
    const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000);
    const profiles = await db.select({
      userId: userProfiles.userId,
      avatar: userProfiles.avatar,
      experience: userProfiles.experience,
      lastSeen: userProfiles.lastSeen,
    }).from(userProfiles)
      .where(gt(userProfiles.lastSeen, fiveMinAgo))
      .limit(50);

    const result = [];
    for (const p of profiles) {
      const user = await this.getUser(p.userId);
      if (user) {
        const { getUserTier } = await import("@shared/schema");
        const tier = getUserTier(p.experience);
        result.push({
          userId: p.userId,
          username: user.firstName || user.email || "Anonymous",
          tier: tier.name,
          avatar: p.avatar || "steve",
          lastSeen: p.lastSeen?.toISOString() || new Date().toISOString(),
        });
      }
    }
    return result;
  }

  async getLeaderboard(): Promise<any[]> {
    const profiles = await db.select().from(userProfiles)
      .orderBy(desc(userProfiles.experience))
      .limit(50);

    const result = [];
    for (const p of profiles) {
      const user = await this.getUser(p.userId);
      if (user) {
        const { getUserTier } = await import("@shared/schema");
        const tier = getUserTier(p.experience);
        result.push({
          userId: p.userId,
          username: user.firstName || user.email || "Anonymous",
          tier: tier.name,
          experience: p.experience,
          balance: p.balance,
          avatar: p.avatar || "steve",
          totalGamesPlayed: p.totalGamesPlayed,
          duelWins: p.duelWins,
          duelElo: p.duelElo,
        });
      }
    }
    return result;
  }
}

export const storage = new DatabaseStorage();
