import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),

  balance: numeric("balance").default("0").notNull(),
  level: integer("level").default(1).notNull(),
  experience: integer("experience").default(0).notNull(),

  lastHourlyRoll: timestamp("last_hourly_roll"),
  lastDailyBonus: timestamp("last_daily_bonus"),
  hiloStreak: integer("hilo_streak").default(0).notNull(),

  walletAddress: text("wallet_address"),
  chatColor: text("chat_color"),
  avatar: text("avatar").default("steve"),

  emailVerified: boolean("email_verified").default(false).notNull(),

  referralCode: text("referral_code"),
  referredBy: text("referred_by"),
  referralCount: integer("referral_count").default(0).notNull(),
  referralEarnings: numeric("referral_earnings").default("0").notNull(),

  loginStreak: integer("login_streak").default(0).notNull(),
  lastLoginDate: text("last_login_date"),

  totalGamesPlayed: integer("total_games_played").default(0).notNull(),

  serverSeed: text("server_seed"),
  serverSeedHash: text("server_seed_hash"),
  clientSeed: text("client_seed").default("cruxfaucet"),
  nonce: integer("nonce").default(0).notNull(),

  duelClass: text("duel_class").default("knight"),
  duelWins: integer("duel_wins").default(0).notNull(),
  duelLosses: integer("duel_losses").default(0).notNull(),
  duelElo: integer("duel_elo").default(1200).notNull(),

  ageVerified: boolean("age_verified").default(false).notNull(),
  lastSeen: timestamp("last_seen"),

  lastWithdrawal: timestamp("last_withdrawal"),
  withdrawalCount: integer("withdrawal_count").default(0).notNull(),

  spendableBalance: numeric("spendable_balance").default("0").notNull(),
  lastUnlockTick: timestamp("last_unlock_tick"),
  totalWithdrawn: numeric("total_withdrawn").default("0").notNull(),

  // ⭐ TRUST SYSTEM
  trustScore: integer("trust_score").default(0).notNull(),
  trustLevel: text("trust_level").default("new").notNull(),
  trustEarnedTotal: integer("trust_earned_total").default(0).notNull(),
  lastTrustUpdate: timestamp("last_trust_update"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});// ===== SUPPORTED CRYPTOS (frontend contract) =====
export const SUPPORTED_CRYPTOS = [
  { id: "btc", symbol: "BTC", name: "Bitcoin", chain: "Bitcoin", color: "#f7931a" },
  { id: "eth", symbol: "ETH", name: "Ethereum", chain: "Ethereum", color: "#627eea" },
  { id: "usdc", symbol: "USDC", name: "USD Coin", chain: "Ethereum", color: "#2775ca" },
] as const;

export type CryptoId = (typeof SUPPORTED_CRYPTOS)[number]["id"];