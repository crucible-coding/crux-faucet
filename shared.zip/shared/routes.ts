import { z } from 'zod';
import { userProfiles, transactions, hiloGames, kenoGames, chatMessages, stakes, duels, userWallets, crashGames } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  forbidden: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  faucet: {
    claim: {
      method: 'POST' as const,
      path: '/api/faucet/claim',
      responses: {
        200: z.object({
          amount: z.string(),
          newBalance: z.string(),
          nextRollAvailableAt: z.string(),
          message: z.string(),
          rolledValue: z.string(),
          serverSeed: z.string(),
          serverSeedHash: z.string(),
          clientSeed: z.string(),
          nonce: z.number(),
          newServerSeedHash: z.string(),
          cryptoSplit: z.array(z.object({
            crypto: z.string(),
            symbol: z.string(),
            amount: z.number(),
          })).optional(),
        }),
        400: z.object({ message: z.string(), nextRollAvailableAt: z.string().optional() }), // Cooldown active
        401: errorSchemas.unauthorized,
      },
    },
    status: {
      method: 'GET' as const,
      path: '/api/faucet/status',
      responses: {
        200: z.object({
          canClaim: z.boolean(),
          nextRollAvailableAt: z.string().nullable(),
          testMode: z.boolean().optional(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  provablyFair: {
    settings: {
      method: 'GET' as const,
      path: '/api/provably-fair/settings',
      responses: {
        200: z.object({
          serverSeedHash: z.string(),
          clientSeed: z.string(),
          nonce: z.number(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    updateClientSeed: {
      method: 'POST' as const,
      path: '/api/provably-fair/client-seed',
      input: z.object({ clientSeed: z.string().min(1).max(64) }),
      responses: {
        200: z.object({
          clientSeed: z.string(),
          message: z.string(),
        }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    rotateSeed: {
      method: 'POST' as const,
      path: '/api/provably-fair/rotate-seed',
      responses: {
        200: z.object({
          previousServerSeed: z.string(),
          newServerSeedHash: z.string(),
          message: z.string(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    verify: {
      method: 'POST' as const,
      path: '/api/provably-fair/verify',
      input: z.object({
        serverSeed: z.string(),
        clientSeed: z.string(),
        nonce: z.number(),
      }),
      responses: {
        200: z.object({
          result: z.string(),
          hash: z.string(),
        }),
      },
    },
  },
  hilo: {
    play: {
      method: 'POST' as const,
      path: '/api/hilo/play',
      input: z.object({
        betAmount: z.number().min(1).max(1000000),
        guess: z.enum(['higher', 'lower']),
      }),
      responses: {
        200: z.object({
          currentNumber: z.number(),
          nextNumber: z.number(),
          guess: z.string(),
          won: z.boolean(),
          betAmount: z.string(),
          payout: z.string(),
          newBalance: z.string(),
          multiplier: z.string(),
          serverSeed: z.string(),
          serverSeedHash: z.string(),
          clientSeed: z.string(),
          nonce: z.number(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    history: {
      method: 'GET' as const,
      path: '/api/hilo/history',
      responses: {
        200: z.array(z.custom<typeof hiloGames.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
  },
  keno: {
    play: {
      method: 'POST' as const,
      path: '/api/keno/play',
      input: z.object({
        betAmount: z.number().min(1).max(1000000),
        selectedNumbers: z.array(z.number().min(1).max(40)).min(1).max(10),
      }),
      responses: {
        200: z.object({
          selectedNumbers: z.array(z.number()),
          drawnNumbers: z.array(z.number()),
          hits: z.number(),
          multiplier: z.string(),
          betAmount: z.string(),
          payout: z.string(),
          newBalance: z.string(),
          serverSeed: z.string(),
          serverSeedHash: z.string(),
          clientSeed: z.string(),
          nonce: z.number(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    history: {
      method: 'GET' as const,
      path: '/api/keno/history',
      responses: {
        200: z.array(z.custom<typeof kenoGames.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
  },
  user: {
    dashboard: {
      method: 'GET' as const,
      path: '/api/user/dashboard',
      responses: {
        200: z.object({
          profile: z.custom<typeof userProfiles.$inferSelect>(),
          transactions: z.array(z.custom<typeof transactions.$inferSelect>()),
          nextRollAvailableAt: z.string().nullable(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  chat: {
    messages: {
      method: 'GET' as const,
      path: '/api/chat/messages',
      responses: {
        200: z.array(z.custom<typeof chatMessages.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    send: {
      method: 'POST' as const,
      path: '/api/chat/send',
      input: z.object({
        message: z.string().min(1).max(500),
      }),
      responses: {
        200: z.custom<typeof chatMessages.$inferSelect>(),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  dailyBonus: {
    claim: {
      method: 'POST' as const,
      path: '/api/daily-bonus/claim',
      responses: {
        200: z.object({
          amount: z.number(),
          newBalance: z.string(),
          tierName: z.string(),
          message: z.string(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    status: {
      method: 'GET' as const,
      path: '/api/daily-bonus/status',
      responses: {
        200: z.object({
          canClaim: z.boolean(),
          nextAvailableAt: z.string().nullable(),
          bonusAmount: z.number(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  chatColor: {
    update: {
      method: 'POST' as const,
      path: '/api/chat/color',
      input: z.object({
        color: z.string().regex(/^#[0-9a-fA-F]{6}$/, "Invalid hex color"),
      }),
      responses: {
        200: z.object({ chatColor: z.string(), message: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
        403: errorSchemas.forbidden,
      },
    },
  },
  staking: {
    create: {
      method: 'POST' as const,
      path: '/api/staking/create',
      input: z.object({
        satoshiAmount: z.number().min(100),
      }),
      responses: {
        200: z.object({
          stake: z.custom<typeof stakes.$inferSelect>(),
          message: z.string(),
          newBalance: z.string(),
          stakingApy: z.number(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/staking/list',
      responses: {
        200: z.object({
          stakes: z.array(z.custom<typeof stakes.$inferSelect>()),
          totalEthStaked: z.string(),
          totalSatoshiStaked: z.string(),
          stakingApy: z.number(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    withdraw: {
      method: 'POST' as const,
      path: '/api/staking/withdraw',
      input: z.object({
        stakeId: z.number(),
      }),
      responses: {
        200: z.object({
          message: z.string(),
          ethAmount: z.string(),
          ethWithRewards: z.string(),
          satoshiReturned: z.string(),
          newBalance: z.string(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    prices: {
      method: 'GET' as const,
      path: '/api/staking/prices',
      responses: {
        200: z.object({
          btcPrice: z.number(),
          ethPrice: z.number(),
          btcToEthRate: z.number(),
        }),
      },
    },
  },
  referral: {
    apply: {
      method: 'POST' as const,
      path: '/api/referral/apply',
      input: z.object({
        code: z.string().min(1).max(20),
      }),
      responses: {
        200: z.object({ message: z.string(), newBalance: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  avatar: {
    update: {
      method: 'POST' as const,
      path: '/api/avatar/update',
      input: z.object({
        avatarId: z.string().min(1),
      }),
      responses: {
        200: z.object({ avatar: z.string(), message: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  duel: {
    create: {
      method: 'POST' as const,
      path: '/api/duel/create',
      input: z.object({
        betAmount: z.number().min(10).max(1000000),
        gameType: z.enum(['hilo', 'keno']).default('hilo'),
        targetUserId: z.string().optional(),
      }),
      responses: {
        200: z.object({
          duel: z.custom<typeof duels.$inferSelect>(),
          message: z.string(),
          newBalance: z.string(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    accept: {
      method: 'POST' as const,
      path: '/api/duel/accept',
      input: z.object({
        duelId: z.number(),
      }),
      responses: {
        200: z.object({
          duel: z.custom<typeof duels.$inferSelect>(),
          message: z.string(),
          newBalance: z.string(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    cancel: {
      method: 'POST' as const,
      path: '/api/duel/cancel',
      input: z.object({
        duelId: z.number(),
      }),
      responses: {
        200: z.object({ message: z.string(), newBalance: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/duel/list',
      responses: {
        200: z.array(z.custom<typeof duels.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    history: {
      method: 'GET' as const,
      path: '/api/duel/history',
      responses: {
        200: z.array(z.custom<typeof duels.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
  },
  wallet: {
    withdraw: {
      method: 'POST' as const,
      path: '/api/wallet/withdraw',
      input: z.object({
        amount: z.number().min(1),
        btcAddress: z.string().min(26).max(62),
      }),
      responses: {
        200: z.object({
          message: z.string(),
          newBalance: z.string(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    withdrawStatus: {
      method: 'GET' as const,
      path: '/api/wallet/withdraw-status',
      responses: {
        200: z.object({
          balance: z.number(),
          spendableBalance: z.number(),
          lockedBalance: z.number(),
          tierLimit: z.number(),
          cooldownMinutesRemaining: z.number(),
          withdrawalCount: z.number(),
          totalWithdrawn: z.number(),
          dailyBudgetRemaining: z.number(),
          systemMode: z.string(),
          healthScore: z.number(),
          canWithdraw: z.boolean(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  liquidity: {
    status: {
      method: 'GET' as const,
      path: '/api/liquidity/status',
      responses: {
        200: z.object({
          mode: z.string(),
          healthScore: z.number(),
          liquidityFactor: z.number(),
          emergencyMode: z.boolean(),
          rewardMultiplier: z.string(),
          unlockRate: z.number(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  inbox: {
    list: {
      method: 'GET' as const,
      path: '/api/inbox/messages',
      responses: {
        200: z.object({
          messages: z.array(z.any()),
          unreadCount: z.number(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
    read: {
      method: 'POST' as const,
      path: '/api/inbox/read',
      input: z.object({ messageId: z.number() }),
      responses: {
        200: z.object({ message: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    verifyEmail: {
      method: 'POST' as const,
      path: '/api/inbox/verify-email',
      input: z.object({ messageId: z.number() }),
      responses: {
        200: z.object({ message: z.string(), newBalance: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  ranks: {
    list: {
      method: 'GET' as const,
      path: '/api/ranks/list',
      responses: {
        200: z.array(z.object({
          tier: z.string(),
          monthlyPrice: z.number(),
          monthlyCrux: z.number(),
          priceId: z.string().optional(),
          productId: z.string().optional(),
        })),
      },
    },
    checkout: {
      method: 'POST' as const,
      path: '/api/ranks/checkout',
      input: z.object({
        tier: z.string(),
      }),
      responses: {
        200: z.object({ url: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    status: {
      method: 'GET' as const,
      path: '/api/ranks/status',
      responses: {
        200: z.object({
          hasSubscription: z.boolean(),
          subscribedTier: z.string().nullable(),
          nextBillingDate: z.string().nullable(),
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  crash: {
    play: {
      method: 'POST' as const,
      path: '/api/crash/play',
      input: z.object({
        betAmount: z.number().min(1).max(1000000),
      }),
      responses: {
        200: z.object({
          gameId: z.number(),
          crashPoint: z.string(),
          serverSeedHash: z.string(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    cashout: {
      method: 'POST' as const,
      path: '/api/crash/cashout',
      input: z.object({
        gameId: z.number(),
        cashoutAt: z.number().min(1.01),
      }),
      responses: {
        200: z.object({
          won: z.boolean(),
          crashPoint: z.string(),
          cashedOutAt: z.string(),
          payout: z.string(),
          newBalance: z.string(),
          serverSeed: z.string(),
          serverSeedHash: z.string(),
          clientSeed: z.string(),
          nonce: z.number(),
        }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
    history: {
      method: 'GET' as const,
      path: '/api/crash/history',
      responses: {
        200: z.array(z.custom<typeof crashGames.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
  },
  cryptoWallets: {
    list: {
      method: 'GET' as const,
      path: '/api/crypto-wallets/list',
      responses: {
        200: z.array(z.object({
          id: z.number(),
          userId: z.string(),
          currency: z.string(),
          balance: z.string(),
          createdAt: z.string().nullable(),
        })),
        401: errorSchemas.unauthorized,
      },
    },
  },
  duelClass: {
    update: {
      method: 'POST' as const,
      path: '/api/duel-class/update',
      input: z.object({
        duelClass: z.enum(['knight', 'assassin', 'tank', 'alchemist', 'ranger', 'warden']),
      }),
      responses: {
        200: z.object({ duelClass: z.string(), message: z.string() }),
        400: z.object({ message: z.string() }),
        401: errorSchemas.unauthorized,
      },
    },
  },
  online: {
    heartbeat: {
      method: 'POST' as const,
      path: '/api/online/heartbeat',
      responses: {
        200: z.object({ ok: z.boolean() }),
        401: errorSchemas.unauthorized,
      },
    },
    players: {
      method: 'GET' as const,
      path: '/api/online/players',
      responses: {
        200: z.array(z.object({
          userId: z.string(),
          username: z.string(),
          tier: z.string(),
          avatar: z.string(),
          lastSeen: z.string(),
        })),
        401: errorSchemas.unauthorized,
      },
    },
  },
  stripe: {
    publishableKey: {
      method: 'GET' as const,
      path: '/api/stripe/publishable-key',
      responses: {
        200: z.object({ publishableKey: z.string() }),
      },
    },
  },
};

// ============================================
// REQUIRED: buildUrl helper
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type FaucetClaimResponse = z.infer<typeof api.faucet.claim.responses[200]>;
export type FaucetStatusResponse = z.infer<typeof api.faucet.status.responses[200]>;
export type UserDashboardResponse = z.infer<typeof api.user.dashboard.responses[200]>;
